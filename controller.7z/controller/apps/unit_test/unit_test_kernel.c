#include "unit_test_kernel.h"

#include "kernel/base/me_malloc.h"

#include <stdarg.h>
#include <stddef.h>
#include <setjmp.h>

#include "cmockery.h"


static struct unit_test_kernel_
{
	me_uint8_t				test_ram_0[1024];
	me_uint8_t				test_ram_1[1027];
} unit_test_kernel_g;


static void unit_test_kernel_memory_base(void **state, me_uint8_t *ram_addr, me_size_t ram_size)
{
	me_malloc_manager_t *	test_mgr;
	void *					test_ptr;

	test_mgr = me_malloc_initialize(ram_addr, ram_size);
	assert_true(test_mgr != NULL);

	me_malloc_finalize(test_mgr);
}

static void unit_test_kernel_memory(void **state)
{
}


me_bool_t unit_test_kernel(void)
{
	const UnitTest tests[] = {
		unit_test(unit_test_kernel_memory),
	};

	me_int32_t result;

	result = run_tests(tests);

	return (ME_TRUE);
}

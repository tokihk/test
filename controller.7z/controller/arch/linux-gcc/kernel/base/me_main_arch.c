#include "kernel/base/me_kernel_main.h"


int main(int argc, char *argv[])
{
	me_int8_t exit_code;

	exit_code = me_kernel_main((me_int32_t)argc, (const me_achar_t **)argv);

	return (exit_code);
}



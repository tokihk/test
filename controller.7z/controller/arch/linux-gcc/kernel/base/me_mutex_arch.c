#include "me_mutex_arch.h"



me_bool_t me_mutex_initialize_arch(me_mutex_arch_t *obj)
{
	pthread_mutex_init(&obj->mutex, NULL);

	return (ME_TRUE);
}

void me_mutex_finalize_arch(me_mutex_arch_t *obj)
{
	pthread_mutex_destroy(&obj->mutex);
}

void me_mutex_lock_arch(me_mutex_arch_t *obj)
{
	pthread_mutex_lock(&obj->mutex);
}

me_bool_t me_mutex_trylock_arch(me_mutex_arch_t *obj)
{
	me_bool_t lock = ME_FALSE;

	if (pthread_mutex_trylock(&obj->mutex) == 0) {
		lock = ME_TRUE;
	}

	return (lock);
}

void me_mutex_unlock_arch(me_mutex_arch_t *obj)
{
	pthread_mutex_unlock(&obj->mutex);
}

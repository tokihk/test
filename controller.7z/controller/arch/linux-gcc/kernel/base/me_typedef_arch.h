#ifndef ME_TYPEDEF_ARCH_H_
#define ME_TYPEDEF_ARCH_H_

#include <stddef.h>
#include <stdint.h>
#include <wchar.h>

	typedef unsigned char				me_uint8_t;
	typedef unsigned short				me_uint16_t;
	typedef unsigned int				me_uint32_t;

	typedef signed char					me_int8_t;
	typedef signed short				me_int16_t;
	typedef signed int					me_int32_t;

	typedef unsigned char				me_bool_t;
	typedef size_t						me_size_t;

	#define ME_SIZE_MAX					SIZE_MAX

	#define ME_STRING_LENGTH_MAX		0x0FFFFFFFu

	#define ME_PATH_LENGTH_MAX			250u

#endif

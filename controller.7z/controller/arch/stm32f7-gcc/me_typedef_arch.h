#ifndef ME_TYPEDEF_ARCH_HPP_
#define ME_TYPEDEF_ARCH_HPP_

	typedef unsigned char			me_uint8_t;
	typedef unsigned short			me_uint16_t;
	typedef unsigned int			me_uint32_t;

	typedef signed char				me_int8_t;
	typedef signed short			me_int16_t;
	typedef signed int				me_int32_t;

#endif

#include "kernel/base/me_main.h"


me_int8_t me_main(me_int32_t argc, const me_achar_t *argv[])
{
	me_int8_t exit_code = 0;

	UNREFERENCED_PARAMETER(argc);
	UNREFERENCED_PARAMETER(argv);

	return (exit_code);
}



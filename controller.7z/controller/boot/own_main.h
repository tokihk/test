#ifndef ME_MAIN_H_
#define ME_MAIN_H_

#include "kernel/me_kernel.h"


	me_int8_t			me_main(me_int32_t argc, const me_achar_t *argv[]);

#endif

#ifndef ME_CONFIG_H_
#define ME_CONFIG_H_

#include "kernel/base/me_config_arch.h"


#ifndef ME_SYSLOG_TARGET_STDOUT_ENABLE
#define ME_SYSLOG_TARGET_STDOUT_ENABLE			(0)
#endif

#ifndef ME_SYSLOG_TARGET_STDERR_ENABLE
#define ME_SYSLOG_TARGET_STDERR_ENABLE			(0)
#endif

#ifndef ME_SYSLOG_TARGET_FILE_ENABLE
#define ME_SYSLOG_TARGET_FILE_ENABLE			(0)
#endif

#ifndef ME_SYSLOG_TARGET_UDP_ENABLE
#define ME_SYSLOG_TARGET_UDP_ENABLE				(0)
#endif

#ifndef ME_SYSLOG_TARGET_TCP_ENABLE
#define ME_SYSLOG_TARGET_TCP_ENABLE				(0)
#endif

#endif

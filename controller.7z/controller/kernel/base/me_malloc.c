/* ###################################################################### *//**
 *
 *	@addtogroup	Kernel
 *	@{
 *	@file		me_malloc.h
 *	@brief		Heap Memory Module
 *	@author		Copyright (C) 2019 Hitoshi Kouno
 *
*//* ####################################################################### */

#include "me_malloc.h"


struct me_malloc_use_cell_header
{
	me_size_t						cell_size;
	void *							cell_addr_top;
	const me_achar_t *				source_file_name;
	me_uint32_t						source_line_no;
};

struct me_malloc_use_cell_footer
{
	void *							cell_addr_top;
};


me_malloc_manager_t *me_malloc_initialize(void *ram_addr, me_size_t ram_size)
{
	me_malloc_manager_t *mgr = NULL;

	if (   (ram_addr != NULL)
		&& (ram_size > sizeof(me_malloc_manager_t))
	) {
		mgr = (me_malloc_manager_t *)ram_addr;

		memset(mgr, sizeof(*mgr));
		mgr->ram_addr = ram_addr;
		mgr->ram_size = ram_size;

		mgr->free_cell_top.cell_next = mgr->ram_addr + sizeof(*mgr);
		mgr->free_cell_top.cell_next->cell_size = mgr->ram_size - sizeof(*mgr);
		mgr->free_cell_top.cell_next->cell_next = NULL;

		mgr->alloc_cell_top.cell_prev = &mgr->alloc_cell_top;
		mgr->alloc_cell_top.cell_next = &mgr->alloc_cell_top;
	}

	return (mgr);
}

void me_malloc_finalize(me_malloc_manager_t *mgr)
{
	if (mgr != NULL) {
	}
}

void me_malloc_using_list(me_malloc_manager_t *mgr, ME_MALLOC_USING_CALLBACK callback)
{

}

void *me_malloc_base(me_malloc_manager_t *mgr, me_size_t size, const char *file_name, int line_no)
{
	void *ptr = NULL;

	if (   (mgr != NULL)
		&& (size > 0)
	) {
		struct me_malloc_free_cell *cell_prev = mgr->free_cell_top;
		struct me_malloc_free_cell *cell_curr = cell_prev->cell_next;
		me_size_t cell_size = size;

		/* Cell Size */
		if ((cell_size & 0x03) != 0) {
			cell_size += 4 - (cell_size & 0x03);
		}
		cell_size += sizeof(struct me_malloc_alloc_cell);

		/* Scan Free Cell */
		while ((cell_curr != NULL) && (cell_curr->cell_size <= cell_size)) {
			cell_prev = cell_curr;
			cell_curr = cell_curr->cell_next;
		}

		/* Found Free Cell */
		if (cell_curr != NULL) {
			struct me_malloc_alloc_cell *alloc_cell = (struct me_malloc_alloc_cell *)cell_curr->cell_next;
			struct me_malloc_free_cell *free_cell_new = (struct me_malloc_free_cell *)((me_uint8_t *)cell_curr + cell_size);

			ptr = (me_uint8_t *)cell_curr + sizeof(*alloc_cell);

			/* Allocate Cell Memory */
			alloc_cell->cell_size = cell_size;
			alloc_cell->info.data_size = size;
			alloc_cell->info.data_addr = ptr;
			alloc_cell->info.source_file_name = file_name;
			alloc_cell->info.source_line_no = line_no;

			alloc_cell->cell_prev = mgr->alloc_cell_top.cell_prev;
			alloc_cell->cell_next = &mgr->alloc_cell_top;

			mgr->alloc_cell_top.cell_prev->cell_next = alloc_cell;
			mgr->alloc_cell_top.cell_prev = alloc_cell;

			free_cell_new->cell_next = cell_curr->cell_next;
			free_cell_new->cell_size = cell_curr->cell_size - cell_size;

			cell_prev->cell_next = free_cell_new;
		}
	}

	return (ptr);
}

void *me_calloc_base(me_malloc_manager_t *mgr, me_size_t size, const char *file_name, int line_no)
{
	void *ptr = me_malloc_base(mgr, size, file_name, line_no);

	if (ptr != NULL) {
		memset(ptr, size);
	}

	return (ptr);
}

void me_free_base(me_malloc_manager_t *mgr, void *ptr)
{
	if (ptr != NULL) {
		struct me_malloc_alloc_cell *cell_free = ptr - sizeof(struct me_malloc_alloc_cell);
		struct me_malloc_free_cell *cell_prev = mgr->free_cell_top;
		struct me_malloc_free_cell *cell_curr = cell_prev->cell_next;

		while ((cell_curr != NULL) && (cell_curr < cell_free)) {

		}
	}
}
static void memory_free_sub(void *p)
{
	if (p) {
		MEMORY_CELL *curr, *prev;
		MEMORY_CELL *free = (MEMORY_CELL *)((char_t *)p - offsetof(MEMORY_CELL, next));

		/* === Search the Free Cell === */
		prev = &memory_state.free;
		curr = prev->next;
		while (curr && (curr < free)) {
			prev = curr;
			curr = curr->next;
		}

		/* === Unite the Forward Adjacent Cell === */
		if (!curr) {
			free->next  = NULL;
		} else if ((MEMORY_CELL *)((char_t *)free + free->size) == curr) {
			free->size += curr->size;
			free->next  = curr->next;
		} else {
			free->next  = curr;
		}

		/* === Unite the Backward Adjacent Cell === */
		if ((MEMORY_CELL *)((char_t *)prev + prev->size) == free) {
			prev->size += free->size;
			prev->next  = free->next;
		} else {
			prev->next  = free;
		}

		/* === Memory Health Check === */
		#ifdef MEMORY_HEALTH_CHECK
		memory_health_check(D_FALSE);
		#endif
	}
}

/* ####### File End ###### */
/** @} */

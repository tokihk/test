/* ###################################################################### *//**
 *
 *	@addtogroup	Kernel
 *	@{
 *	@file		me_malloc.h
 *	@brief		Heap Memory Module
 *	@author		Copyright (C) 2019 Hitoshi Kouno
 *
*//* ####################################################################### */
#ifndef ME_MALLOC_H_
#define ME_MALLOC_H_

#include "kernel/me_kernel.h"


struct me_malloc_alloc_cell_info
{
	const void *						data_addr;
	me_size_t							data_size;
	const me_achar_t *					source_file_name;
	me_uint32_t							source_line_no;
};

typedef void (* ME_MALLOC_USING_CALLBACK)(me_malloc_manager_t *mgr, me_uint32_t index, const struct me_malloc_alloc_cell_info *info);

struct me_malloc_alloc_cell
{
	me_size_t							cell_size;
	struct me_malloc_alloc_cell *		cell_prev;
	struct me_malloc_alloc_cell *		cell_next;
	struct me_malloc_alloc_cell_info	info;
};

struct me_malloc_free_cell
{
	me_size_t							cell_size;
	struct me_malloc_free_cell *		cell_next;
};

typedef struct me_malloc_manager
{
	me_uint8_t *						ram_addr;
	me_size_t							ram_size;
	struct me_malloc_free_cell			free_cell_top;
	struct me_malloc_alloc_cell			alloc_cell_top;
} me_malloc_manager_t;


me_malloc_manager_t *			me_malloc_initialize(void *ram_addr, me_size_t ram_size);
void							me_malloc_finalize(me_malloc_manager_t *mgr);

void							me_malloc_using_list(me_malloc_manager_t *mgr, ME_MALLOC_USING_CALLBACK callback);

void *							me_malloc_base(me_malloc_manager_t *mgr, me_size_t size, const char *file_name, int line_no);
void *							me_calloc_base(me_malloc_manager_t *mgr, me_size_t size, const char *file_name, int line_no);

void							me_free_base(me_malloc_manager_t *mgr, void *ptr);


#endif /* ME_THREAD_H_ */
/* ####### File End ###### */
/** @} */

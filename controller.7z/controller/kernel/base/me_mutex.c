/* ###################################################################### *//**
 *
 *	@addtogroup	Kernel
 *	@{
 *	@file		me_mutex.c
 *	@brief		Mutex Module
 *	@author		Copyright (C) 2019 Hitoshi Kouno
 *
*//* ####################################################################### */

#include "me_mutex.h"


me_bool_t me_mutex_initialize(me_mutex_t *obj)
{
	me_bool_t init_ok = ME_FALSE;

	if (obj != NULL) {
		obj->guard_code = obj;

		if (me_mutex_initialize_arch(&obj->arch_param)) {
			init_ok = ME_TRUE;
		}
	}

	if (!init_ok) {
		me_mutex_finalize(obj);
	}

	return (init_ok);
}

void me_mutex_finalize(me_mutex_t *obj)
{
	if ((obj != NULL) && (obj->guard_code == obj)) {
		me_mutex_finalize_arch(&obj->arch_param);
		obj->guard_code = NULL;
	}
}

void me_mutex_lock(me_mutex_t *obj)
{
	if ((obj != NULL) && (obj->guard_code == obj)) {
		me_mutex_lock_arch(&obj->arch_param);
	}
}

me_bool_t me_mutex_trylock(me_mutex_t *obj)
{
	me_bool_t lock = ME_FALSE;

	if ((obj != NULL) && (obj->guard_code == obj)) {
		lock = me_mutex_trylock_arch(&obj->arch_param);
	}

	return (lock);
}

void me_mutex_unlock(me_mutex_t *obj)
{
	if ((obj != NULL) && (obj->guard_code == obj)) {
		me_mutex_unlock_arch(&obj->arch_param);
	}
}


/* ####### File End ###### */
/** @} */

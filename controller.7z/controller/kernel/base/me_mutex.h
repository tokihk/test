/* ###################################################################### *//**
 *
 *	@addtogroup	Kernel
 *	@{
 *	@file		me_mutex.h
 *	@brief		Mutex Module
 *	@author		Copyright (C) 2019 Hitoshi Kouno
 *
*//* ####################################################################### */
#ifndef ME_MUTEX_H_
#define ME_MUTEX_H_

#include "kernel/me_kernel.h"

#include "kernel/base/me_mutex_arch.h"


typedef struct me_mutex
{
	void *					guard_code;
	me_mutex_arch_t			arch_param;
} me_mutex_t;


me_bool_t			me_mutex_initialize(me_mutex_t *obj);
void				me_mutex_finalize(me_mutex_t *obj);

void				me_mutex_lock(me_mutex_t *obj);
me_bool_t			me_mutex_trylock(me_mutex_t *obj);

void				me_mutex_unlock(me_mutex_t *obj);


#endif /* ME_MUTEX_H_ */
/* ####### File End ###### */
/** @} */

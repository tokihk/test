#ifndef ME_STRING_H_
#define ME_STRING_H_

#include "kernel/me_kernel.h"

#include <stdarg.h>


typedef struct me_string
{
	me_uint16_t		attr;
	me_size_t		length_max;
	me_size_t		length_use;
	me_char_t *		value;
} me_string_t;


me_size_t				me_strlen(const me_char_t *str);
me_size_t				me_stralen(const me_achar_t *str);
me_size_t				me_strwlen(const me_wchar_t *str);

void					me_strcpy(me_char_t *dst, const me_char_t *src);
void					me_strcpyn(me_char_t *dst, const me_char_t *src, me_size_t len);

void					me_stratow(me_wchar_t *dst, const me_achar_t *src);
void					me_stratown(me_wchar_t *dst, const me_achar_t *src, me_size_t len);

void					me_strwtoa(me_achar_t *dst, const me_wchar_t *src);
void					me_strwtoan(me_achar_t *dst, const me_wchar_t *src, me_size_t len);

void					me_stratoc(me_char_t *dst, const me_achar_t *src);
void					me_stratocn(me_char_t *dst, const me_achar_t *src, me_size_t len);

void					me_strwtoc(me_char_t *dst, const me_wchar_t *src);
void					me_strwtocn(me_char_t *dst, const me_wchar_t *src, me_size_t len);

void					me_strctoa(me_achar_t *dst, const me_char_t *src);
void					me_strctoan(me_achar_t *dst, const me_char_t *src, me_size_t len);

void					me_strctow(me_wchar_t *dst, const me_char_t *src);
void					me_strctown(me_wchar_t *dst, const me_char_t *src, me_size_t len);

me_string_t *			me_string_new(const me_char_t *text);
me_string_t *			me_string_new_limit(me_uint32_t length_max);
me_string_t *			me_string_new_placement(me_uint8_t *ram, me_uint16_t ram_size);

void					me_string_delete(me_string_t *obj);

me_uint16_t				me_string_length(const me_string_t *obj);

const me_char_t *		me_string_c_str(const me_string_t *obj);

me_char_t				me_string_get_at(const me_string_t *obj, me_uint16_t pos);
void					me_string_set_at(me_string_t *obj, me_uint16_t pos, me_char_t value);

void					me_string_clear(me_string_t *obj);

me_int8_t				me_string_compare(const me_string_t *obj1, const me_string_t *obj2);

void					me_string_assign(me_string_t *obj, const me_string_t *str);
void					me_string_assign_text(me_string_t *obj, const me_char_t *text, me_uint16_t size);
void					me_string_assign_format(me_string_t *obj, const me_char_t *format, ... );
void					me_string_assign_vformat(me_string_t *obj, const me_char_t *format, va_list args);

void					me_string_append(me_string_t *obj, const me_string_t *str);
void					me_string_append_char(me_string_t *obj, me_char_t value);
void					me_string_append_text(me_string_t *obj, const me_char_t *text, me_uint16_t size);
void					me_string_append_format(me_string_t *obj, const me_char_t *format, ... );
void					me_string_append_vformat(me_string_t *obj, const me_char_t *format, va_list args);

me_uint16_t				me_string_find_last_of(const me_string_t *obj, const me_char_t *text, me_uint16_t pos);

#endif

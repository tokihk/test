/* ###################################################################### *//**
 *
 *	@addtogroup	Base
 *	@{
 *	@file		ic_syslog.c
 *	@brief		Syslog
 *	@author		Copyright (C) 2019 Hitoshi Kouno
 *
*//* ####################################################################### */

#include "me_syslog.h"


#define ME_SYSLOG_OUTPUT_BUFFER_SIZE		(1152)
#define ME_SYSLOG_TCP_CLOSE_DELAY			(2000)


static const me_uint8_t me_syslog_utf8_bom[] = { 0xEF, 0xBB, 0xBF };



#if 0
static const me_char_t *me_syslog_month_code[] = {
	"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
};
#endif

#if 0
static void me_syslog_file_output(me_syslog_t *obj, const me_uint8_t *data, me_uint16_t size)
{
	me_file_t *file;

	file = me_file_open(obj->profile.file.path, IC_FILE_READWRITE_ADD);
	if (file != NULL) {
		me_file_write(file, data, size);
		me_file_close(file);
	}
}
#endif

#if 0
static void me_syslog_tcp_client_output(me_syslog_t *obj, const me_uint8_t *data, me_uint16_t size)
{
	if (obj->tcp_client.obj == NULL) {
		IC_TRAP_PTR_ERROR(obj->tcp_client.obj = me_tcp_client_new(&obj->profile.tcp_client.remote));
	}

	if (obj->tcp_client.obj != NULL) {
		me_tcp_client_send(obj->tcp_client.obj, data, size);
		obj->tcp_client.last_send_time = me_clock_time_msec();
	}
}
#endif

#if 0
static void me_syslog_tcp_client_poll(me_syslog_t *obj)
{
	if (obj->tcp_client.obj != NULL) {
		if (   (!me_tcp_client_send_is_busy(obj->tcp_client.obj))
			&& (me_clock_elapsed_msec(obj->tcp_client.last_send_time) >= IC_SYSLOG_TCP_CLOSE_DELAY)
		) {
			/* 送信が完了していれば閉じる */
			me_tcp_client_delete(obj->tcp_client.obj);
			obj->tcp_client.obj = NULL;
		}
	}
}
#endif

static void me_syslog_setup_header(me_string_t *obj, enum en_me_syslog_facility fac, enum en_me_syslog_severity sev)
{
	me_datetime_t dt;

	if (me_datetime_utc_time_get(&dt)) {
#if 0
		/* RFC 3164 */
		/* <Code> Jan  1 00:00:00 app_name: 2016-01-01T00:00:00.000 MSG */
		me_string_append_format(
			obj,
			"<%d> %s %2d %02d:%02d:%02d %s: %02d-%02d-%02dT%02d:%02d:%02d.%03d ",
			(me_uint16_t)fac * 8 + (me_uint16_t)sev,
			me_syslog_month_code[dt.month], dt.day, dt.hour, dt.min, dt.sec,
			IC_SPEC_OBJECT_NAME,
			dt.year, dt.month, dt.day, dt.hour, dt.min, dt.sec, dt.msec);
#else
		/* RFC 5424 (https://tools.ietf.org/html/rfc5424) */
		/* <PRI>VERSION TIMESTAMP HOSTNAME APP-NAME - MSGID - MSG */
		/* <PRI>1 2016-01-23T01:23:45.678Z ICOM nx-3761-app-main - NX-3761 - BOMmessage */
		me_string_append_format(
			obj,
			"<%d>1 %04d-%02d-%02dT%02d:%02d:%02d.%03dZ ICOM %s - %s - ",
			(me_uint16_t)fac * 8 + (me_uint16_t)sev,
			dt.year, dt.month, dt.day, dt.hour, dt.min, dt.sec, dt.msec,
			IC_SPEC_OBJECT_NAME,
			IC_SPEC_MACHINE_NAME);

		me_string_append_text(obj, (me_char_t *)me_syslog_utf8_bom, me_countof(me_syslog_utf8_bom));

#endif
	}
}

static void me_syslog_setup_footer(me_string_t *obj)
{
	me_string_append_char(obj, '\n');
}

static void me_syslog_output_exec(me_syslog_t *obj, enum en_me_syslog_severity sev, const me_string_t *str)
{
	/* 標準出力 */
	if (   (me_has_flag(obj->profile.target, SyslogTargetFlag_Stdout))
		&& (sev <= obj->profile.std_out.filter)
	) {
		me_system_stdout_format(me_string_c_str(str));
	}

	/* 標準エラー出力 */
	if (   (me_has_flag(obj->profile.target, SyslogTargetFlag_Stderr))
		&& (sev <= obj->profile.std_err.filter)
	) {
		me_system_stderr_format(me_string_c_str(str));
	}

	/* ファイル出力 */
	if (   (me_has_flag(obj->profile.target, SyslogTargetFlag_File))
		&& (sev <= obj->profile.file.filter)
	) {
		me_syslog_file_output(obj, (me_uint8_t *)me_string_c_str(str), me_string_length(str));
	}

	/* UDP Client出力 */
	if (   (me_has_flag(obj->profile.target, SyslogTargetFlag_UdpClient))
		&& (sev <= obj->profile.udp_client.filter)
	) {
		/* 最後のNUL文字まで出力 */
		me_udp_client_send(obj->udp_client.obj, (me_uint8_t *)me_string_c_str(str), me_string_length(str) + 1, &obj->profile.udp_client.remote);
	}

	/* TCP Client出力 */
	if (   (me_has_flag(obj->profile.target, SyslogTargetFlag_TcpClient))
		&& (sev <= obj->profile.tcp_client.filter)
	) {
		/* 最後のNUL文字まで出力 */
		me_syslog_tcp_client_output(obj, (me_uint8_t *)me_string_c_str(str), me_string_length(str) + 1);
	}
}

me_syslog_t *me_syslog_new(const me_syslog_profile_t *profile)
{
	me_syslog_t *obj = NULL;
	me_bool_t error = IC_FALSE;

	if (profile != NULL) {
		IC_TRAP_PTR_ERROR_SET(obj = me_malloc_base(sizeof(*obj)), error);
		if (obj != NULL) {
			obj->profile = *profile;
			obj->mtx_output = me_mutex_new();

			/* UDP Client Setup */
			if (me_has_flag(obj->profile.target, SyslogTargetFlag_UdpClient)) {
				IC_EVENT_OUT_MESSAGE("Syslog UDP Enable");
				IC_TRAP_PTR_ERROR_SET(obj->udp_client.obj = me_udp_client_new(IC_IPDOMAIN_TYPE_IPV4, NULL), error);
			}

			/* TCP Client Setup */
			if (me_has_flag(obj->profile.target, SyslogTargetFlag_TcpClient)) {
				IC_EVENT_OUT_MESSAGE("Syslog TCP Enable");
			}
		}
	}

	/* === エラー処理 === */
	if (error) {
		me_syslog_delete(obj);
		obj = NULL;
	}

	return (obj);
}

void me_syslog_delete(me_syslog_t *obj)
{
	if (obj != NULL) {
		me_mutex_delete(obj->mtx_output);
		me_udp_client_delete(obj->udp_client.obj);
		me_tcp_client_delete(obj->tcp_client.obj);

		me_free_base(obj);
	}
}

void me_syslog_poll(me_syslog_t *obj)
{
	if (obj != NULL) {
		me_syslog_tcp_client_poll(obj);
	}
}

void me_syslog_output_format(me_syslog_t *obj, enum en_me_syslog_facility fac, enum en_me_syslog_severity sev, const me_char_t *format, ... )
{
	if (obj != NULL) {
		va_list args = {0};

		/* --- 可変引数初期化 --- */
		va_start(args, format);

		/* --- 処理開始 --- */
		me_syslog_output_vformat(obj, fac, sev, format, args);

		/* --- 可変引数終了 --- */
		va_end(args);
	}
}

void me_syslog_output_vformat(me_syslog_t *obj, enum en_me_syslog_facility fac, enum en_me_syslog_severity sev, const me_char_t *format, va_list args)
{
	if (obj != NULL) {
		me_uint8_t str_buffer[IC_SYSLOG_OUTPUT_BUFFER_SIZE];
		me_string_t *str;

		str = me_string_new_placement(str_buffer, sizeof(str_buffer));
		if (str != NULL) {
			/* ヘッダー追加 */
			me_syslog_setup_header(str, fac, sev);

			/* メッセージ追加 */
			me_string_append_vformat(str, format, args);

			/* フッター追加 */
			me_syslog_setup_footer(str);

			/* Syslog出力 */
			me_syslog_output_exec(obj, sev, str);

			me_string_delete(str);
		}
	}
}

/* ####### File End ###### */
/** @} */

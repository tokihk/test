/* ###################################################################### *//**
 *
 *	@addtogroup	Kernel
 *	@{
 *	@file		me_path.h
 *	@brief		Path Module
 *	@author		Copyright (C) 2019 Hitoshi Kouno
 *
*//* ####################################################################### */
#ifndef ME_PATH_H_
#define ME_PATH_H_

#include "kernel/me_kernel.h"


typedef struct me_path
{
	me_char_t		value[ME_PATH_LENGTH_MAX];
} me_path_t;


const me_char_t *		me_path_text(const me_path_t *obj);

void					me_path_clear(me_path_t *obj);

me_bool_t				me_path_assign(me_path_t *obj, const me_char_t *path);


#endif /* ME_PATH_H_ */
/* ####### File End ###### */
/** @} */

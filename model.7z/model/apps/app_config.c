#include "app_config.h"

#include "kernel/fs/me_path.h"

#include <string.h>


static const struct app_config_table_system APP_CONFIG_TABLE_SYSTEM_DEFAULT =
{
	.syslog_output_path = { ME_TEXT( ME_PATH( "/tmp/model-app-log.log" ) ) },
	.syslog_fac         = MeSyslogFacility_Local0,
};


static struct app_config
{
	struct app_config_table_system		cfg_system;
} g_app_config;


void app_config_initialize(void)
{
	g_app_config.cfg_system = APP_CONFIG_TABLE_SYSTEM_DEFAULT;
}

void app_config_finalize(void)
{
}

const struct app_config_table_system *app_config_system_ref(void)
{
	return (&g_app_config.cfg_system);
}

me_bool_t app_config_system_get_base(me_size_t offset, me_size_t size, void *value)
{
	me_bool_t get_ok = ME_FALSE;

	if ((size > 0) && (offset + size < sizeof(g_app_config.cfg_system)) && (value != NULL)) {
		memcpy(value, (me_uint8_t *)&g_app_config.cfg_system + offset, size);
	}

	return (get_ok);
}

me_bool_t app_config_system_set_base(me_size_t offset, me_size_t size, const void *value)
{
	me_bool_t set_ok = ME_FALSE;

	if ((size > 0) && (offset + size < sizeof(g_app_config.cfg_system)) && (value != NULL)) {
		memcpy((me_uint8_t *)&g_app_config.cfg_system + offset, value, size);
	}

	return (set_ok);
}


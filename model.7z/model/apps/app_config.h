#ifndef APP_CONFIG_H_
#define APP_CONFIG_H_

#include "kernel/me_kernel.h"

#include "apps/app_config_table.h"


void										app_config_initialize(void);
void										app_config_finalize(void);

const struct app_config_table_system *		app_config_system_ref(void);

#define app_config_system_get(name,value)	app_config_system_get_base(ME_OFFSETOF(struct app_config_table_system,name),ME_MEMBER_SIZEOF(struct app_config_table_system,name),value)
me_bool_t									app_config_system_get_base(me_size_t offset, me_size_t size, void *value);

#define app_config_system_set(name,value)	app_config_system_set_base(ME_OFFSETOF(struct app_config_table_system,name),ME_MEMBER_SIZEOF(struct app_config_table_system,name),value)
me_bool_t									app_config_system_set_base(me_size_t offset, me_size_t size, const void *value);


#endif

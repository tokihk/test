#ifndef APP_CONFIG_TABLE_H_
#define APP_CONFIG_TABLE_H_

#include "kernel/me_kernel.h"

#include "kernel/ext/me_syslog.h"

#include "kernel/fs/me_path.h"


	struct app_config_table_system
	{
		me_path_t					syslog_output_path;
		enum me_syslog_facility		syslog_fac;
	};


#endif

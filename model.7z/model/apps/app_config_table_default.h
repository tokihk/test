#ifndef APP_CONFIG_TABLE_H_
#define APP_CONFIG_TABLE_H_

#include "kernel/me_kernel.h"

#include "apps/app_config_table.h"


#endif

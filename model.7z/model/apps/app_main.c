#include "app_main.h"
#include "app_config.h"

#include "apps/unit_test/unit_test.h"
#include "apps/logic-analyzer/logic_analyzer.h"

#include "kernel/base/me_main_system.h"
#include "kernel/base/me_task.h"


#define APP_MAIN_TASK_IVAL			(10)


static struct app_main
{
	me_module_manager_t		mod_mgr;
	me_syslog_t				syslog_mgr;

	me_task_t				task_main;

	me_bool_t				exit_req;
	me_bool_t				exit_status;
} g_app_main;


#if defined(XENV_MODE_UNIT_TEST)

static const me_module_profile_t MOD_MAIN_APP[] =
{
	{
		.callback_init    = unit_test_init,
		.callback_exit    = unit_test_exit,
		.callback_poll    = unit_test_poll,
		.polling_interval = 0,
	}
};

#else

static const me_module_profile_t MOD_MAIN_APP[] =
{
	{
		.callback_init    = logic_analyzer_init,
		.callback_exit    = logic_analyzer_exit,
		.callback_poll    = logic_analyzer_poll,
		.polling_interval = 0,
	},
};

#endif

static me_bool_t app_main_initialize(void)
{
	struct me_syslog_profile syslog_profile = {0};
	me_size_t index;

	app_config_initialize();

	/* Syslog開始 */
//	syslog_profile.target_flags = MeSyslogTarget_Stdout | MeSyslogTarget_File;
	syslog_profile.enable_severity_level = MeSyslogSeverity_Debug;
	syslog_profile.file.output_path = app_config_system_ref()->syslog_output_path;

	me_syslog_initialize(&g_app_main.syslog_mgr, &syslog_profile);

	me_module_manager_initialize(&g_app_main.mod_mgr);

	/* メインアプリケーション登録 */
	for (index = 0; index < ME_COUNTOF(MOD_MAIN_APP); index++) {
		me_module_register(&g_app_main.mod_mgr, &MOD_MAIN_APP[index]);
	}

	app_output_log(MeSyslogSeverity_Information, ME_TEXT("System Startup"));

	return (ME_TRUE);
}

static void app_main_finalize(void)
{
	/* アプリケーション停止 */
	me_module_manager_finalize(&g_app_main.mod_mgr);

	app_output_log(MeSyslogSeverity_Information, ME_TEXT("System Shutdown"));

	/* 溜まっているログをすべて出力 */
	while (me_syslog_is_busy(&g_app_main.syslog_mgr)) {
		me_syslog_poll(&g_app_main.syslog_mgr);
	}

	me_syslog_finalize(&g_app_main.syslog_mgr);

	app_config_finalize();
}

static void app_main_exec(void)
{
	while (!g_app_main.exit_req) {
		me_module_manager_poll(&g_app_main.mod_mgr);

		me_syslog_poll(&g_app_main.syslog_mgr);

		me_task_sleep(APP_MAIN_TASK_IVAL);
	}
}

static void app_main_task(me_task_t *obj, void *param)
{
	app_main_initialize();

	app_main_exec();

	app_main_finalize();

	g_app_main.exit_status = ME_TRUE;

	/* !!! メインループを停止させない !!! */
	for (;;) { me_task_sleep(1000); }
}

void app_output_log(enum me_syslog_severity sev, const me_char_t *format, ... )
{
	if (format != NULL) {
		va_list args = {0};

		/* 可変引数初期化 */
		va_start(args, format);

		/* 処理開始 */
		me_syslog_output_vformat(
				&g_app_main.syslog_mgr,
				app_config_system_ref()->syslog_fac,
				sev,
				format,
				args);

		/* 可変引数終了 */
		va_end(args);
	}
}

void me_system_on_signal(enum me_signal_type signal)
{
	g_app_main.exit_req = ME_TRUE;
}

me_int8_t me_system_main(me_int32_t argc, const me_achar_t *argv[])
{
	me_int8_t exit_code = 0;

	UNREFERENCED_PARAMETER(argc);
	UNREFERENCED_PARAMETER(argv);

	me_task_scheduler_initialize();

	/* メインタスク登録 */
	me_task_create(&g_app_main.task_main, 0, 0, app_main_task, NULL);

	me_task_scheduler_exec();

	me_task_scheduler_finalize();

	return (exit_code);
}


#include "app_main.h"
#include "app_config.h"

#include "apps/unit_test/unit_test.h"
#include "apps/hresvelgr/hresvelgr.h"

#include "kernel/base/me_main_system.h"


static struct app_main
{
	me_module_manager_t		mod_mgr;
	me_syslog_t				syslog_mgr;
	me_bool_t				exit_req;
} g_app_main;


#if defined(XENV_MODE_UNIT_TEST)

static const me_module_profile_t mod_main_app =
{
	.callback_init    = unit_test_init,
	.callback_exit    = unit_test_exit,
	.callback_poll    = unit_test_poll,
	.polling_interval = 0,
};

#else

static const me_module_profile_t mod_main_app =
{
	.callback_init    = hresvelgr_init,
	.callback_exit    = hresvelgr_exit,
	.callback_poll    = hresvelgr_poll,
	.polling_interval = 0,
};

#endif

void app_output_log(enum me_syslog_severity sev, const me_char_t *format, ... )
{
	if (format != NULL) {
		va_list args = {0};

		/* 可変引数初期化 */
		va_start(args, format);

		/* 処理開始 */
		me_syslog_output_vformat(
				&g_app_main.syslog_mgr,
				app_config_system_ref()->syslog_fac,
				sev,
				format,
				args);

		/* 可変引数終了 */
		va_end(args);
	}
}

void me_system_on_signal(enum me_signal_type signal)
{
	g_app_main.exit_req = ME_TRUE;
}

static me_bool_t app_initialize(void)
{
	struct me_syslog_profile profile;

	app_config_initialize();

	profile.target_flags = MeSyslogTarget_File;
	profile.enable_severity_level = MeSyslogSeverity_Debug;
	profile.file.output_path = app_config_system_ref()->syslog_output_path;

	me_syslog_initialize(&g_app_main.syslog_mgr, &profile);

	me_module_manager_initialize(&g_app_main.mod_mgr);

	/* メインアプリケーション登録 */
	me_module_register(&g_app_main.mod_mgr, &mod_main_app);

	app_output_log(MeSyslogSeverity_Information, ME_TEXT("System Startup"));

	return (ME_TRUE);
}

static void app_finalize(void)
{
	/* アプリケーション停止 */
	me_module_manager_finalize(&g_app_main.mod_mgr);

	app_output_log(MeSyslogSeverity_Information, ME_TEXT("System Shutdown"));

	me_syslog_finalize(&g_app_main.syslog_mgr);

	app_config_finalize();
}

static void app_poll(void)
{
	while (!g_app_main.exit_req) {
		me_module_manager_poll(&g_app_main.mod_mgr);
	}
}

me_int8_t me_system_main(me_int32_t argc, const me_achar_t *argv[])
{
	me_int8_t exit_code = 0;

	UNREFERENCED_PARAMETER(argc);
	UNREFERENCED_PARAMETER(argv);

	app_initialize();

	/* アプリケーション実行 */
	app_poll();

	app_finalize();

	return (exit_code);
}


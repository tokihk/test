#ifndef APP_MAIN_H_
#define APP_MAIN_H_

#include "kernel/ext/me_syslog.h"


void			app_output_log(enum me_syslog_severity sev, const me_char_t *format, ... );

void			app_work_path_get(const me_char_t *path);


#endif

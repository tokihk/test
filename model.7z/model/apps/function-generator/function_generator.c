#include "function_generator.h"


me_bool_t function_generator_init(me_module_t *obj)
{


	return (ME_TRUE);
}

void function_generator_exit(me_module_t *obj, enum me_module_exit_reason reason, me_int32_t exit_code)
{
}

void function_generator_poll(me_module_t *obj)
{
}

#include "hresvelgr.h"


me_bool_t hresvelgr_init(me_module_t *obj)
{



	return (ME_TRUE);
}

void hresvelgr_exit(me_module_t *obj, enum me_module_exit_reason reason, me_int32_t exit_code)
{
}

void hresvelgr_poll(me_module_t *obj)
{
}

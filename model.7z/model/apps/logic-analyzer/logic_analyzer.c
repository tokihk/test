#include "logic_analyzer.h"

#include "../../kernel/devices/me_gpio.h"
#include "../../kernel/devices/me_timer.h"
#include "kernel/base/me_task.h"

#include "apps/app_main.h"


static struct logic_analyzer
{
	me_task_t			task_main;

	me_bool_t			debug_out;
} g_logic_analyzer;


void logic_analyzer_sampling_timer_event(me_uint16_t tmr_id)
{
	app_output_log(MeSyslogSeverity_Debug, ME_TEXT("me_timer_isr=%d"), tmr_id);

	me_gpio_value_set(0, g_logic_analyzer.debug_out);
   	g_logic_analyzer.debug_out = !g_logic_analyzer.debug_out;
}

me_bool_t logic_analyzer_init(me_module_t *obj)
{
	me_gpio_initialize();

	me_gpio_direction_set(0, 1);

	me_timer_create(0, 100000, logic_analyzer_sampling_timer_event);
//	me_timer_create(0, 50000, logic_analyzer_sampling_timer_event);

	return (ME_TRUE);
}

void logic_analyzer_exit(me_module_t *obj, enum me_module_exit_reason reason, me_int32_t exit_code)
{
}

void logic_analyzer_poll(me_module_t *obj)
{
}

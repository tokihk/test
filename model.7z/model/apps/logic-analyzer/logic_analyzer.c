#include "logic_analyzer.h"

#include "kernel/base/me_task.h"

#include "kernel/dev/me_dev_timer.h"

#include "apps/app_main.h"


static struct logic_analyzer
{
	me_task_t			task_main;
} g_logic_analyzer;


void me_dev_timer_isr(me_uint16_t tmr_id)
{
	app_output_log(MeSyslogSeverity_Debug, ME_TEXT("me_dev_timer_isr=%d"), tmr_id);
}

me_bool_t logic_analyzer_init(me_module_t *obj)
{
	me_dev_timer_create(0, 200);

	return (ME_TRUE);
}

void logic_analyzer_exit(me_module_t *obj, enum me_module_exit_reason reason, me_int32_t exit_code)
{
}

void logic_analyzer_poll(me_module_t *obj)
{
}

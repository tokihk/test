#ifndef LOGIC_ANALYZER_H_
#define LOGIC_ANALYZER_H_

#include "kernel/me_kernel.h"

#include "kernel/base/me_module.h"


me_bool_t						logic_analyzer_init(me_module_t *obj);
void							logic_analyzer_exit(me_module_t *obj, enum me_module_exit_reason reason, me_int32_t exit_code);
void							logic_analyzer_poll(me_module_t *obj);


#endif

#ifndef HRESVELGR_H_
#define HRESVELGR_H_

#include "kernel/me_kernel.h"

#include "kernel/base/me_module.h"


me_bool_t						oscilloscope_init(me_module_t *obj);
void							oscilloscope_exit(me_module_t *obj, enum me_module_exit_reason reason, me_int32_t exit_code);
void							oscilloscope_poll(me_module_t *obj);


#endif

#include "unit_test.h"
#include "unit_test_kernel.h"


me_bool_t unit_test_init(me_module_t *obj)
{
	return (ME_TRUE);
}

void unit_test_exit(me_module_t *obj, me_int32_t exit_code)
{
}

void unit_test_poll(me_module_t *obj)
{
	unit_test_kernel();

	me_module_exit(obj, 0);
}

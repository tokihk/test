#include "unit_test.h"
#include "unit_test_kernel.h"

#include "kernel/base/me_main_system.h"

#include "unity.h"
#include "unity_fixture.h"


static void unit_test_run_all(void)
{
	unit_test_kernel();
}

me_bool_t unit_test_init(me_module_t *obj)
{
	return (ME_TRUE);
}

void unit_test_exit(me_module_t *obj, enum me_module_exit_reason reason, me_int32_t exit_code)
{
}

void unit_test_poll(me_module_t *obj)
{
	UnityMain( me_system_startup_argument_count(), me_system_startup_argument_value(), unit_test_run_all );

	fflush(stdout);
	fflush(stderr);

	me_module_exit(obj, 0);
}

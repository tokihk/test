#ifndef UNIT_TEST_H_
#define UNIT_TEST_H_

#include "kernel/me_kernel.h"

#include "kernel/base/me_module.h"


me_bool_t						unit_test_init(me_module_t *obj);
void							unit_test_exit(me_module_t *obj, me_int32_t exit_code);
void							unit_test_poll(me_module_t *obj);


#endif

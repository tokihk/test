#include "unit_test_kernel.h"

#include "unit_test_kernel_heap_memory.h"
#include "unit_test_kernel_string.h"
#include "unit_test_kernel_syslog.h"

#include "unity.h"
#include "unity_fixture.h"


void unit_test_kernel(void)
{
	unit_test_kernel_heap_memory();
	unit_test_kernel_string();
	unit_test_kernel_syslog();
}

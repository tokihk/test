#include "unit_test_kernel.h"

#include "kernel/base/me_heap_memory.h"

#include <stdarg.h>
#include <stddef.h>
#include <setjmp.h>
#include <stdio.h>

#include "cmockery.h"


static struct unit_test_kernel_
{
	me_uint8_t				test_ram_0[1027];
} unit_test_kernel_g;


static void unit_test_kernel_memory_base(void **state, me_uint8_t *ram_addr, me_size_t ram_size)
{
	me_heap_manager_t *		test_mgr;
	void *					test_ptr_0;
	void *					test_ptr_1;
	void *					test_ptr_2;
	void *					test_ptr_3;

	/* マーネージャー初期化確認 */
	test_mgr = me_heap_initialize(ram_addr, ram_size);
	assert_true(test_mgr != NULL);

	/* 再確保したときに同じアドレスが返されるか */
	{
		test_ptr_0 = me_heap_malloc(test_mgr, 128);
		assert_true(test_ptr_0 != NULL);

		test_ptr_1 = me_heap_malloc(test_mgr, 128);
		assert_true(test_ptr_1 != NULL);

		test_ptr_2 = me_heap_malloc(test_mgr, 128);
		assert_true(test_ptr_2 != NULL);

		/* test_ptr_0の場所の再確保を確認 */
		me_heap_free(test_mgr, test_ptr_0);

		test_ptr_3 = me_heap_malloc(test_mgr, 128);
		assert_true(test_ptr_0 == test_ptr_3);

		test_ptr_0 = test_ptr_3;

		/* test_ptr_1の場所の再確保を確認 */
		me_heap_free(test_mgr, test_ptr_1);

		test_ptr_3 = me_heap_malloc(test_mgr, 128);
		assert_true(test_ptr_1 == test_ptr_3);

		test_ptr_1 = test_ptr_3;

		/* test_ptr_2の場所の再確保を確認 */
		me_heap_free(test_mgr, test_ptr_2);

		test_ptr_3 = me_heap_malloc(test_mgr, 128);
		assert_true(test_ptr_2 == test_ptr_3);

		test_ptr_2 = test_ptr_3;

		me_heap_free(test_mgr, test_ptr_0);
		me_heap_free(test_mgr, test_ptr_1);
		me_heap_free(test_mgr, test_ptr_2);
	}

	me_heap_finalize(test_mgr);
}

static void unit_test_kernel_memory(void **state)
{
	unit_test_kernel_memory_base(state, unit_test_kernel_g.test_ram_0, sizeof(unit_test_kernel_g.test_ram_0));
}


me_bool_t unit_test_kernel(void)
{
	const UnitTest tests[] = {
		unit_test(unit_test_kernel_memory),
	};

	me_int32_t result;

	result = run_tests(tests);

	fflush(stdout);

	return (ME_TRUE);
}

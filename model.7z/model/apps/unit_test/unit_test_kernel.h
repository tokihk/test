#ifndef UNIT_TEST_KERNEL_H_
#define UNIT_TEST_KERNEL_H_

#include "kernel/me_kernel.h"

#include "kernel/base/me_module.h"


me_bool_t				unit_test_kernel(void);


#endif

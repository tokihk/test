#ifndef UNIT_TEST_KERNEL_H_
#define UNIT_TEST_KERNEL_H_

#include "kernel/me_kernel.h"


void					unit_test_kernel(void);


#endif

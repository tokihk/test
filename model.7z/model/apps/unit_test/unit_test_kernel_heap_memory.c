#include "kernel/base/me_heap_memory.h"

#include "unity.h"
#include "unity_fixture.h"


static struct unit_test_kernel_heap_memory
{
	me_heap_manager_t *		test_mgr;
	me_uint8_t				test_ram[1024];
} g_unit_test_kernel_heap_memory;


#define TEST_MANAGER g_unit_test_kernel_heap_memory.test_mgr


TEST_GROUP( kernel_heap_memory );

TEST_SETUP( kernel_heap_memory )
{
	TEST_ASSERT_NOT_NULL(TEST_MANAGER = me_heap_initialize(g_unit_test_kernel_heap_memory.test_ram, sizeof(g_unit_test_kernel_heap_memory.test_ram)));
}

TEST_TEAR_DOWN( kernel_heap_memory )
{
	me_heap_finalize(TEST_MANAGER);

	fflush(stdout);
	fflush(stderr);
}

TEST( kernel_heap_memory, basic )
{
	void *					test_ptr_0;
	void *					test_ptr_1;
	void *					test_ptr_2;
	void *					test_ptr_3;

	/* 再確保したときに同じアドレスが返されるか */
	TEST_ASSERT_NOT_NULL(test_ptr_0 = me_heap_malloc(TEST_MANAGER, 128));

	TEST_ASSERT_NOT_NULL(test_ptr_1 = me_heap_malloc(TEST_MANAGER, 128));

	TEST_ASSERT_NOT_NULL(test_ptr_2 = me_heap_malloc(TEST_MANAGER, 128));

	/* test_ptr_0の場所の再確保を確認 */
	me_heap_free(TEST_MANAGER, test_ptr_0);

	TEST_ASSERT_NOT_NULL(test_ptr_3 = me_heap_malloc(TEST_MANAGER, 128));
	TEST_ASSERT_EQUAL(test_ptr_0, test_ptr_3);

	test_ptr_0 = test_ptr_3;

	/* test_ptr_1の場所の再確保を確認 */
	me_heap_free(TEST_MANAGER, test_ptr_1);

	TEST_ASSERT_NOT_NULL(test_ptr_3 = me_heap_malloc(TEST_MANAGER, 128));
	TEST_ASSERT_EQUAL(test_ptr_1, test_ptr_3);

	test_ptr_1 = test_ptr_3;

	/* test_ptr_2の場所の再確保を確認 */
	me_heap_free(TEST_MANAGER, test_ptr_2);

	TEST_ASSERT_NOT_NULL(test_ptr_3 = me_heap_malloc(TEST_MANAGER, 128));
	TEST_ASSERT_EQUAL(test_ptr_2, test_ptr_3);

	test_ptr_2 = test_ptr_3;

	me_heap_free(TEST_MANAGER, test_ptr_0);
	me_heap_free(TEST_MANAGER, test_ptr_1);
	me_heap_free(TEST_MANAGER, test_ptr_2);
}

TEST_GROUP_RUNNER( kernel_heap_memory )
{
	RUN_TEST_CASE( kernel_heap_memory, basic );
}

void unit_test_kernel_heap_memory(void)
{
	RUN_TEST_GROUP( kernel_heap_memory );
}

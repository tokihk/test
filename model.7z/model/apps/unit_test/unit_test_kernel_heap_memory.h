#ifndef UNIT_TEST_KERNEL_HEAP_MEMORY_H_
#define UNIT_TEST_KERNEL_HEAP_MEMORY_H_

#include "kernel/me_kernel.h"


void				unit_test_kernel_heap_memory(void);


#endif

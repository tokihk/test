#include "unit_test_kernel.h"

#include "kernel/base/me_string.h"

#include "unity.h"
#include "unity_fixture.h"


static struct unit_test_kernel_string
{
	me_string_t				test_obj;
	me_uint8_t				test_ram[1024];
} g_unit_test_kernel_string;


#define TEST_OBJECT g_unit_test_kernel_string.test_obj


TEST_GROUP( kernel_string );

TEST_SETUP( kernel_string )
{
	TEST_ASSERT_TRUE(
		me_string_initialize_placement(
			&TEST_OBJECT,
			&g_unit_test_kernel_string.test_ram[0],
			sizeof(g_unit_test_kernel_string.test_ram)));
}

TEST_TEAR_DOWN( kernel_string )
{
	me_string_finalize(&TEST_OBJECT);

	fflush(stdout);
	fflush(stderr);
}

TEST( kernel_string, me_string_assign )
{
	static const me_char_t TEST_PATTERN_0[] = ME_TEXT("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ");

	me_string_assign_text(&TEST_OBJECT, TEST_PATTERN_0, ME_COUNTOF(TEST_PATTERN_0));

	TEST_ASSERT_EQUAL_STRING(me_string_c_str(&TEST_OBJECT), TEST_PATTERN_0);

	TEST_ASSERT_EQUAL_INT(me_string_length(&TEST_OBJECT), ME_COUNTOF(TEST_PATTERN_0) - 1);
}

TEST_GROUP_RUNNER( kernel_string )
{
	RUN_TEST_CASE( kernel_string, me_string_assign );
}

void unit_test_kernel_string(void)
{
	RUN_TEST_GROUP( kernel_string );
}

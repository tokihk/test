#ifndef UNIT_TEST_KERNEL_STRING_H_
#define UNIT_TEST_KERNEL_STRING_H_

#include "kernel/me_kernel.h"


void				unit_test_kernel_string(void);


#endif

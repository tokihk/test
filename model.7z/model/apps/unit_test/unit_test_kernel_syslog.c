#include "unit_test_kernel.h"

#include "kernel/ext/me_syslog.h"

#include "unity.h"
#include "unity_fixture.h"


TEST_GROUP( kernel_syslog );

TEST_SETUP( kernel_syslog )
{
}

TEST_TEAR_DOWN( kernel_syslog )
{
	fflush(stdout);
	fflush(stderr);
}

TEST( kernel_syslog, basic )
{
	me_syslog_t obj = {0};
	struct me_syslog_profile profile = {0};

	profile.enable_severity_level = MeSyslogSeverity_Debug;
	profile.target_flags = MeSyslogTarget_File;

	me_path_initialize(&profile.file.output_path, ME_TEXT("./unit_test_kernel_syslog.txt"));

	TEST_ASSERT_TRUE(me_syslog_initialize(&obj, &profile));

	me_syslog_output_format(&obj, MeSyslogFacility_Local0, MeSyslogSeverity_Debug, ME_TEXT("Syslog Test 0"));
	me_syslog_output_format(&obj, MeSyslogFacility_Local0, MeSyslogSeverity_Debug, ME_TEXT("Syslog Test 1"));
	me_syslog_output_format(&obj, MeSyslogFacility_Local0, MeSyslogSeverity_Debug, ME_TEXT("Syslog Test 2"));
	me_syslog_output_format(&obj, MeSyslogFacility_Local0, MeSyslogSeverity_Debug, ME_TEXT("Syslog Test 3"));
	me_syslog_output_format(&obj, MeSyslogFacility_Local0, MeSyslogSeverity_Debug, ME_TEXT("Syslog Test 4"));

	me_syslog_finalize(&obj);
}

TEST_GROUP_RUNNER( kernel_syslog )
{
	RUN_TEST_CASE( kernel_syslog, basic );
}

void unit_test_kernel_syslog(void)
{
	RUN_TEST_GROUP( kernel_syslog );
}

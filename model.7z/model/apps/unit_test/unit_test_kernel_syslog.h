#ifndef UNIT_TEST_KERNEL_SYSLOG_H_
#define UNIT_TEST_KERNEL_SYSLOG_H_

#include "kernel/me_kernel.h"


void				unit_test_kernel_syslog(void);


#endif

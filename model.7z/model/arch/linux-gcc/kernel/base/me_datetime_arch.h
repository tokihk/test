/* ###################################################################### *//**
 *
 *	@addtogroup	Kernel
 *	@{
 *	@file		me_datetime_arch.h
 *	@brief		Datetime Module (for Linux GCC)
 *	@author		Copyright (C) 2019 Hitoshi Kouno
 *
*//* ####################################################################### */
#ifndef ME_DATETIME_ARCH_H_
#define ME_DATETIME_ARCH_H_

#include "kernel/me_kernel.h"

#include <time.h>


typedef struct me_epoch_time
{
	time_t			time_l;
} me_epoch_time_t;



#endif /* ME_MUTEX_ARCH_H_ */
/* ####### File End ###### */
/** @} */

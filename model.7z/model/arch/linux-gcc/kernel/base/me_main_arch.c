#include "kernel/base/me_kernel_main.h"

#include <signal.h>


static void on_signal_handler(int signo, siginfo_t *info, void *context)
{
	me_kernel_on_signal(ME_SIGNAL_TERM);
}


const struct sigaction sa_capture =
{
	.sa_sigaction = on_signal_handler,
	.sa_flags = SA_SIGINFO,
};


int main(int argc, char *argv[])
{
	me_int8_t exit_code = -1;

	if (sigaction(SIGTERM, &sa_capture, NULL) >= 0) {
		exit_code = me_kernel_main((me_int32_t)argc, (const me_achar_t **)argv);
	}

	return (exit_code);
}



#include "me_datetime_arch.h"

#include "chip.h"


void me_datetime_initialize_arch(void)
{

}

void me_datetime_finalize_arch(void)
{

}

me_bool_t me_datetime_now_arch(me_datetime_t *dt)
{
	me_bool_t success = ME_FALSE;

	if (dt != NULL) {
		if (me_datetime_now_utc_arch(dt)) {
//			success = ME_TRUE;
		}
	}

	return (success);
}

me_bool_t me_datetime_now_utc_arch(me_datetime_t *dt)
{
	me_bool_t success = ME_FALSE;

	if (dt != NULL) {
		RTC_TIME_T tm;

		Chip_RTC_GetFullTime(LPC_RTC, &tm);

		dt->year = tm.time[RTC_TIMETYPE_YEAR];
		dt->month = tm.time[RTC_TIMETYPE_MONTH];
		dt->day = tm.time[RTC_TIMETYPE_DAYOFMONTH];
		dt->hour = tm.time[RTC_TIMETYPE_HOUR];
		dt->min = tm.time[RTC_TIMETYPE_MINUTE];
		dt->sec = tm.time[RTC_TIMETYPE_SECOND];
		dt->msec = 0;

		success = ME_TRUE;
	}

	return (success);
}

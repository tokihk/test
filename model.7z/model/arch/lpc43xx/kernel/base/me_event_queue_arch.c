#include "kernel/base/me_event_queue_arch.h"


me_bool_t me_event_queue_create_arch(me_event_queue_arch_t *obj, me_size_t event_num_max)
{
	me_bool_t success = ME_FALSE;

	obj->handle = xQueueCreate(event_num_max, sizeof(me_uint16_t));
	if (obj != NULL) {
		success = ME_TRUE;
	}

	return (success);
}

void me_event_queue_destroy_arch(me_event_queue_arch_t *obj)
{
	vQueueDelete(obj->handle);
}

me_bool_t me_event_queue_send_arch(me_event_queue_arch_t *obj, me_uint16_t event_id)
{
	me_bool_t success = ME_FALSE;

	if (xQueueSendToBack(obj->handle, &event_id, 0)) {
		success = ME_TRUE;
	}

	return (success);
}

me_bool_t me_event_queue_send_isr_arch(me_event_queue_arch_t *obj, me_uint16_t event_id)
{
	me_bool_t success = ME_FALSE;

	if (xQueueSendToBackFromISR(obj->handle, &event_id, NULL) == pdPASS) {
		success = ME_TRUE;
	}

	return (success);
}

me_bool_t me_event_queue_recv_arch(me_event_queue_arch_t *obj, me_uint16_t *event_id, me_uint32_t timeout_msec)
{
	me_bool_t success = ME_FALSE;

	if (xQueueReceive(obj->handle, event_id, pdMS_TO_TICKS(timeout_msec))) {
		success = ME_TRUE;
	}

	return (success);
}

me_bool_t me_event_queue_recv_isr_arch(me_event_queue_arch_t *obj, me_uint16_t *event_id)
{
	me_bool_t success = ME_FALSE;

	if (xQueueReceiveFromISR(obj->handle, event_id, NULL)) {
		success = ME_TRUE;
	}

	return (success);
}

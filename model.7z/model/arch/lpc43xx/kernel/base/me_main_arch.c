#include "kernel/base/me_main_kernel.h"

#include "FreeRTOS.h"
#include "task.h"


static struct
{
} g_me_main_arch;


me_uint32_t me_system_tick_msec_get_arch(void)
{
	return ((me_uint32_t)xTaskGetTickCount());
}

me_size_t me_stdin_arch(me_uint8_t *buffer, me_size_t size)
{
	me_size_t read_size = 0;

	return (read_size);
}

me_size_t me_stdout_arch(const me_uint8_t *data, me_size_t size)
{
	me_size_t write_size = 0;

	return (write_size);
}

me_size_t me_stderr_arch(const me_uint8_t *data, me_size_t size)
{
	me_size_t write_size = 0;

	return (write_size);
}

me_int8_t me_main_arch(void)
{
	me_int8_t exit_code = -1;

	exit_code = me_kernel_main((me_int32_t)0, (const me_achar_t **)NULL);

	return (exit_code);
}



#include "kernel/base/me_main_kernel.h"

#include <signal.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <poll.h>
#include <time.h>


static struct me_main_arch
{
	int					pfd_stdin;
	int					pfd_stdout;
	int					pfd_stderr;
} g_me_main_arch;


static void on_signal_handler(int signo, siginfo_t *info, void *context)
{
//	me_kernel_on_signal(ME_SIGNAL_TERM);
}


static const struct sigaction sa_capture =
{
	.sa_sigaction = on_signal_handler,
	.sa_flags = SA_SIGINFO,
};


me_uint32_t me_system_tick_msec_get_arch(void)
{
	me_uint32_t tick_ms = 0;
	struct timespec tspec = {0};

	if (clock_gettime(CLOCK_REALTIME, &tspec) == 0) {
		tick_ms = (me_uint32_t)((me_uint64_t)tspec.tv_sec * 1000ul + (me_uint64_t)tspec.tv_nsec / 1000000ul);
	}

	return (tick_ms);
}

me_size_t me_stdin_arch(me_uint8_t *buffer, me_size_t size)
{
	me_size_t read_size = 0;
	struct pollfd pfd;
	int result;

	pfd.fd = g_me_main_arch.pfd_stdin;
	pfd.events = POLLIN | POLLPRI;

	while (   (read_size < size)
		   && (poll(&pfd, 1, 0) > 0)
	) {
		result = read(pfd.fd, buffer + read_size, 1);
		if (result > 0) {
			read_size += result;
		} else {
			break;
		}
	}

	return (read_size);
}

me_size_t me_stdout_arch(const me_uint8_t *data, me_size_t size)
{
	me_size_t write_size = 0;
	struct pollfd pfd;
	int result;

	pfd.fd = g_me_main_arch.pfd_stdout;
	pfd.events = POLLOUT | POLLERR | POLLHUP | POLLNVAL;

	while (   (write_size < size)
		   && (poll(&pfd, 1, 0) > 0)
	) {
		if (pfd.revents & POLLOUT) {
			result = write(pfd.fd, data + write_size, size - write_size);

			if (result > 0) {
				write_size += result;
			} else {
				break;
			}
		} else {
			break;
		}
	}

	if (write_size > 0) {
		fflush(stdout);
	}

	return (write_size);
}

me_size_t me_stderr_arch(const me_uint8_t *data, me_size_t size)
{
	me_size_t write_size = 0;
	struct pollfd pfd;
	int result;

	pfd.fd = g_me_main_arch.pfd_stderr;
	pfd.events = POLLOUT | POLLERR | POLLHUP | POLLNVAL;

	while (   (write_size < size)
		   && (poll(&pfd, 1, 0) > 0)
	) {
		if (pfd.revents & POLLOUT) {
			result = write(pfd.fd, data + write_size, size - write_size);

			if (result > 0) {
				write_size += result;
			} else {
				break;
			}
		} else {
			break;
		}
	}

	return (write_size);
}

int main(int argc, char *argv[])
{
	me_int8_t exit_code = -1;

	g_me_main_arch.pfd_stdin = fileno(stdin);
	g_me_main_arch.pfd_stdout = fileno(stdout);
	g_me_main_arch.pfd_stderr = fileno(stderr);

	if (sigaction(SIGTERM, &sa_capture, NULL) >= 0) {
		exit_code = me_kernel_main((me_int32_t)argc, (const me_achar_t **)argv);
	}

	return (exit_code);
}



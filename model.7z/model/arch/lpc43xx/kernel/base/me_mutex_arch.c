#include "me_mutex_arch.h"



me_bool_t me_mutex_initialize_arch(me_mutex_arch_t *obj)
{
	obj->mutex = xSemaphoreCreateMutex();

	return (ME_TOBOOL(obj->mutex != NULL));
}

void me_mutex_finalize_arch(me_mutex_arch_t *obj)
{
}

void me_mutex_lock_arch(me_mutex_arch_t *obj)
{
	xSemaphoreTake(obj->mutex, portMAX_DELAY);
}

me_bool_t me_mutex_trylock_arch(me_mutex_arch_t *obj)
{
	me_bool_t lock = ME_FALSE;

	if (xSemaphoreTake(obj->mutex, 0)) {
		lock = ME_TRUE;
	}

	return (lock);
}

void me_mutex_unlock_arch(me_mutex_arch_t *obj)
{
	xSemaphoreGive(obj->mutex);
}

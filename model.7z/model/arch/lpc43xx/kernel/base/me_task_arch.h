/* ###################################################################### *//**
 *
 *	@addtogroup	Kernel
 *	@{
 *	@file		me_task_arch.h
 *	@brief		Task Module
 *	@author		Copyright (C) 2019 Hitoshi Kouno
 *
*//* ####################################################################### */
#ifndef ME_TASK_ARCH_H_
#define ME_TASK_ARCH_H_

#include "kernel/me_kernel.h"

#if XENV_MODEN_FREERTOS
#include "FreeRTOS.h"
#include "task.h"
#endif

typedef struct me_task_arch
{
#if XENV_MODEN_FREERTOS
	xTaskHandle				task_handle;
#endif

	void					(* callback)(struct me_task_arch *, void *);
	void *					callback_param;
} me_task_arch_t;


me_bool_t				me_task_create_arch(me_task_arch_t *obj, me_uint8_t *stack_area, me_size_t stack_size, me_uint8_t priority, void (* callback)(struct me_task_arch *, void *), void *param);
void					me_task_destroy_arch(me_task_arch_t *obj);

void					me_task_suspend_arch(me_task_arch_t *obj);
void					me_task_resume_arch(me_task_arch_t *obj);

void					me_task_sleep_arch(me_uint32_t time_msec);


#endif /* ME_TASK_ARCH_H_ */
/* ####### File End ###### */
/** @} */

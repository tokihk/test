#include "me_core_arch.h"

#include "FreeRTOS.h"
#include "task.h"


static struct
{
} g_me_main_arch;


me_int8_t me_startup_arch(me_int8_t argc, me_achar_t **argv)
{
	me_int8_t ret = 0;

	ret = me_main(argc, argv);

	return (ret);
}

me_uint32_t me_systick_msec_get_arch(void)
{
	return ((me_uint32_t)xTaskGetTickCount());
}

me_size_t me_stdin_arch(me_uint8_t *buffer, me_size_t size)
{
	me_size_t read_size = 0;

	return (read_size);
}

me_size_t me_stdout_arch(const me_uint8_t *data, me_size_t size)
{
	me_size_t write_size = 0;

	return (write_size);
}

me_size_t me_stderr_arch(const me_uint8_t *data, me_size_t size)
{
	me_size_t write_size = 0;

	return (write_size);
}

#ifndef ME_CORE_ARCH_H_
#define ME_CORE_ARCH_H_

#include "kernel/core/me_stddef.h"


me_int8_t						me_startup_arch(me_int8_t argc, me_achar_t **argv);

me_uint32_t						me_systick_msec_get_arch(void);

me_size_t						me_stdin_arch(me_uint8_t *buffer, me_size_t size);

me_size_t						me_stdout_arch(const me_uint8_t *data, me_size_t size);

me_size_t						me_stderr_arch(const me_uint8_t *data, me_size_t size);


#endif

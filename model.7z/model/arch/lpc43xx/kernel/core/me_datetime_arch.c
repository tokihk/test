#include "me_datetime_arch.h"

#include "kernel/peripherals/me_rtc.h"

#include "chip.h"


void me_datetime_initialize_arch(void)
{
	me_rtc_initialize();
}

void me_datetime_finalize_arch(void)
{
	me_rtc_finalize();
}

me_bool_t me_datetime_now_arch(struct me_datetime *dt)
{
	me_bool_t success = ME_FALSE;

	if (dt != NULL) {
		if (me_datetime_now_utc_arch(dt)) {
			success = ME_TRUE;
		}
	}

	return (success);
}

me_bool_t me_datetime_now_utc_arch(struct me_datetime *dt)
{
	return (me_rtc_datetime_get(dt));
}

#include "me_mutex_arch.h"


me_bool_t me_mutex_create_arch(struct me_mutex_arch *obj)
{
	obj->handle = xSemaphoreCreateMutex();

	return (obj->handle != NULL);
}

void me_mutex_destroy_arch(struct me_mutex_arch *obj)
{
	vSemaphoreDelete(obj->handle);
}

void me_mutex_lock_arch(struct me_mutex_arch *obj)
{
	xSemaphoreTake(obj->handle, portMAX_DELAY);
}

me_bool_t me_mutex_trylock_arch(struct me_mutex_arch *obj)
{
	me_bool_t lock = ME_FALSE;

	if (xSemaphoreTake(obj->handle, 0)) {
		lock = ME_TRUE;
	}

	return (lock);
}

void me_mutex_unlock_arch(struct me_mutex_arch *obj)
{
	xSemaphoreGive(obj->handle);
}

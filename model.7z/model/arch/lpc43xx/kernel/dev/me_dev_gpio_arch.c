#include "me_dev_gpio_arch.h"

#include "chip.h"


void me_dev_gpio_initialize_arch(void)
{
	Chip_GPIO_Init(LPC_GPIO_PORT);
}

void me_dev_gpio_finalize_arch(void)
{

}

enum me_dev_gpio_dir me_dev_gpio_direction_get_arch(me_uint16_t gpio_no)
{
	return (Chip_GPIO_GetPinDIR(LPC_GPIO_PORT, (me_uint8_t)(gpio_no >> 8), (me_uint8_t)(gpio_no & 0xFF)));
}

void me_dev_gpio_direction_set_arch(me_uint16_t gpio_no, me_bool_t dir)
{
	Chip_GPIO_WriteDirBit(LPC_GPIO_PORT, (me_uint8_t)(gpio_no >> 8), (me_uint8_t)(gpio_no & 0xFF), (bool)dir);
}

me_bool_t me_dev_gpio_value_get_arch(me_uint16_t gpio_no)
{
	return ((me_bool_t)Chip_GPIO_GetPinState(LPC_GPIO_PORT, (me_uint8_t)(gpio_no >> 8), (me_uint8_t)(gpio_no & 0xFF)));
}

void me_dev_gpio_value_set_arch(me_uint16_t gpio_no, me_bool_t value)
{
	Chip_GPIO_SetPinState(LPC_GPIO_PORT, (me_uint8_t)(gpio_no >> 8), (me_uint8_t)(gpio_no & 0xFF), value);
}


#ifndef ME_DEV_GPIO_ARCH_H_
#define ME_DEV_GPIO_ARCH_H_

#include "kernel/me_kernel.h"

#include "kernel/dev/me_device_typedef.h"


void						me_dev_gpio_initialize_arch(void);
void						me_dev_gpio_finalize_arch(void);

enum me_dev_gpio_dir		me_dev_gpio_direction_get_arch(me_uint16_t gpio_no);
void						me_dev_gpio_direction_set_arch(me_uint16_t gpio_no, enum me_dev_gpio_dir dir);

me_bool_t					me_dev_gpio_value_get_arch(me_uint16_t gpio_no);
void						me_dev_gpio_value_set_arch(me_uint16_t gpio_no, me_bool_t value);


#endif

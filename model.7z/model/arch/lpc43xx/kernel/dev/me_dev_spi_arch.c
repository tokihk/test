#include "kernel/me_kernel.h"

#include "kernel/dev/me_dev_typedef.h"

#include "chip.h"


me_bool_t me_dev_spi_setup_0_arch(enum me_dev_spi_mode mode, me_uint32_t clock_hz)
{
	Chip_SSP_Init(LPC_SSP0);

    Chip_SSP_SetFormat(LPC_SSP0, SSP_BITS_8, SSP_FRAMEFORMAT_SPI, SSP_CLOCK_MODE0);

    Chip_SSP_Enable(LPC_SSP0);

	/* Initialize GPDMA controller */
	Chip_GPDMA_Init(LPC_GPDMA);

	/* Setting GPDMA interrupt */
	NVIC_DisableIRQ(DMA_IRQn);
	NVIC_SetPriority(DMA_IRQn, ((0x01 << 3) | 0x01));
	NVIC_EnableIRQ(DMA_IRQn);

	Chip_SSP_SetMaster(LPC_SSP0, (mode == ME_DEV_SPI_MODE_MASTER) ? (1) : (0));

	return (ME_TRUE);
}

me_bool_t me_dev_spi_initialize_arch(void)
{
	return (ME_FALSE);
}

void me_dev_spi_finalize_arch(void)
{
}

me_bool_t me_dev_spi_setup_arch(me_uint16_t spi_id, enum me_dev_spi_mode mode, me_uint32_t clock_hz)
{
	switch (spi_id) {
		case 0:
			break;
	}

	return (ME_FALSE);
}

me_size_t me_dev_spi_send_arch(me_uint16_t spi_id, const me_uint8_t *data, me_size_t size)
{
	return (0);
}

me_bool_t me_dev_spi_send_async_arch(me_uint16_t spi_id, const me_uint8_t *data, me_size_t size)
{
	return (ME_FALSE);
}

me_bool_t me_dev_spi_send_async_is_busy_arch(me_uint16_t spi_id)
{
	return (ME_FALSE);
}

me_size_t me_dev_spi_recv_arch(me_uint16_t spi_id, me_uint8_t *buffer, me_size_t buffer_size)
{
	return (0);
}


me_bool_t me_dev_spi_recv_async_arch(me_uint16_t spi_id, me_uint8_t *buffer, me_size_t buffer_size)
{
	return (ME_FALSE);
}

me_bool_t me_dev_spi_recv_async_is_busy_arch(me_uint16_t spi_id)
{
	return (ME_FALSE);
}



#include "me_dev_timer_arch.h"

#include "chip.h"


#define WEAK __attribute__ ((weak))
#define ALIAS(f) __attribute__ ((weak, alias (#f)))


static const struct me_dev_timer_reg_map_arch
{
	LPC_TIMER_T *		reg;
	me_int8_t			channel;
	CHIP_RGU_RST_T		rgu_rst;
	CHIP_CCU_CLK_T		ccu_clk;
	IRQn_Type			irq_type;
} ME_DEV_TIMER_REG_MAP_LIST_ARCH[] = {
	{ .reg = LPC_TIMER0, .channel = 0, .rgu_rst = RGU_TIMER0_RST, .ccu_clk = CLK_MX_TIMER0, .irq_type = TIMER0_IRQn },
	{ .reg = LPC_TIMER1, .channel = 0, .rgu_rst = RGU_TIMER1_RST, .ccu_clk = CLK_MX_TIMER1, .irq_type = TIMER1_IRQn },
	{ .reg = LPC_TIMER2, .channel = 0, .rgu_rst = RGU_TIMER2_RST, .ccu_clk = CLK_MX_TIMER2, .irq_type = TIMER2_IRQn },
	{ .reg = LPC_TIMER3, .channel = 0, .rgu_rst = RGU_TIMER3_RST, .ccu_clk = CLK_MX_TIMER3, .irq_type = TIMER3_IRQn },
};

static struct g_me_dev_timer_arch_
{
	me_dev_timer_arch_t *	timer_obj[ME_COUNTOF(ME_DEV_TIMER_PERIPHERAL_MAP_ARCH)];
} g_me_dev_timer_arch;


WEAK void me_dev_timer_default_isr(void);

void me_dev_timer0_isr(void) ALIAS(me_dev_timer_default_isr);
void me_dev_timer1_isr(void) ALIAS(me_dev_timer_default_isr);
void me_dev_timer2_isr(void) ALIAS(me_dev_timer_default_isr);
void me_dev_timer3_isr(void) ALIAS(me_dev_timer_default_isr);


static me_uint16_t me_dev_timer_func_to_id_arch(me_uint16_t tmr_id)
{
	if (tmr_id >= ME_DEV_TIMER_FUNC_TOP) {
		tmr_id -= ME_DEV_TIMER_FUNC_TOP;
	}

	return (tmr_id);
}

void me_dev_timer_default_isr(void)
{
}

void TIMER0_IRQHandler(void)
{
	me_dev_timer0_isr();
}

void TIMER1_IRQHandler(void)
{
	me_dev_timer1_isr();
}

void TIMER2_IRQHandler(void)
{
	me_dev_timer2_isr();
}

void TIMER3_IRQHandler(void)
{
	me_dev_timer3_isr();
}

void me_dev_timer_initialize_arch(void)
{
	/* Enable timer clock and reset it */
	Chip_TIMER_Init(LPC_TIMER0);
	Chip_TIMER_Init(LPC_TIMER1);
	Chip_TIMER_Init(LPC_TIMER2);
	Chip_TIMER_Init(LPC_TIMER3);

	Chip_RGU_TriggerReset(RGU_TIMER0_RST);
	Chip_RGU_TriggerReset(RGU_TIMER1_RST);
	Chip_RGU_TriggerReset(RGU_TIMER2_RST);
	Chip_RGU_TriggerReset(RGU_TIMER3_RST);

	while (   (Chip_RGU_InReset(RGU_TIMER0_RST))
		   || (Chip_RGU_InReset(RGU_TIMER1_RST))
		   || (Chip_RGU_InReset(RGU_TIMER2_RST))
		   || (Chip_RGU_InReset(RGU_TIMER3_RST))
	) {}

	Chip_TIMER_Reset(LPC_TIMER0);
	Chip_TIMER_Reset(LPC_TIMER1);
	Chip_TIMER_Reset(LPC_TIMER2);
	Chip_TIMER_Reset(LPC_TIMER3);
}

void me_dev_timer_finalize_arch(void)
{
}

me_bool_t me_dev_timer_create_arch(me_uint16_t tmr_id, me_uint32_t ival_hz)
{
	me_bool_t success = ME_FALSE;

	tmr_id = me_dev_timer_func_to_id_arch(tmr_id);

	if (tmr_id < ME_COUNTOF(ME_DEV_TIMER_REG_MAP_LIST_ARCH)) {
		const struct me_dev_timer_reg_map_arch *regmap = &ME_DEV_TIMER_REG_MAP_LIST_ARCH[tmr_id];

		/* Disable timer interrupt */
		NVIC_DisableIRQ(regmap->irq_type);

		/* Disable timer */
		Chip_TIMER_Disable(regmap->reg);

		Chip_TIMER_MatchEnableInt(regmap->reg, regmap->channel);
		Chip_TIMER_ResetOnMatchEnable(regmap->reg, regmap->channel);

		/* Enable timer */
		Chip_TIMER_Enable(regmap->reg);

		/* Enable timer interrupt */
		NVIC_EnableIRQ(regmap->irq_type);
		NVIC_ClearPendingIRQ(regmap->irq_type);

		success = ME_TRUE;
	}

	return (ME_TRUE);
}

void me_dev_timer_destroy_arch(me_uint16_t tmr_id)
{
	tmr_id = me_dev_timer_func_to_id_arch(tmr_id);

	if (tmr_id < ME_COUNTOF(ME_DEV_TIMER_REG_MAP_LIST_ARCH)) {
		const struct me_dev_timer_reg_map_arch *regmap = &ME_DEV_TIMER_REG_MAP_LIST_ARCH[tmr_id];

		/* Disable timer interrupt */
		NVIC_DisableIRQ(pmap->irq_type);

		/* Disable timer */
		Chip_TIMER_Disable(pmap->reg);

		Chip_TIMER_MatchDisableInt(pmap->reg, pmap->channel);
		Chip_TIMER_ResetOnMatchDisable(pmap->reg, pmap->channel);

		/* Enable timer */
		Chip_TIMER_Enable(pmap->reg);

		/* Enable timer interrupt */
		NVIC_EnableIRQ(pmap->irq_type);
		NVIC_ClearPendingIRQ(pmap->irq_type);
	}
}


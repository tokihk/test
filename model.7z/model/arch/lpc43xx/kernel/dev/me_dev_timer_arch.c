#include "me_dev_timer_arch.h"

#include "chip.h"


static const struct me_dev_timer_peripheral_map_arch
{
	LPC_TIMER_T *		reg;
	me_int8_t			channel;
	CHIP_RGU_RST_T		rgu_rst;
	CHIP_CCU_CLK_T		ccu_clk;
	IRQn_Type			irq_type;
} ME_DEV_TIMER_PERIPHERAL_MAP_ARCH[] = {
	{ .reg = LPC_TIMER0, .channel = 0, .rgu_rst = RGU_TIMER0_RST, .ccu_clk = CLK_MX_TIMER0, .irq_type = TIMER0_IRQn },
	{ .reg = LPC_TIMER1, .channel = 0, .rgu_rst = RGU_TIMER1_RST, .ccu_clk = CLK_MX_TIMER1, .irq_type = TIMER1_IRQn },
	{ .reg = LPC_TIMER2, .channel = 0, .rgu_rst = RGU_TIMER2_RST, .ccu_clk = CLK_MX_TIMER2, .irq_type = TIMER2_IRQn },
	{ .reg = LPC_TIMER3, .channel = 0, .rgu_rst = RGU_TIMER3_RST, .ccu_clk = CLK_MX_TIMER3, .irq_type = TIMER3_IRQn },
};

static struct g_me_dev_timer_arch_
{
	me_dev_timer_arch_t *	timer_obj[ME_COUNTOF(ME_DEV_TIMER_PERIPHERAL_MAP_ARCH)];
} g_me_dev_timer_arch;

static void TIMER_IRQHandler_base(LPC_TIMER_T *reg)
{
	me_int8_t index;
	const struct me_dev_timer_peripheral_map_arch *pmap;
	me_dev_timer_arch_t *obj;

	for (index = 0; index < (me_int8_t)ME_COUNTOF(g_me_dev_timer_arch.timer_obj); index++) {
		pmap = &ME_DEV_TIMER_PERIPHERAL_MAP_ARCH[index];
		if ((pmap->reg == reg) && (Chip_TIMER_MatchPending(pmap->reg, pmap->channel))) {
			Chip_TIMER_ClearMatch(pmap->reg, pmap->channel);

			obj = g_me_dev_timer_arch.timer_obj[index];
			if (obj != NULL) {
				(obj->config.callback_isr)(obj, obj->config.callback_param);
			}
		}
	}
}

void TIMER0_IRQHandler(void)
{
	TIMER_IRQHandler_base(LPC_TIMER0);
}

void TIMER1_IRQHandler(void)
{
	TIMER_IRQHandler_base(LPC_TIMER1);
}

void TIMER2_IRQHandler(void)
{
	TIMER_IRQHandler_base(LPC_TIMER2);
}

void TIMER3_IRQHandler(void)
{
	TIMER_IRQHandler_base(LPC_TIMER3);
}

void me_dev_timer_initialize_arch(void)
{
	/* Enable timer clock and reset it */
	Chip_TIMER_Init(LPC_TIMER0);
	Chip_TIMER_Init(LPC_TIMER1);
	Chip_TIMER_Init(LPC_TIMER2);
	Chip_TIMER_Init(LPC_TIMER3);

	Chip_RGU_TriggerReset(RGU_TIMER0_RST);
	Chip_RGU_TriggerReset(RGU_TIMER1_RST);
	Chip_RGU_TriggerReset(RGU_TIMER2_RST);
	Chip_RGU_TriggerReset(RGU_TIMER3_RST);

	while (   (Chip_RGU_InReset(RGU_TIMER0_RST))
		   || (Chip_RGU_InReset(RGU_TIMER1_RST))
		   || (Chip_RGU_InReset(RGU_TIMER2_RST))
		   || (Chip_RGU_InReset(RGU_TIMER3_RST))
	) {}

	Chip_TIMER_Reset(LPC_TIMER0);
	Chip_TIMER_Reset(LPC_TIMER1);
	Chip_TIMER_Reset(LPC_TIMER2);
	Chip_TIMER_Reset(LPC_TIMER3);
}

void me_dev_timer_finalize_arch(void)
{
}

me_bool_t me_dev_timer_create_arch(me_dev_timer_arch_t *obj, const me_dev_timer_config_arch_t *config)
{
	me_bool_t success = ME_FALSE;

	if (config != NULL) {
		me_uint8_t map_no;

		for (map_no = 0; map_no < (me_uint8_t)ME_COUNTOF(g_me_dev_timer_arch.timer_obj); map_no++) {
			if (g_me_dev_timer_arch.timer_obj[map_no] == NULL) {
				break;
			}
		}

		if (map_no < ME_COUNTOF(g_me_dev_timer_arch.timer_obj)) {
			obj->config = *config;
			obj->map_no = map_no;

			g_me_dev_timer_arch.timer_obj[map_no] = obj;

			success = ME_TRUE;
		}
	}

	return (success);
}

void me_dev_timer_destroy_arch(me_dev_timer_arch_t *obj)
{
	me_dev_timer_stop_arch(obj);

	g_me_dev_timer_arch.timer_obj[obj->map_no] = NULL;
}

void me_dev_timer_start_arch(me_dev_timer_arch_t *obj)
{
	const struct me_dev_timer_peripheral_map_arch *pmap = &ME_DEV_TIMER_PERIPHERAL_MAP_ARCH[obj->map_no];

	/* Disable timer interrupt */
	NVIC_DisableIRQ(pmap->irq_type);

	/* Disable timer */
	Chip_TIMER_Disable(pmap->reg);

	Chip_TIMER_MatchEnableInt(pmap->reg, pmap->channel);
	Chip_TIMER_ResetOnMatchEnable(pmap->reg, pmap->channel);

	/* Enable timer */
	Chip_TIMER_Enable(pmap->reg);

	/* Enable timer interrupt */
	NVIC_EnableIRQ(pmap->irq_type);
	NVIC_ClearPendingIRQ(pmap->irq_type);
}

void me_dev_timer_stop_arch(me_dev_timer_arch_t *obj)
{
	const struct me_dev_timer_peripheral_map_arch *pmap = &ME_DEV_TIMER_PERIPHERAL_MAP_ARCH[obj->map_no];

	/* Disable timer interrupt */
	NVIC_DisableIRQ(pmap->irq_type);

	/* Disable timer */
	Chip_TIMER_Disable(pmap->reg);

	Chip_TIMER_MatchDisableInt(pmap->reg, pmap->channel);
	Chip_TIMER_ResetOnMatchDisable(pmap->reg, pmap->channel);

	/* Enable timer */
	Chip_TIMER_Enable(pmap->reg);

	/* Enable timer interrupt */
	NVIC_EnableIRQ(pmap->irq_type);
	NVIC_ClearPendingIRQ(pmap->irq_type);
}



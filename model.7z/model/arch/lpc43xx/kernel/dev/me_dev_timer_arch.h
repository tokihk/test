#ifndef ME_DEV_TIMER_ARCH_H_
#define ME_DEV_TIMER_ARCH_H_

#include "kernel/me_kernel.h"

#include "kernel/dev/me_device_typedef.h"


typedef struct me_dev_timer_arch
{
	me_dev_timer_config_arch_t	config;
	me_uint8_t					map_no;
} me_dev_timer_arch_t;


void					me_dev_timer_initialize_arch(void);
void					me_dev_timer_finalize_arch(void);

me_bool_t				me_dev_timer_create_arch(me_dev_timer_arch_t *obj, const me_dev_timer_config_arch_t *config);
void					me_dev_timer_destroy_arch(me_dev_timer_arch_t *obj);

void					me_dev_timer_start_arch(me_dev_timer_arch_t *obj);
void					me_dev_timer_stop_arch(me_dev_timer_arch_t *obj);


#endif


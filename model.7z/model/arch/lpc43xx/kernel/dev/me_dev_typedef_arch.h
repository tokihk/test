#ifndef ME_DEV_TYPEDEF_ARCH_H_
#define ME_DEV_TYPEDEF_ARCH_H_

#include "kernel/me_kernel.h"

#endif

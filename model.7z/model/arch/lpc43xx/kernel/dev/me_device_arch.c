#include "kernel/dev/me_device_arch.h"


me_bool_t me_device_initialize_arch(void)
{
	return (ME_TRUE);
}

void me_device_finalize_arch(void)
{

}



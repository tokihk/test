#include "me_gpio_arch.h"

#include "chip.h"


void me_gpio_initialize_arch(void)
{
	Chip_GPIO_Init(LPC_GPIO_PORT);
}

void me_gpio_finalize_arch(void)
{

}

me_uint16_t me_gpio_count_arch(void)
{

}

enum me_gpio_direction me_gpio_direction_get_arch(me_uint16_t gpio_no)
{

}

void me_gpio_direction_set_arch(me_uint16_t gpio_no, enum me_gpio_direction dir)
{

}

enum me_gpio_logic me_gpio_value_get_arch(me_uint16_t gpio_no)
{

}

void me_gpio_value_set_arch(me_uint16_t gpio_no, enum me_gpio_logic value)
{

}


#ifndef ME_FS_TYPEDEF_ARCH_H_
#define ME_FS_TYPEDEF_ARCH_H_

#include "kernel/me_kernel.h"

#include "ff.h"


typedef struct me_file_arch
{
	FIL				file;
	me_bool_t		open_status;
} me_file_arch_t;


#endif

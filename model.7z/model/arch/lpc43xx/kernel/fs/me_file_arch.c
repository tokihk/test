#include "kernel/fs/me_file_fatfs_arch.h"


#ifndef ME_FILE_ARCH_H_
#define ME_FILE_ARCH_H_

#include "kernel/me_kernel.h"

#include "ff.h"


typedef struct me_file_arch
{
	FIL				file;
	me_bool_t		open_status;
} me_file_arch_t;


me_bool_t				me_current_dir_set_arch(const me_char_t *dir_path);
me_bool_t				me_current_dir_get_arch(me_char_t *buffer, me_size_t buffer_size);

me_bool_t				me_make_directory_arch(const me_char_t *dir_path);

void					me_remove_directory_arch(const me_char_t *dir_path);
void					me_remove_file_arch(const me_char_t *file_path);

me_bool_t				me_is_file_exist_arch(const me_char_t *file_path);
me_bool_t				me_is_dir_exist_arch(const me_char_t *dir_path);

me_bool_t				me_file_open_arch(me_file_arch_t *obj, const me_char_t *file_path, enum me_file_mode mode);

void					me_file_close_arch(me_file_arch_t *obj);

me_size_t				me_file_read_arch(me_file_arch_t *obj, me_uint8_t *buffer, me_size_t buffer_size);

me_size_t				me_file_write_arch(me_file_arch_t *obj, const me_uint8_t *data, me_uint16_t size);


#endif

#include "kernel/fs/me_file_arch.h"

#include "kernel/base/me_main_system.h"
#include "kernel/base/me_string_utility.h"


me_bool_t me_current_dir_set_arch(const me_char_t *dir_path)
{
	me_bool_t set_ok = ME_FALSE;

	if (f_chdir(dir_path) == FR_OK) {
		set_ok = ME_TRUE;
	}

	return (set_ok);
}

me_bool_t me_current_dir_get_arch(me_char_t *buffer, me_size_t buffer_size)
{
	me_bool_t get_ok = ME_FALSE;

	if (f_getcwd(buffer, buffer_size) == FR_OK) {
		get_ok = ME_TRUE;
	}

	return (get_ok);
}

me_bool_t me_make_directory_arch(const me_char_t *dir_path)
{
	me_bool_t make_ok = ME_FALSE;

	if (f_mkdir(dir_path) == FR_OK) {
		make_ok = ME_TRUE;
	}

	return (make_ok);
}

void me_remove_directory_arch(const me_char_t *dir_path)
{
	if (dir_path != NULL) {
		f_rmdir(dir_path);
	}
}

void me_remove_file_arch(const me_char_t *file_path)
{
	if (file_path != NULL) {
		f_unlink(file_path);
	}
}

me_bool_t me_is_file_exist_arch(const me_char_t *file_path)
{
	me_bool_t exist = ME_FALSE;
	FIL file;

	if (f_open(&file, file_path, FA_OPEN_EXISTING) == FR_OK) {
		f_close(&file);

		exist = ME_TRUE;
	}

	return (exist);
}

me_bool_t me_is_dir_exist_arch(const me_char_t *dir_path)
{
	me_bool_t exist = ME_FALSE;
	DIR dir;

	if (f_opendir(&dir, dir_path) == FR_OK) {
		f_closedir(&dir);

		exist = ME_TRUE;
	}

	return (exist);
}

me_bool_t me_file_open_arch(me_file_arch_t *obj, const me_char_t *file_path, enum me_file_mode mode)
{
	BYTE ff_mode;

	switch (mode) {
		case ME_FILE_READONLY:		ff_mode = FA_OPEN_EXISTING;	break;
		case ME_FILE_READWRITE_NEW:	ff_mode = FA_CREATE_ALWAYS;	break;
		case ME_FILE_READWRITE_ADD:	ff_mode = FA_OPEN_APPEND;	break;
		default:					ff_mode = FA_OPEN_EXISTING;	break;
	}

	obj->open_status = ME_FALSE;

	if (f_open(&obj->file, file_path, ff_mode) == FR_OK) {
		obj->open_status = ME_TRUE;
	}

	return (obj->open_status);
}

void me_file_close_arch(me_file_arch_t *obj)
{
	if (obj->open_status) {
		f_close(&obj->file);
		obj->open_status = ME_FALSE;
	}
}

me_size_t me_file_read_arch(me_file_arch_t *obj, me_uint8_t *buffer, me_size_t buffer_size)
{
	UINT read_size = 0;

	if (f_read(&obj->file, buffer, (UINT)buffer_size, &read_size) != FR_OK) {
		read_size = 0;
	}

	return ((me_size_t)read_size);
}

me_size_t me_file_write_arch(me_file_arch_t *obj, const me_uint8_t *data, me_uint16_t size)
{
	UINT write_size = 0;

	if (f_write(&obj->file, data, size, &write_size) != FR_OK) {
		write_size = 0;
	}

	return (write_size);
}

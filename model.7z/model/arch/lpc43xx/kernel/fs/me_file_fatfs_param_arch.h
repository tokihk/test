/* ###################################################################### *//**
 *
 *	@addtogroup	Kernel
 *	@{
 *	@file		me_file_fatfs_param_arch.h
 *	@brief		File System Module
 *	@author		Copyright (C) 2019 Hitoshi Kouno
 *
*//* ####################################################################### */
#ifndef ME_FILE_FATFS_PARAM_ARCH_H_
#define ME_FILE_FATFS_PARAM_ARCH_H_

#include "kernel/me_kernel.h"

#include "ff.h"


typedef struct me_file_param_arch
{
	FIL				file;
	me_bool_t		open_status;
} me_file_param_arch_t;


#endif /* ME_FILE_FATFS_PARAM_ARCH_H_ */
/* ####### File End ###### */
/** @} */

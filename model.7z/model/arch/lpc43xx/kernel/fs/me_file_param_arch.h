#ifndef ME_FILE_PARAM_ARCH_H_
#define ME_FILE_PARAM_ARCH_H_

#include "kernel/me_kernel.h"


#include "kernel/fs/me_file_fatfs_param_arch.h"


#endif

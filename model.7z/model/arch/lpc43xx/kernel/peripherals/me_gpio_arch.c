#include "arch/skelton/kernel/peripherals/me_gpio_arch.h"

#include "chip.h"


static me_uint16_t me_gpio_func_to_pin_arch(me_uint16_t gpio_id)
{
	switch (gpio_id) {
		case ME_DEV_GPIO_ID_DEBUG_00:	gpio_id = 0x0307;	break;
		default:						gpio_id = 0x0100;	break;
	}

	return (gpio_id);
}

me_bool_t me_gpio_initialize_arch(void)
{
	Chip_GPIO_Init(LPC_GPIO_PORT);

	return (ME_TRUE);
}

void me_gpio_finalize_arch(void)
{
}

me_bool_t me_gpio_direction_get_arch(me_uint16_t gpio_id)
{
	gpio_id = me_gpio_func_to_pin_arch(gpio_id);

	return (Chip_GPIO_GetPinDIR(LPC_GPIO_PORT, (me_uint8_t)(gpio_id >> 8), (me_uint8_t)(gpio_id & 0xFF)));
}

void me_gpio_direction_set_arch(me_uint16_t gpio_id, me_bool_t dir)
{
	gpio_id = me_gpio_func_to_pin_arch(gpio_id);

	Chip_GPIO_WriteDirBit(LPC_GPIO_PORT, (me_uint8_t)(gpio_id >> 8), (me_uint8_t)(gpio_id & 0xFF), (bool)dir);
}

me_bool_t me_gpio_value_get_arch(me_uint16_t gpio_id)
{
	gpio_id = me_gpio_func_to_pin_arch(gpio_id);

	return ((me_bool_t)Chip_GPIO_GetPinState(LPC_GPIO_PORT, (me_uint8_t)(gpio_id >> 8), (me_uint8_t)(gpio_id & 0xFF)));
}

void me_gpio_value_set_arch(me_uint16_t gpio_id, me_bool_t value)
{
	gpio_id = me_gpio_func_to_pin_arch(gpio_id);

	Chip_GPIO_SetPinState(LPC_GPIO_PORT, (me_uint8_t)(gpio_id >> 8), (me_uint8_t)(gpio_id & 0xFF), value);
}


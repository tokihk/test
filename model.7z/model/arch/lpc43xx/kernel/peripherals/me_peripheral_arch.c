#include "arch/skelton/kernel/peripherals/me_peripheral_arch.h"

#include "chip.h"


me_bool_t me_peripheral_initialize_arch(void)
{
	return (ME_TRUE);
}

void me_peripheral_finalize_arch(void)
{

}



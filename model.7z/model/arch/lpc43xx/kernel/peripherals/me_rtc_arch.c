#include "me_rtc_arch.h"

#include "chip.h"


me_bool_t me_rtc_initialize_arch(void)
{
	Chip_RTC_Init(LPC_RTC);

	return (ME_FALSE);
}

void me_rtc_finalize_arch(void)
{
}

me_bool_t me_rtc_datetime_get_arch(struct me_datetime *dt)
{
	RTC_TIME_T rt = {0};

	Chip_RTC_GetFullTime(LPC_RTC, &rt);

	dt->sec = (me_uint8_t)rt.time[RTC_TIMETYPE_SECOND];
	dt->min = (me_uint8_t)rt.time[RTC_TIMETYPE_MINUTE];
	dt->hour = (me_uint8_t)rt.time[RTC_TIMETYPE_HOUR];
	dt->month = (me_uint8_t)rt.time[RTC_TIMETYPE_MONTH];
	dt->year = (me_uint16_t)rt.time[RTC_TIMETYPE_YEAR];

	return (ME_TRUE);
}

me_bool_t me_rtc_datetime_set_arch(const struct me_datetime *dt)
{
	RTC_TIME_T rt = {0};

	rt.time[RTC_TIMETYPE_SECOND]  = dt->sec;
	rt.time[RTC_TIMETYPE_MINUTE]  = dt->min;
	rt.time[RTC_TIMETYPE_HOUR]    = dt->hour;
	rt.time[RTC_TIMETYPE_MONTH]   = dt->month;
	rt.time[RTC_TIMETYPE_YEAR]    = dt->year;

	Chip_RTC_SetFullTime(LPC_RTC, &rt);

	return (ME_TRUE);
}

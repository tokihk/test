#ifndef ME_TIMER_ARCH_H_
#define ME_TIMER_ARCH_H_

#include "kernel/peripherals/me_timer_stddef.h"



me_bool_t				me_timer_initialize_arch(void);
void					me_timer_finalize_arch(void);

me_bool_t				me_timer_create_arch(me_uint16_t tmr_id, me_uint32_t ival_10nsec, me_timer_callback_t callback);
void					me_timer_destroy_arch(me_uint16_t tmr_id);

void					me_timer_isr(me_uint16_t tmr_id);


#endif

/* ###################################################################### *//**
 *
 *	@addtogroup	Kernel
 *	@{
 *	@file		me_mutex_param_arch.h
 *	@brief		Mutex Module
 *	@author		Copyright (C) 2019 Hitoshi Kouno
 *
*//* ####################################################################### */
#ifndef ME_MUTEX_PARAM_ARCH_H_
#define ME_MUTEX_PARAM_ARCH_H_

#include "kernel/me_kernel.h"


typedef struct me_mutex_param_arch
{
	me_uint8_t			dammy;
} me_mutex_param_arch_t;


#endif /* ME_MUTEX_PARAM_ARCH_H_ */
/* ####### File End ###### */
/** @} */

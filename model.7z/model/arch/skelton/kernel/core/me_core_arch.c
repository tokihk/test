#include "me_core_arch.h"

#include "kernel/core/me_core.h"


me_int8_t me_startup_arch(me_int8_t argc, me_achar_t **argv)
{
	me_int8_t ret = 0;

	ret = me_main(argc, argv);

	return (ret);
}

me_uint32_t me_system_tick_msec_get_arch(void)
{
	return (0);
}

me_size_t me_stdin_arch(me_uint8_t *buffer, me_size_t size)
{
	return (0);
}

me_size_t me_stdout_arch(const me_uint8_t *data, me_size_t size)
{
	return (0);
}

me_size_t me_stderr_arch(const me_uint8_t *data, me_size_t size)
{
	return (0);
}



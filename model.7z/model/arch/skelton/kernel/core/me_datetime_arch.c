#include "me_datetime_arch.h"


me_bool_t me_datetime_now_arch(struct me_datetime *dt)
{
	return (ME_FALSE);
}

me_bool_t me_datetime_now_utc_arch(struct me_datetime *dt)
{
	return (ME_FALSE);
}


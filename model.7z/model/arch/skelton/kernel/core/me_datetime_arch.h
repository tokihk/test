#ifndef ME_DATETIME_ARCH_H_
#define ME_DATETIME_ARCH_H_

#include "kernel/core/me_datetime_stddef.h"


me_bool_t			me_datetime_now_arch(struct me_datetime *dt);
me_bool_t			me_datetime_now_utc_arch(struct me_datetime *dt);


#endif

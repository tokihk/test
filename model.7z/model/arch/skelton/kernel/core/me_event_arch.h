#ifndef ME_EVENT_ARCH_H_
#define ME_EVENT_ARCH_H_

#include "kernel/core/me_stddef.h"


me_bool_t				me_event_queue_create_arch(me_event_queue_arch_t *obj, me_size_t event_num_max);
void					me_event_queue_destroy_arch(me_event_queue_arch_t *obj);

me_bool_t				me_event_queue_send_arch(me_event_queue_arch_t *obj, me_uint16_t event_id);
me_bool_t				me_event_queue_send_isr_arch(me_event_queue_arch_t *obj, me_uint16_t event_id);

me_bool_t				me_event_queue_recv_arch(me_event_queue_arch_t *obj, me_uint16_t *event_id, me_uint32_t timeout_msec);
me_bool_t				me_event_queue_recv_isr_arch(me_event_queue_arch_t *obj, me_uint16_t *event_id);


#endif

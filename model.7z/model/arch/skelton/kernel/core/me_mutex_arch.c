#include "me_mutex_arch.h"


me_bool_t me_mutex_create_arch(struct me_mutex_arch *obj)
{
	return (ME_FALSE);
}

void me_mutex_destroy_arch(struct me_mutex_arch *obj)
{
}

void me_mutex_lock_arch(struct me_mutex_arch *obj)
{
}

me_bool_t me_mutex_trylock_arch(struct me_mutex_arch *obj)
{
	return (ME_FALSE);
}

void me_mutex_unlock_arch(struct me_mutex_arch *obj)
{
}


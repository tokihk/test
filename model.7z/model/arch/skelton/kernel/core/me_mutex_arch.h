#ifndef ME_MUTEX_ARCH_H_
#define ME_MUTEX_ARCH_H_

#include "kernel/core/me_stddef.h"


struct me_mutex_arch
{
};


me_bool_t			me_mutex_create_arch(struct me_mutex_arch *obj);
void				me_mutex_destroy_arch(struct me_mutex_arch *obj);

void				me_mutex_lock_arch(struct me_mutex_arch *obj);
me_bool_t			me_mutex_trylock_arch(struct me_mutex_arch *obj);

void				me_mutex_unlock_arch(struct me_mutex_arch *obj);


#endif


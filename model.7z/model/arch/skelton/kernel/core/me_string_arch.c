#include "me_string_arch.h"

#include <string.h>
#include <stdio.h>
#include <wchar.h>


me_int32_t me_string_vsnprintf_arch(me_char_t *dst, me_size_t size, const me_char_t *format, va_list args)
{
	me_int32_t ret;

	ret = (me_int_t)vsnprintf(dst, size, format, args);
	if (ret > (me_int_t)size) {
		ret = -1;
	}

	return (ret);
}

me_int32_t me_string_vswprintf_arch(me_wchar_t *dst, me_size_t size, const me_wchar_t *format, va_list args)
{
	me_int32_t ret;

	ret = (me_int32_t)vswprintf(dst, size, format, args);
	if (ret < 0) {
		ret = -1;
	}

	return (ret);
}

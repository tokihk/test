#include "kernel/core/me_task_arch.h"


static struct
{
	me_task_arch_t		root;

	me_bool_t			exit_req;
} g_me_task_arch;


static void me_task_main_arch(void *param)
{
	((me_task_arch_t *)param)->callback((me_task_arch_t *)param, ((me_task_arch_t *)param)->callback_param);
}

void me_task_scheduler_initialize_arch(void)
{
	g_me_task_arch.root.next = &g_me_task_arch.root;
	g_me_task_arch.root.prev = &g_me_task_arch.root;
}

void me_task_scheduler_finalize_arch(void)
{
}

void me_task_scheduler_exec_arch(void)
{
	struct me_task_arch *task;
	struct me_task_arch *task_next;

	while (g_me_task_arch.root.next != &g_me_task_arch.root) {
		task = g_me_task_arch.root.next;
		while (task != &g_me_task_arch.root) {
			/* タスク実行 */
			if (!task->exit_req) {
				if (task->poll_counter > 0) {
					task->poll_counter--;
				}

				if (task->poll_counter == 0) {
					(task->callback)(task, task->callback_param);
					task->poll_counter = task->priority;
				}
			}

			/* 終了要求のないタスクを選択 */
			task_next = task->next;
			while (task_next->exit_req) {
				task_next = task_next->next;
			}

			/* 終了要求のあるタスクを削除 */
			if (g_me_task_arch.exit_req) {
				struct me_task_arch *task_temp;

				task_temp = g_me_task_arch.root.next;
				while (task_temp != &g_me_task_arch.root) {
					if (task_temp->exit_req) {
						task_temp->prev->next = task_temp->next;
						task_temp->next->prev = task_temp->prev;
					}
					task_temp = task_temp->next;
				}

				g_me_task_arch.exit_req = ME_FALSE;
			}

			task = task_next;
		}
	}
}

me_bool_t me_task_create_arch(struct me_task_arch *obj, me_size_t stack_size, me_uint8_t priority, void (* callback)(struct me_task_arch *, void *), void *param)
{
	me_bool_t success = ME_FALSE;

	obj->callback = callback;
	obj->callback_param = param;
	obj->priority = (me_uint8_t)(0xFFu - priority);
	obj->poll_counter = obj->priority;
	obj->exit_req = ME_FALSE;

	obj->prev = g_me_task_arch.root->prev;
	obj->next = &g_me_task_arch.root;

	obj->prev->next = obj;
	obj->next->prev = obj;

	return (success);
}

void me_task_destroy_arch(me_task_arch_t *obj)
{
	obj->exit_req = ME_TRUE;
}

void me_task_sleep_msec_arch(me_uint32_t time_msec)
{
}

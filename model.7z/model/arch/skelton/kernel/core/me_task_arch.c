#include "kernel/base/me_task_arch.h"


static struct
{
	me_task_arch_t		root;
} g_me_task_arch;


static void me_task_main_arch(void *param)
{
	((me_task_arch_t *)param)->callback((me_task_arch_t *)param, ((me_task_arch_t *)param)->callback_param);
}

void me_task_scheduler_initialize_arch(void)
{
	g_me_task_arch.root.next = &g_me_task_arch.root;
	g_me_task_arch.root.prev = &g_me_task_arch.root;
}

void me_task_scheduler_finalize_arch(void)
{

}

void me_task_scheduler_exec_arch(void)
{
}

me_bool_t me_task_create_arch(me_task_arch_t *obj, me_size_t stack_size, me_uint8_t priority, void (* callback)(struct me_task_arch *, void *), void *param)
{
	me_bool_t success = ME_FALSE;

	obj->callback = callback;
	obj->callback_param = param;


	obj->prev = g_me_task_arch.root->prev;
	obj->next = &g_me_task_arch.root;

	g_me_task_arch.root->prev->next = obj;

	return (success);
}

void me_task_destroy_arch(me_task_arch_t *obj)
{
	obj->prev->next = obj->next;
	obj->next->prev = obj->prev;

	obj->prev = NULL;
	obj->next = NULL;
}

void me_task_sleep_msec_arch(me_uint32_t time_msec)
{
}

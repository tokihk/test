#ifndef ME_TASK_ARCH_H_
#define ME_TASK_ARCH_H_

#include "kernel/core/me_stddef.h"


struct me_task_arch
{
	struct me_task_arch *	prev;
	struct me_task_arch *	next;

	void					(* callback)(struct me_task_arch *, void *);
	void *					callback_param;

	me_uint8_t				priority;
	me_uint8_t				poll_counter;

	me_bool_t				exit_req;
};


void					me_task_scheduler_initialize_arch(void);
void					me_task_scheduler_finalize_arch(void);
void					me_task_scheduler_exec_arch(void);

me_bool_t				me_task_create_arch(struct me_task_arch *obj, me_size_t stack_size, me_uint8_t priority, void (* callback)(struct me_task_arch *, void *), void *param);
void					me_task_destroy_arch(struct me_task_arch *obj);

void					me_task_sleep_msec_arch(me_uint32_t time_msec);


#endif

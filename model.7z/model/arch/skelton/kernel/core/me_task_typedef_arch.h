#ifndef ME_TASK_TYPEDEF_ARCH_H_
#define ME_TASK_TYPEDEF_ARCH_H_

#include "kernel/me_kernel.h"


	typedef struct me_task_arch
	{
		struct me_task_arch *	prev;
		struct me_task_arch *	next;

		void					(* callback)(struct me_task_arch *, void *);
		void *					callback_param;
	} me_task_arch_t;


#endif

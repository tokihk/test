#include "kernel/dev/me_dev_gpio_arch.h"


void me_dev_gpio_initialize_arch(void)
{
}

void me_dev_gpio_finalize_arch(void)
{
}

me_bool_t me_dev_gpio_direction_get_arch(me_uint16_t pin)
{
	return (ME_FALSE);
}

void me_dev_gpio_direction_set_arch(me_uint16_t pin, me_bool_t dir)
{
}

me_bool_t me_dev_gpio_value_get_arch(me_uint16_t pin)
{
	return (ME_FALSE);
}

void me_dev_gpio_value_set_arch(me_uint16_t pin, me_bool_t value)
{
}


#ifndef ME_FILESYSTEM_ARCH_H_
#define ME_FILESYSTEM_ARCH_H_

#include "kernel/filesystem/me_filesystem_stddef.h"

#include "kernel/filesystem/me_path.h"

#include <stdarg.h>


struct me_file_arch
{
};

struct me_directory_arch
{
};


me_bool_t				me_fs_open_arch(struct me_file_arch *file, const me_char_t *path, me_uint8_t mode);
me_bool_t				me_fs_close_arch(struct me_file_arch *file);
me_bool_t				me_fs_read_arch(struct me_file_arch *file, void *buff, me_size_t read_size, me_size_t *result);
me_bool_t				me_fs_write_arch(struct me_file_arch *file, const void *data, me_size_t write_size, me_size_t *result);
me_size_t				me_fs_write_vformat_arch(struct me_file_arch *file, const me_char_t *format, va_list args);

me_bool_t				me_fs_lseek_arch(struct me_file_arch *file, me_size_t ofs);

me_bool_t				me_fs_opendir_arch(struct me_directory_arch *dir, const me_char_t *path);
me_bool_t				me_fs_closedir_arch(struct me_directory_arch *dir);
me_bool_t				me_fs_readdir_arch(struct me_directory_arch *dir, struct me_file_info *info);

me_bool_t				me_fs_mkdir_arch(const me_char_t *path);
me_bool_t				me_fs_unlink_arch(const me_char_t *path);
me_bool_t				me_fs_rename_arch(const me_char_t *path_old, const me_char_t *path_new);
me_bool_t				me_fs_stat_arch(const me_char_t *path, struct me_file_info *info);
me_bool_t				me_fs_chdir_arch(const me_char_t *path);
me_bool_t				me_fs_getcwd_arch(struct me_path *path);


#endif

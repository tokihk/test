#include "kernel/net/me_net_board.h"


me_bool_t me_net_initialize_arch(void)
{
	return (ME_TRUE);
}

void me_net_finalize_arch(void)
{
}

me_bool_t me_net_endpoint_get_arch(me_net_endpoint_arch_t *ep, enum me_net_domain_type dtype, const me_achar_t *hostname)
{
	return (ME_FALSE);
}

me_bool_t me_net_endpoint_to_text_arch(const me_net_endpoint_arch_t *ep, enum me_net_domain_type dtype, me_achar_t *ep_text, me_size_t ep_text_size)
{
	return (ME_FALSE);
}

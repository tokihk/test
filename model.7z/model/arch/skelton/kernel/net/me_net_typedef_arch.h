#ifndef ME_NET_TYPEDEF_ARCH_H_
#define ME_NET_TYPEDEF_ARCH_H_

#include "kernel/me_kernel.h"


typedef struct me_net_endpoint_arch
{
	me_uint8_t			dammy;
} me_net_endpoint_arch_t;

typedef struct me_net_tcp_server_arch
{
	me_uint8_t			dammy;
} me_net_tcp_server_arch_t;

typedef struct me_net_tcp_client_arch
{
	me_uint8_t			dammy;
} me_net_tcp_client_arch_t;

typedef struct me_net_udp_client_arch
{
	me_uint8_t			dammy;
} me_net_udp_client_arch_t;


#endif

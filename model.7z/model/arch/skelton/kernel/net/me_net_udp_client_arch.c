#include "kernel/net/me_net_udp_client_arch.h"


me_bool_t me_net_udp_client_create_arch(me_net_udp_client_arch_t *obj, me_uint16_t local_port_no)
{
	return (ME_FALSE);
}

void me_net_udp_client_destroy_arch(me_net_udp_client_arch_t *obj)
{
}

me_size_t me_net_udp_client_sendto_arch(me_net_udp_client_arch_t *obj, const me_uint8_t *data, me_size_t size, const me_net_endpoint_t *remote_ep)
{
	return (0u);
}

me_size_t me_net_udp_client_recvfrom_arch(me_net_udp_client_arch_t *obj, me_uint8_t *buffer, me_size_t size, me_net_endpoint_t *remote_ep, me_uint32_t timeout_msec)
{
	return (0u);
}


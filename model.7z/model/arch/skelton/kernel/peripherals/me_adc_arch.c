#include "me_adc_arch.h"


me_bool_t me_adc_initialize_arch(void)
{
	return (ME_FALSE);
}

void me_adc_finalize_arch(void)
{
}

me_bool_t me_adc_value_get_arch(me_uint16_t adc_id)
{
	return (ME_FALSE);
}

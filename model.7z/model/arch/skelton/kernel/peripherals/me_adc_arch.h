#ifndef ME_ADC_ARCH_H_
#define ME_ADC_ARCH_H_

#include "kernel/peripherals/me_adc_stddef.h"


me_bool_t					me_adc_initialize_arch(void);
void						me_adc_finalize_arch(void);

me_bool_t					me_adc_value_get_arch(me_uint16_t adc_id);


#endif

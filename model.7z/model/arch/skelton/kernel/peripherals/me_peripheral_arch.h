#ifndef ME_PERIPHERAL_ARCH_H_
#define ME_PERIPHERAL_ARCH_H_

#include "kernel/me_kernel.h"


me_bool_t			me_peripheral_initialize_arch(void);
void				me_peripheral_finalize_arch(void);


#endif

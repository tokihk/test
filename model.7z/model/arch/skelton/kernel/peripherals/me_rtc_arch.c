#include "me_rtc_arch.h"

#include "kernel/peripherals/me_rtc_arch.h"


me_bool_t me_rtc_initialize_arch(void)
{
	return (ME_FALSE);
}

void me_rtc_finalize_arch(void)
{
}

me_bool_t me_rtc_datetime_get_arch(struct me_datetime_t *dt)
{
	return (ME_FALSE);
}

me_bool_t me_rtc_datetime_set_arch(const struct me_datetime_t *dt)
{
	return (ME_FALSE);
}

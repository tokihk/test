#ifndef ME_RTC_ARCH_H_
#define ME_RTC_ARCH_H_

#include "kernel/core/me_stddef.h"

#include "kernel/core/me_datetime.h"


me_bool_t					me_rtc_initialize_arch(void);
void						me_rtc_finalize_arch(void);

me_bool_t					me_rtc_datetime_get_arch(struct me_datetime_t *dt);

me_bool_t					me_rtc_datetime_set_arch(const struct me_datetime_t *dt);


#endif

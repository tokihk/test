#include "kernel/base/me_datetime_arch.h"

#include <time.h>


#ifdef __GNUC__
#define localtime_s			localtime_r
#define gmtime_s			gmtime_r
#endif


static me_uint64_t me_datetime_now_epoch_msec_arch(void)
{
	me_uint64_t time_ms = 0;
	struct timespec tspec = {0};

	if (clock_gettime(CLOCK_REALTIME, &tspec) == 0) {
		time_ms = (me_uint64_t)((me_uint64_t)tspec.tv_sec * 1000ul + (me_uint64_t)tspec.tv_nsec / 1000000ul);
	}

	return (time_ms);
}

me_bool_t me_datetime_now_arch(me_datetime_t *dt)
{
	me_bool_t success = ME_FALSE;

	if (dt != NULL) {
		me_uint64_t epoch_msec = me_datetime_now_epoch_msec_arch();

		if (epoch_msec > 0) {
			time_t epoch;
			struct tm tm_v;

			/* エポックタイムに変換 */
			epoch = epoch_msec / 1000;

			/* ローカル時刻を取得 */
			if (localtime_s(&epoch, &tm_v) != NULL) {
				dt->year = (me_uint16_t)(tm_v.tm_year + 1900);
				dt->month = (me_uint8_t)(tm_v.tm_mon + 1);
				dt->day = (me_uint8_t)tm_v.tm_mday;
				dt->hour = (me_uint8_t)tm_v.tm_hour;
				dt->min = (me_uint8_t)tm_v.tm_min;
				dt->sec = (me_uint8_t)tm_v.tm_sec;
				dt->msec = (me_uint16_t)(epoch_msec % 1000);
				dt->local = ME_TRUE;

				success = ME_TRUE;
			}
		}
	}

	return (success);
}

me_bool_t me_datetime_now_utc_arch(me_datetime_t *dt)
{
	me_bool_t success = ME_FALSE;

	if (dt != NULL) {
		me_uint64_t epoch_msec = me_datetime_now_epoch_msec_arch();

		if (epoch_msec > 0) {
			time_t epoch;
			struct tm tm_v;

			/* エポックタイムに変換 */
			epoch = epoch_msec / 1000;

			/* UTC時刻を取得 */
			if (gmtime_s(&epoch, &tm_v) != NULL) {
				dt->year = (me_uint16_t)(tm_v.tm_year + 1900);
				dt->month = (me_uint8_t)(tm_v.tm_mon + 1);
				dt->day = (me_uint8_t)tm_v.tm_mday;
				dt->hour = (me_uint8_t)tm_v.tm_hour;
				dt->min = (me_uint8_t)tm_v.tm_min;
				dt->sec = (me_uint8_t)tm_v.tm_sec;
				dt->msec = (me_uint16_t)(epoch_msec % 1000);
				dt->local = ME_FALSE;

				success = ME_TRUE;
			}
		}
	}

	return (success);
}

/* ###################################################################### *//**
 *
 *	@addtogroup	Kernel
 *	@{
 *	@file		me_datetime_arch.h
 *	@brief		Datetime Module (for Linux GCC)
 *	@author		Copyright (C) 2019 Hitoshi Kouno
 *
*//* ####################################################################### */
#ifndef ME_DATETIME_ARCH_H_
#define ME_DATETIME_ARCH_H_

#include "kernel/me_kernel.h"


me_bool_t			me_datetime_now_arch(me_datetime_t *dt);
me_bool_t			me_datetime_now_utc_arch(me_datetime_t *dt);


#endif /* ME_MUTEX_ARCH_H_ */
/* ####### File End ###### */
/** @} */

#if XENV_LIB_RTOS_FREERTOS
#include "me_mutex_freertos_arch.c"
#else
#include "me_mutex_posix_arch.c"
#endif

#include "kernel/base/me_mutex_arch.h"


me_bool_t me_mutex_create_arch(me_mutex_arch_t *obj)
{
	me_bool_t success = ME_FALSE;

	if (pthread_mutex_init(&obj->param.mutex, NULL) == 0) {
		success = ME_TRUE;
	}

	return (success);
}

void me_mutex_destroy_arch(me_mutex_arch_t *obj)
{
	pthread_mutex_destroy(&obj->param.mutex);
}

void me_mutex_lock_arch(me_mutex_arch_t *obj)
{
	pthread_mutex_lock(&obj->param.mutex);
}

me_bool_t me_mutex_trylock_arch(me_mutex_arch_t *obj)
{
	me_bool_t lock = ME_FALSE;

	if (pthread_mutex_trylock(&obj->param.mutex) == 0) {
		lock = ME_TRUE;
	}

	return (lock);
}

void me_mutex_unlock_arch(me_mutex_arch_t *obj)
{
	pthread_mutex_unlock(&obj->param.mutex);
}

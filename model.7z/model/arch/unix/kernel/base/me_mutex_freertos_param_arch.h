/* ###################################################################### *//**
 *
 *	@addtogroup	Kernel
 *	@{
 *	@file		me_mutex_arch.h
 *	@brief		Mutex Module (for Linux GCC)
 *	@author		Copyright (C) 2019 Hitoshi Kouno
 *
*//* ####################################################################### */
#ifndef ME_MUTEX_FREERTOS_PARAM_ARCH_H_
#define ME_MUTEX_FREERTOS_PARAM_ARCH_H_

#include "kernel/me_kernel.h"

#include "FreeRTOS.h"
#include "semphr.h"


typedef struct me_mutex_param_arch
{
	xSemaphoreHandle		handle;
} me_mutex_param_arch_t;


#endif /* ME_MUTEX_FREERTOS_PARAM_ARCH_H_ */
/* ####### File End ###### */
/** @} */

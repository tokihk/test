/* ###################################################################### *//**
 *
 *	@addtogroup	Kernel
 *	@{
 *	@file		me_mutex_param_arch.h
 *	@brief		Mutex Module
 *	@author		Copyright (C) 2019 Hitoshi Kouno
 *
*//* ####################################################################### */
#ifndef ME_MUTEX_PARAM_ARCH_H_
#define ME_MUTEX_PARAM_ARCH_H_

#include "kernel/me_kernel.h"


#if XENV_LIB_RTOS_FREERTOS
#include "me_mutex_freertos_param_arch.h"
#else
#include "me_mutex_posix_param_arch.h"
#endif


#endif /* ME_MUTEX_PARAM_ARCH_H_ */
/* ####### File End ###### */
/** @} */

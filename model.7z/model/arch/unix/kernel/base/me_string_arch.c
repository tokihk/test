#include "me_string_arch.h"

#include <string.h>
#include <stdio.h>
#include <wchar.h>


me_int32_t me_string_vsnprintf_arch(me_char_t *dst, me_size_t size, const me_char_t *format, va_list args)
{
	int ret;

#if ME_OPTION_CHAR_IS_WCHAR
	ret = (me_int32_t)vswprintf(dst, size, format, args);
	if (ret < 0) {
		ret = -1;
	}
#else
	ret = (me_int_t)vsnprintf(dst, size, format, args);
	if (ret > (me_int_t)size) {
		ret = -1;
	}
#endif

	return (ret);
}


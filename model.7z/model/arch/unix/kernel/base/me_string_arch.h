#ifndef ME_STRING_ARCH_H_
#define ME_STRING_ARCH_H_

#include "kernel/me_kernel.h"

#include <stdarg.h>


me_int32_t					me_string_vsnprintf_arch(me_char_t *dst, me_size_t size, const me_char_t *format, va_list args);


#endif

#include "kernel/base/me_task_arch.h"

#include <unistd.h>
#include <fcntl.h>


static void *me_task_main(void *param)
{
	me_task_arch_t *obj = (me_task_arch_t *)param;
	int old_value;

	pthread_setcancelstate(PTHREAD_CANCEL_ENABLE, &old_value);
	pthread_setcanceltype(PTHREAD_CANCEL_ASYNCHRONOUS, &old_value);

	(obj->callback)(obj, obj->callback_param);

	pthread_exit(NULL);

	return (NULL);
}

void me_task_scheduler_initialize_arch(void)
{
}

void me_task_scheduler_finalize_arch(void)
{
}

void me_task_scheduler_exec_arch(void)
{
	for (;;) {
		sleep(1);
	}
}

me_bool_t me_task_create_arch(me_task_arch_t *obj, me_size_t stack_size, me_uint8_t priority, void (* callback)(struct me_task_arch *, void *), void *param)
{
	pthread_attr_t attr;

	obj->callback = callback;
	obj->callback_param = param;
	obj->running = ME_FALSE;

	if (pthread_attr_init(&attr) != 0) {
		return (ME_FALSE);
	}

	if (pthread_create(&obj->thread_id, &attr, me_task_main, obj) != 0) {
		return (ME_FALSE);
	}

	return (ME_TRUE);
}

void me_task_destroy_arch(me_task_arch_t *obj)
{
	pthread_cancel(obj->thread_id);
	obj->thread_id = 0;
}

void me_task_sleep_arch(me_uint32_t time_msec)
{
	struct timespec tspec;

	tspec.tv_sec = (time_t)(time_msec / 1000);
	tspec.tv_nsec = (long)time_msec % 1000 * 1000000;

	nanosleep(&tspec, NULL);
}

me_bool_t me_task_event_create_arch(me_task_event_arch_t *obj)
{
	me_bool_t success = ME_FALSE;

	if (pipe(obj->pipe_handle) == 0) {
		success = ME_TRUE;
	}

	return (success);
}

void me_task_event_destroy_arch(me_task_event_arch_t *obj)
{
	close(obj->pipe_handle[0]);
	close(obj->pipe_handle[1]);
}

me_bool_t me_task_event_send_arch(me_task_event_arch_t *obj)
{
	me_bool_t success = ME_FALSE;
	me_uint8_t send_data = 0;

	if (write(obj->pipe_handle[1], &send_data, 1) > 0) {
		success = ME_TRUE;
	}

	return (success);
}

me_bool_t me_task_event_wait_arch(me_task_event_arch_t *obj)
{
	me_bool_t success = ME_FALSE;
	me_uint8_t recv_data;

	if (read(obj->pipe_handle[0], &recv_data, 1) > 0) {
		success = ME_TRUE;
	}

	return (success);
}

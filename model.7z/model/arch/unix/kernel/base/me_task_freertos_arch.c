#include "kernel/base/me_task_arch.h"


static void me_task_main_arch(void *param)
{
}

me_bool_t me_task_create_arch(me_task_arch_t *obj, me_uint8_t *stack_area, me_size_t stack_size, me_uint8_t priority, void (* callback)(struct me_task_arch *, void *), void *param)
{
	me_bool_t success = ME_FALSE;
	me_size_t stack_size_adj = 0x0001;
	xTaskParameters task_param =
	{
		.pvTaskCode     = me_task_main_arch,
		.pcName         = (signed char *)"",
		.pvParameters   = param,
		.uxPriority     = (unsigned portBASE_TYPE)priority,
		.puxStackBuffer = (portSTACK_TYPE *)stack_area,
	};

	/* スタックサイズは2のべき乗 */
	while ((stack_size_adj << 1) < stack_size) {
		stack_size_adj <<= 1;
	}

	/* portSTACK_TYPEの倍数で調節 */
	task_param.usStackDepth = stack_size_adj / sizeof(portSTACK_TYPE);

	if (xTaskCreateRestricted(&task_param, &obj->param.handle) == pdPASS) {
		success = ME_TRUE;
	}

	return (success);
}

void me_task_destroy_arch(me_task_arch_t *obj)
{

}

void me_task_suspend_arch(me_task_arch_t *obj)
{

}

void me_task_resume_arch(me_task_arch_t *obj)
{

}

void me_task_sleep_arch(me_uint32_t time_msec)
{

}


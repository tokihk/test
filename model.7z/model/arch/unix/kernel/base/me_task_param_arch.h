/* ###################################################################### *//**
 *
 *	@addtogroup	Kernel
 *	@{
 *	@file		me_task_param_arch.h
 *	@brief		Task Module Parameter
 *	@author		Copyright (C) 2019 Hitoshi Kouno
 *
*//* ####################################################################### */
#ifndef ME_TASK_PARAM_ARCH_H_
#define ME_TASK_PARAM_ARCH_H_

#include "kernel/me_kernel.h"

#include <pthread.h>


typedef struct me_task_param_arch
{
	pthread_t			thread_id;
	me_bool_t			running;
} me_task_param_arch_t;

typedef struct me_task_event_param_arch
{
	me_int_t			handle[2];
} me_task_event_param_arch_t;


#endif /* ME_TASK_PARAM_ARCH_H_ */
/* ####### File End ###### */
/** @} */

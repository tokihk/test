/* ###################################################################### *//**
 *
 *	@addtogroup	Kernel
 *	@{
 *	@file		me_task_param_arch.h
 *	@brief		Task Module Parameter
 *	@author		Copyright (C) 2019 Hitoshi Kouno
 *
*//* ####################################################################### */
#ifndef ME_TASK_PARAM_ARCH_H_
#define ME_TASK_PARAM_ARCH_H_

#include "kernel/me_kernel.h"


#if XENV_LIB_RTOS_FREERTOS
#include "me_task_freertos_param_arch.h"
#endif


#endif /* ME_TASK_PARAM_ARCH_H_ */
/* ####### File End ###### */
/** @} */

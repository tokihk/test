#include "me_thread_arch.h"

#include <time.h>
#include <unistd.h>


#define ME_THREAD_ARCH_POLL_IVAL			(1u)


static void *me_thread_main_arch(void *arg)
{
	me_thread_arch_t *arch = (me_thread_arch_t *)(arg);
	int old_state;
	int old_type;

	pthread_setcancelstate(PTHREAD_CANCEL_ENABLE, &old_state);
	pthread_setcanceltype(PTHREAD_CANCEL_ASYNCHRONOUS, &old_type);

	arch->active = ME_TRUE;

	while (!arch->running) {}

	if (arch->callback != NULL) {
		(arch->callback)(arch, arch->callback_param);
	}

	arch->active = ME_FALSE;

	pthread_exit(NULL);

	return (NULL);
}

me_bool_t me_thread_initialize_arch(me_thread_arch_t *obj, void (* callback)(struct me_thread_arch *, void *), void *param)
{
	me_bool_t success = ME_FALSE;

	if ((obj != NULL) && (callback != NULL)) {
		int result;

		obj->active = ME_FALSE;
		obj->running = ME_FALSE;
		obj->callback = callback;
		obj->callback_param = param;

		result = pthread_create(&obj->thread_id, NULL, me_thread_main_arch, obj);
		if (result == 0) {
			while (!obj->active) {}
			success = ME_TRUE;
		}
	}

	return (success);
}

void me_thread_finalize_arch(me_thread_arch_t *obj)
{
	if (obj != NULL) {
		if (obj->active) {
			pthread_cancel(obj->thread_id);
			pthread_join(obj->thread_id, NULL);
			obj->active = ME_FALSE;
		}
	}
}

void me_thread_start_arch(me_thread_arch_t *obj)
{
	if (obj != NULL) {
		obj->running = ME_TRUE;
	}
}

me_bool_t me_thread_is_active_arch(me_thread_arch_t *obj)
{
	me_bool_t active = ME_FALSE;

	if (obj != NULL) {
		active = obj->active;
	}

	return (active);
}

void me_thread_exit_arch(void)
{
	pthread_exit(NULL);
}

void me_thread_sleep_arch(me_uint32_t time_s)
{
	sleep(time_s);
}

void me_thread_sleep_ms_arch(me_uint32_t time_ms)
{
	struct timespec ts = {0};

	ts.tv_sec = time_ms / 1000;
	ts.tv_nsec = (time_ms % 1000) * 1000000;

	nanosleep(&ts, NULL);
}

/* ###################################################################### *//**
 *
 *	@addtogroup	Kernel
 *	@{
 *	@file		me_thread_arch.h
 *	@brief		Thread Module
 *	@author		Copyright (C) 2019 Hitoshi Kouno
 *
*//* ####################################################################### */
#ifndef ME_THREAD_ARCH_H_
#define ME_THREAD_ARCH_H_

#include "kernel/me_kernel.h"

#include <pthread.h>


typedef struct me_thread_arch
{
	pthread_attr_t			attr;
	pthread_t				thread_id;
	void					(* callback)(struct me_thread_arch *, void *);
	void *					callback_param;
	me_bool_t				active;
	me_bool_t				running;
} me_thread_arch_t;


me_bool_t				me_thread_initialize_arch(me_thread_arch_t *obj, void (* callback)(struct me_thread_arch *, void *), void *param);
void					me_thread_finalize_arch(me_thread_arch_t *obj);

void					me_thread_start_arch(me_thread_arch_t *obj);

me_bool_t				me_thread_is_active_arch(me_thread_arch_t *obj);

void					me_thread_exit_arch(void);

void					me_thread_sleep_arch(me_uint32_t time_s);
void					me_thread_sleep_ms_arch(me_uint32_t time_ms);


#endif /* ME_THREAD_ARCH_H_ */
/* ####### File End ###### */
/** @} */

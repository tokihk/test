#ifndef ME_TYPEDEF_ARCH_H_
#define ME_TYPEDEF_ARCH_H_

#include <stddef.h>
#include <stdint.h>
#include <wchar.h>
#include <limits.h>
#include <pthread.h>

	typedef unsigned char						me_uint8_t;
	typedef unsigned short						me_uint16_t;
	typedef unsigned int						me_uint32_t;
	typedef unsigned long long					me_uint64_t;

	typedef signed char							me_int8_t;
	typedef signed short						me_int16_t;
	typedef signed int							me_int32_t;
	typedef signed long long					me_int64_t;

	typedef char								me_achar_t;
	typedef wchar_t								me_wchar_t;

	typedef unsigned char						me_bool_t;
	typedef size_t								me_size_t;

	#define ME_SIZE_MAX							SIZE_MAX

	#define ME_MB_LEN_MAX						MB_LEN_MAX

	typedef struct me_task_arch
	{
		pthread_t				thread_id;
		me_bool_t				running;
		pthread_t				task_handle;
		void					(* callback)(struct me_task_arch *, void *);
		void *					callback_param;
	} me_task_arch_t;

	typedef struct me_task_event_arch
	{
		me_int_t				pipe_handle[2];
	} me_task_event_arch_t;

	typedef struct me_mutex_arch
	{
		pthread_mutex_t			mutex;
	} me_mutex_arch_t;

#endif

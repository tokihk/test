#include "kernel/dev/me_gpio_arch.h"

#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <poll.h>


static const char ME_DEV_GPIO_WORD_DIR_INPUT[]  = {'i', 'n'};
static const char ME_DEV_GPIO_WORD_DIR_OUTPUT[] = {'o', 'u', 't'};


static me_uint16_t me_gpio_func_to_pin_arch(me_uint16_t gpio_id)
{
	if (gpio_id >= ME_DEV_GPIO_FUNC_TOP) {
		gpio_id -= ME_DEV_GPIO_FUNC_TOP;
	}

	return (gpio_id);
}

me_bool_t me_gpio_initialize_arch(void)
{
	return (ME_TRUE);
}

void me_gpio_finalize_arch(void)
{
}

me_bool_t me_gpio_direction_get_arch(me_uint16_t gpio_id)
{
	me_bool_t value = ME_FALSE;
	int fd;
	char path[48];
	char value_c;

	gpio_id = me_gpio_func_to_pin_arch(gpio_id);

	/* ポートクラスパス設定 */
	snprintf(path, sizeof(path), "/sys/class/gpio/gpio%d/value", gpio_id);

	/* 読み込み */
	fd = open(path, O_RDONLY);
	if (fd != -1) {
		read(fd, &value_c, 1);
		if (value_c == '1') {
			value = ME_TRUE;
		}
		close(fd);
	}

	return (value);
}

void me_gpio_direction_set_arch(me_uint16_t gpio_id, me_bool_t dir)
{
	int fd;
	char path[48];
	char port_no[8];

	gpio_id = me_gpio_func_to_pin_arch(gpio_id);

	/* ポート番号文字列設定 */
	snprintf(port_no, sizeof(port_no), "%u", gpio_id);

	/* ポートクラスパス設定 */
	snprintf(path, sizeof(path), "/sys/class/gpio/gpio%s/direction", port_no);

	do {
		/* 設定 */
		fd = open(path, O_WRONLY);
		if (fd != -1) {
			if (dir) {
				write(fd, ME_DEV_GPIO_WORD_DIR_OUTPUT, sizeof(ME_DEV_GPIO_WORD_DIR_OUTPUT));
			} else {
				write(fd, ME_DEV_GPIO_WORD_DIR_INPUT, sizeof(ME_DEV_GPIO_WORD_DIR_INPUT));
			}
			close(fd);
			break;
		}

		/* 設定できない場合はポート有効化 */
		fd = open("/sys/class/gpio/export", O_WRONLY);
		if (fd != -1) {
			write(fd, port_no, strnlen(port_no, sizeof(port_no)));
			close(fd);
			continue;
		}
	} while (0);
}

me_bool_t me_gpio_value_get_arch(me_uint16_t gpio_id)
{
	me_bool_t value = ME_FALSE;
	int fd;
	char path[48];
	char value_c;

	gpio_id = me_gpio_func_to_pin_arch(gpio_id);

	/* ポートクラスパス設定 */
	snprintf(path, sizeof(path), "/sys/class/gpio/gpio%d/value", gpio_id);

	/* 読み込み */
	fd = open(path, O_RDONLY);
	if (fd != -1) {
		read(fd, &value_c, 1);
		if (value_c == '1') {
			value = ME_TRUE;
		}
		close(fd);
	}

	return (value);
}

void me_gpio_value_set_arch(me_uint16_t gpio_id, me_bool_t value)
{
	int fd;
	char path[48];

	gpio_id = me_gpio_func_to_pin_arch(gpio_id);

	/* ポートクラスパス設定 */
	snprintf(path, sizeof(path), "/sys/class/gpio/gpio%d/value", gpio_id);

	/* 設定 */
	fd = open(path, O_WRONLY);
	if (fd != -1) {
		write(fd, &value, 1);
		close(fd);
	}
}


#include "me_dev_gpio_arch.h"

#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <poll.h>


const static char ME_DEV_GPIO_WORD_DIR_INPUT[]  = {'i', 'n'};
const static char ME_DEV_GPIO_WORD_DIR_OUTPUT[] = {'o', 'u', 't'};


void me_dev_gpio_initialize_arch(void)
{
}

void me_dev_gpio_finalize_arch(void)
{
}

me_bool_t me_dev_gpio_direction_get_arch(enum me_dev_gpio_pin_arch pin)
{
	return (ME_FALSE);
}

void me_dev_gpio_direction_set_arch(enum me_dev_gpio_pin_arch pin, me_bool_t dir)
{
	int fd;
	char path[64];
	char port_no_

	do {
		/* 設定 */
		snprintf(path, "/sys/class/gpio/gpio%u/direction", (me_uint32_t)pin);
		fd = open(path, O_WRONLY);
		if (fd != -1) {
			if (dir) {
				write(fd, ME_DEV_GPIO_WORD_DIR_OUTPUT, sizeof(ME_DEV_GPIO_WORD_DIR_OUTPUT));
			} else {
				write(fd, ME_DEV_GPIO_WORD_DIR_INPUT, sizeof(ME_DEV_GPIO_WORD_DIR_INPUT));
			}
			close(fd);
			break;
		}

		/* 設定できない場合はポート有効化 */
		snprintf(path, "/sys/class/gpio/gpio%u/direction", (me_uint32_t)pin);

	} while (0);

	fd = open("/sys/class/gpio/export", O_WRONLY);
	if (fd != -1) {
		char port_no_str[32];

		snprintf(port_no_str, "%u", (me_uint32_t)pin);

		write(fd, port_no_str, strnlen(port_no_str, sizeof(port_no_str)));

		close(fd);
	}
}

me_bool_t me_dev_gpio_value_get_arch(enum me_dev_gpio_pin_arch pin)
{
	return (ME_FALSE);
}

void me_dev_gpio_value_set_arch(enum me_dev_gpio_pin_arch pin, me_bool_t value)
{
}


#include "kernel/dev/me_dev_timer_arch.h"

#include <sys/timerfd.h>
#include <sys/time.h>
#include <poll.h>
#include <signal.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <errno.h>
#include <pthread.h>


#define ME_DEV_TIMER_ID_MAX_ARCH		(10)


static struct me_dev_timer_arch
{
	pthread_t					thread_id;

	struct pollfd				pf_poll[ME_DEV_TIMER_ID_MAX_ARCH + 1];

	me_int_t					fd_timer[ME_DEV_TIMER_ID_MAX_ARCH];
	me_int_t					fd_control[2];

	me_dev_timer_callback_t		callback[ME_DEV_TIMER_ID_MAX_ARCH];

	me_bool_t					thread_exist;
} g_me_dev_timer_arch;


static void me_dev_timer_thread_exit_arch(void)
{
	if (g_me_dev_timer_arch.thread_exist) {
		if (g_me_dev_timer_arch.fd_control[1] >= 0) {
			me_uint8_t data = 0;

			if (write(g_me_dev_timer_arch.fd_control[1], &data, 1) > 0) {
				pthread_join(g_me_dev_timer_arch.thread_id, NULL);
			}
		} else {
			pthread_cancel(g_me_dev_timer_arch.thread_id);
			pthread_join(g_me_dev_timer_arch.thread_id, NULL);
		}

		g_me_dev_timer_arch.thread_exist = ME_FALSE;
	}
}

static void *me_dev_timer_thread_arch(void *param)
{
	me_bool_t exit_req = ME_FALSE;
	me_int_t ret;
	me_size_t index;
	uint64_t recv_data;

	pthread_setcancelstate(PTHREAD_CANCEL_ENABLE, &ret);
	pthread_setcanceltype(PTHREAD_CANCEL_ASYNCHRONOUS, &ret);

	while (!exit_req) {
		ret = poll(g_me_dev_timer_arch.pf_poll, ME_COUNTOF(g_me_dev_timer_arch.pf_poll), 1000);
		if (ret > 0) {
			for (index = 0; index < ME_COUNTOF(g_me_dev_timer_arch.pf_poll); index++) {
				if ((g_me_dev_timer_arch.pf_poll[index].revents & POLLIN) != 0) {
					if (read(g_me_dev_timer_arch.pf_poll[index].fd, &recv_data, sizeof(recv_data)) > 0) {
						if (index < ME_DEV_TIMER_ID_MAX_ARCH) {
							/* タイマーイベント */
							if (g_me_dev_timer_arch.callback[index] != NULL) {
								(g_me_dev_timer_arch.callback[index])((me_uint16_t)(index));
							}
						} else {
							/* 制御イベント */
							exit_req = ME_TRUE;
							break;
						}
					}
				}
			}
		}
	}

	pthread_exit(NULL);

	return (NULL);
}

me_bool_t me_dev_timer_initialize_arch(void)
{
	me_bool_t success = ME_FALSE;
	me_size_t index;

	/* 全監視FDを無効化 */
	for (index = 0; index < ME_COUNTOF(g_me_dev_timer_arch.pf_poll); index++) {
		g_me_dev_timer_arch.pf_poll[index].fd = -1;
		g_me_dev_timer_arch.pf_poll[index].events = POLLIN;
	}

	/* 全タイマーFDを無効化 */
	for (index = 0; index < ME_COUNTOF(g_me_dev_timer_arch.fd_timer); index++) {
		g_me_dev_timer_arch.fd_timer[index] = -1;
	}

	/* 制御用パイプ作成 */
	if (pipe(g_me_dev_timer_arch.fd_control) == 0) {
		/* 最後の監視FDに制御用パイプを設定 */
		g_me_dev_timer_arch.pf_poll[ME_COUNTOF(g_me_dev_timer_arch.pf_poll) - 1].fd = g_me_dev_timer_arch.fd_control[0];

		/* タイマースレッド開始 */
		if (pthread_create(&g_me_dev_timer_arch.thread_id, NULL, me_dev_timer_thread_arch, NULL) == 0) {
			g_me_dev_timer_arch.thread_exist = ME_TRUE;
			success = ME_TRUE;
		}
	} else {
		/* pipe作成失敗時は無効なディスクリプタを設定 */
		g_me_dev_timer_arch.fd_control[0] = -1;
		g_me_dev_timer_arch.fd_control[1] = -1;
	}

	return (success);
}

void me_dev_timer_finalize_arch(void)
{
	me_uint16_t index;

	/* タイマースレッド停止 */
	me_dev_timer_thread_exit_arch();

	/* 全タイマー終了 */
	for (index = 0; index < ME_COUNTOF(g_me_dev_timer_arch.fd_timer); index++) {
		me_dev_timer_destroy_arch(index);
	}

	/* 制御用パイプを終了 */
	for (index = 0; index < ME_COUNTOF(g_me_dev_timer_arch.fd_control); index++) {
		close(g_me_dev_timer_arch.fd_control[index]);
	}
}

me_bool_t me_dev_timer_create_arch(me_uint16_t tmr_id, me_uint32_t ival_10nsec, me_dev_timer_callback_t callback)
{
	me_bool_t success = ME_FALSE;

	/* 割り当て中であれば解放 */
	me_dev_timer_destroy_arch(tmr_id);

	if (tmr_id < ME_COUNTOF(g_me_dev_timer_arch.fd_timer)) {
		struct itimerspec ts;

		g_me_dev_timer_arch.fd_timer[tmr_id] = timerfd_create(CLOCK_REALTIME, 0);
		if (g_me_dev_timer_arch.fd_timer[tmr_id] >= 0) {
			ts.it_interval.tv_sec  = ival_10nsec / 100000000;
			ts.it_interval.tv_nsec = (ival_10nsec % 100000000) * 10;
			ts.it_value = ts.it_interval;

			if (timerfd_settime(g_me_dev_timer_arch.fd_timer[tmr_id], TFD_TIMER_ABSTIME, &ts, NULL) == 0){
				g_me_dev_timer_arch.callback[tmr_id] = callback;

				/* 監視ディスクリプタに設定 */
				g_me_dev_timer_arch.pf_poll[tmr_id].fd = g_me_dev_timer_arch.fd_timer[tmr_id];

				success = ME_TRUE;
			}
		}
	}

	return (success);
}

void me_dev_timer_destroy_arch(me_uint16_t tmr_id)
{
	if (tmr_id < ME_COUNTOF(g_me_dev_timer_arch.fd_timer)) {
		g_me_dev_timer_arch.callback[tmr_id] = NULL;

		/* 監視ディスクリプタから外す */
		g_me_dev_timer_arch.pf_poll[tmr_id].fd = -1;

		/* タイマー削除 */
		if (g_me_dev_timer_arch.fd_timer[tmr_id] >= 0) {
			close(g_me_dev_timer_arch.fd_timer[tmr_id]);
			g_me_dev_timer_arch.fd_timer[tmr_id] = -1;
		}
	}
}


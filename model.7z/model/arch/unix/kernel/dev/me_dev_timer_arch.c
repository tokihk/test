#include "kernel/dev/me_dev_timer_arch.h"


void me_dev_timer_initialize_arch(void)
{
}

void me_dev_timer_finalize_arch(void)
{
}

me_bool_t me_dev_timer_create_arch(me_uint16_t tmr_id, me_uint32_t ival_hz)
{
	return (ME_FALSE);
}

void me_dev_timer_destroy_arch(me_uint16_t tmr_id)
{
}


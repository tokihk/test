#include "kernel/dev/me_device_arch.h"


void me_device_initialize_arch(void)
{

}

void me_device_finalize_arch(void)
{

}



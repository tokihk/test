#include "me_file_arch.h"

#include "kernel/base/me_main_system.h"
#include "kernel/base/me_string_utility.h"

#include <unistd.h>


me_bool_t me_current_dir_set_arch(const me_char_t *dir_path)
{
	me_bool_t set_ok = ME_FALSE;

	if (dir_path != NULL) {
		me_size_t dir_path_len;
		me_achar_t *dir_path_a;

		/* char型に変換 */
		dir_path_len = me_strcnlen(dir_path, ME_PATH_LENGTH_MAX + 1);
		dir_path_a = me_malloc(dir_path_len + 1);
		me_strancpy(dir_path_a, dir_path, dir_path_len + 1);

		if (chdir(dir_path_a) == 0) {
			set_ok = ME_TRUE;
		}
	}

	return (set_ok);
}

me_bool_t me_current_dir_get_arch(me_char_t *buffer, me_size_t buffer_size)
{
	me_bool_t get_ok = ME_FALSE;

	if ((buffer != NULL) && (buffer_size > 0)) {

	}

	return (get_ok);
}

me_bool_t me_make_directory_arch(const me_char_t *dir_path)
{
	me_bool_t make_ok = ME_FALSE;

	if (dir_path != NULL) {

	}

	return (make_ok);
}

void me_remove_directory_arch(const me_char_t *dir_path)
{
	if (dir_path != NULL) {

	}
}

void me_remove_file_arch(const me_char_t *file_path)
{
	if (file_path != NULL) {

	}
}

me_bool_t me_is_file_exist_arch(const me_char_t *file_path)
{
	me_bool_t exist = ME_FALSE;

	if (file_path != NULL) {

	}

	return (exist);
}

me_bool_t me_is_dir_exist_arch(const me_char_t *dir_path)
{
	me_bool_t exist = ME_FALSE;

	if (dir_path != NULL) {

	}

	return (exist);
}

me_bool_t me_file_open_arch(me_file_arch_t *obj, const me_char_t *file_path, enum me_file_mode mode)
{
	me_bool_t open_ok = ME_FALSE;

	if ((obj != NULL) && (file_path != NULL)) {

	}

	return (open_ok);
}

void me_file_close_arch(me_file_arch_t *obj)
{
	if (obj != NULL) {

	}
}

me_size_t me_file_read_arch(me_file_arch_t *obj, me_uint8_t *buffer, me_size_t buffer_size)
{
	me_size_t read_size = 0;

	if ((obj != NULL) && (buffer != NULL) && (buffer_size > 0)) {

	}

	return (read_size);
}

me_size_t me_file_write_arch(me_file_arch_t *obj, const me_uint8_t *data, me_uint16_t size)
{
	me_size_t write_size = 0;

	if ((obj != NULL) && (data != NULL) && (size > 0)) {

	}

	return (write_size);
}

#ifndef ME_FS_TYPEDEF_ARCH_H_
#define ME_FS_TYPEDEF_ARCH_H_

#include "kernel/me_kernel.h"

#include <stdio.h>


typedef struct me_file_arch
{
	FILE *			file;
} me_file_arch_t;


#endif

#include "kernel/net/me_net_board.h"

#include <string.h>
#include <arpa/inet.h>


me_bool_t me_net_initialize_arch(void)
{
	return (ME_TRUE);
}

void me_net_finalize_arch(void)
{
}

me_bool_t me_net_endpoint_get_arch(me_net_endpoint_arch_t *ep, enum me_net_domain_type dtype, const me_achar_t *hostname)
{
	me_bool_t success = ME_FALSE;
	struct addrinfo hints = {0};
	struct addrinfo *res = NULL;

	hints.ai_family   = (dtype == ME_NET_DOMAIN_TYPE_IPV6) ? (AF_INET6) : (AF_INET);
	hints.ai_socktype = SOCK_STREAM;
	hints.ai_flags    = AI_NUMERICSERV;

	if (getaddrinfo(hostname, NULL, &hints, &res) == 0) {
		memset(&ep->sa, 0, sizeof(ep->sa));
		memcpy(&ep->sa, res->ai_addr, res->ai_addrlen);
		success = ME_TRUE;

		freeaddrinfo(res);
	}

	return (success);
}

me_bool_t me_net_endpoint_to_text_arch(const me_net_endpoint_arch_t *ep, enum me_net_domain_type dtype, me_achar_t *ep_text, me_size_t ep_text_size)
{
	me_bool_t success = ME_FALSE;

	if (inet_ntop((dtype == ME_NET_DOMAIN_TYPE_IPV6) ? (AF_INET6) : (AF_INET), &((struct sockaddr_in *)&ep->sa)->sin_addr, ep_text, ep_text_size) != NULL) {
		success = ME_TRUE;
	}

	return (success);
}

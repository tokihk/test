#ifndef ME_NET_TYPEDEF_ARCH_H_
#define ME_NET_TYPEDEF_ARCH_H_

#include "kernel/me_kernel.h"

#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <poll.h>


typedef struct me_net_endpoint_arch
{
	struct sockaddr_storage		sa;
} me_net_endpoint_arch_t;

typedef struct me_net_tcp_server_arch
{
	me_int_t			fd_socket;
} me_net_tcp_server_arch_t;

typedef struct me_net_tcp_client_arch
{
	me_int_t			fd_socket;
} me_net_tcp_client_arch_t;

typedef struct me_net_udp_client_arch
{
	me_int_t			fd_socket;
	struct pollfd		pf_socket;
} me_net_udp_client_arch_t;


#endif

#include "kernel/net/me_net_udp_client_arch.h"

#include <unistd.h>
#include <stdio.h>
#include <arpa/inet.h>


static void me_net_udp_client_addrinfo_dump_arch(struct addrinfo *ai)
{
	struct addrinfo *ai_temp;
	me_achar_t addr_str[100];

	for (ai_temp = ai; ai_temp != NULL; ai_temp = ai_temp->ai_next) {
		inet_ntop(AF_INET, &((struct sockaddr_in *)ai_temp->ai_addr)->sin_addr, addr_str, sizeof(addr_str));
		printf(addr_str);
	}

	fflush(stdout);
}

me_bool_t me_net_udp_client_create_arch(me_net_udp_client_arch_t *obj, me_uint16_t local_port_no)
{
	me_bool_t success = ME_FALSE;
	struct addrinfo hints = {0};
	struct addrinfo *res = NULL;
	char port_no_str[16];

	obj->fd_socket = -1;

	hints.ai_family   = AF_INET;
	hints.ai_socktype = SOCK_DGRAM;
	hints.ai_flags    = AI_PASSIVE;

	snprintf(port_no_str, ME_COUNTOF(port_no_str), "%u", local_port_no);

	if (getaddrinfo(NULL, port_no_str, &hints, &res) == 0) {

		me_net_udp_client_addrinfo_dump_arch(res);

		obj->fd_socket = socket(res->ai_family, res->ai_socktype, res->ai_protocol);
		if (obj->fd_socket >= 0) {
			if (bind(obj->fd_socket, res->ai_addr, res->ai_addrlen) == 0) {
				obj->pf_socket.fd = obj->fd_socket;
				obj->pf_socket.events = POLLIN;

				success = ME_TRUE;
			}
		}

		freeaddrinfo(res);
	}

	if (!success) {
		close(obj->fd_socket);
		obj->fd_socket = -1;
	}

	return (success);
}

void me_net_udp_client_destroy_arch(me_net_udp_client_arch_t *obj)
{
	if (obj->fd_socket >= 0) {
		shutdown(obj->fd_socket, SHUT_RDWR);
		close(obj->fd_socket);
		obj->fd_socket = -1;
	}
}

me_size_t me_net_udp_client_sendto_arch(me_net_udp_client_arch_t *obj, const me_uint8_t *data, me_size_t size, const me_net_endpoint_arch_t *remote_ep)
{
	ssize_t ret;

	ret = sendto(obj->fd_socket, data, size, 0, (const struct sockaddr *)&remote_ep->sa, sizeof(remote_ep->sa));
	if (ret < 0) {
		ret = 0;
	}

	return ((me_size_t)ret);
}

me_size_t me_net_udp_client_recvfrom_arch(me_net_udp_client_arch_t *obj, me_uint8_t *buffer, me_size_t size, me_net_endpoint_arch_t *remote_ep, me_uint32_t timeout_msec)
{
	ssize_t  ret_recv = 0;
	me_int_t ret_poll;
	socklen_t recv_addr_len = sizeof(remote_ep->sa);

	ret_poll = poll(&obj->pf_socket, 1, (int)timeout_msec);
	if (ret_poll > 0) {
		ret_recv = recvfrom(obj->fd_socket, buffer, size, 0, (struct sockaddr *)&remote_ep->sa, &recv_addr_len);
		if (ret_recv > 0) {
		} else if (ret_recv < 0) {
			ret_recv = 0;
		}
	}

	return ((me_size_t)ret_recv);
}


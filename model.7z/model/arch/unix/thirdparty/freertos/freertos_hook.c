
void vMainQueueSendPassed( void )
{
}

void vApplicationIdleHook( void )
{
}

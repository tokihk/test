#include "drivers/display/drv_display_board.h"

#include "drivers/display/drv_display_typedef.h"

#include "kernel/dev/me_dev_spi.h"


enum drv_display_id
{
	DRV_DISPLAY_ID_ILI9341_SPI,
};

static me_size_t drv_display_ili9341_spi_send(const me_uint8_t *data, me_size_t size)
{
	return (0);
}

static me_size_t drv_display_ili9341_spi_recv(me_uint8_t *buffer, me_size_t buffer_size)
{
	return (0);
}

static const drv_display_interface_t DRV_DISPLAY_INTERFACE_ILI9341 =
{
	.send = drv_display_ili9341_spi_send,
	.recv = drv_display_ili9341_spi_recv,
};

static me_bool_t drv_display_ili9341_initialize(void)
{
	me_dev_spi_setup(0, ME_DEV_SPI_MODE_MASTER, 12000000);

	return (ME_TRUE);
}

static void drv_display_ili9341_finalize(void)
{
}

static me_bool_t drv_display_ili9341_transfer_rect(me_uint16_t display_id, const me_uint8_t *data, me_size_t size)
{
	return (ME_TRUE);
}

me_bool_t drv_display_initialize_board(me_uint16_t display_id)
{
	me_bool_t success = ME_FALSE;

	switch (display_id) {
		case DRV_DISPLAY_ID_ILI9341_SPI:
			success = drv_display_ili9341_initialize();
			break;
		default:
			break;
	}

	return (success);
}

void drv_display_finalize_board(me_uint16_t display_id)
{
	switch (display_id) {
		case DRV_DISPLAY_ID_ILI9341_SPI:
			drv_display_ili9341_finalize();
			break;
		default:
			break;
	}
}

me_bool_t drv_display_transfer_rect_board(me_uint16_t display_id, const me_uint8_t *data, me_size_t size)
{
	me_bool_t success = ME_FALSE;

	switch (display_id) {
		case DRV_DISPLAY_ID_ILI9341_SPI:
			success = drv_display_ili9341_transfer_rect(display_id, data, size);
			break;
		default:
			break;
	}

	return (success);
}



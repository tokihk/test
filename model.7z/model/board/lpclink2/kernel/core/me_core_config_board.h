#ifndef ME_CORE_CONFIG_BOARD_H_
#define ME_CORE_CONFIG_BOARD_H_

#include "kernel/core/me_core_config_arch.h"

#endif

#include "board/skelton/kernel/dev/me_dev_spi_board.c"

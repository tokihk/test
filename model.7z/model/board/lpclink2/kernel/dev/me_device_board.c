#include "kernel/dev/me_device_board.h"

#include "chip.h"


me_bool_t me_device_initialize_board(void)
{
	me_bool_t success = ME_FALSE;

	if (me_device_initialize_arch()) {
		/* Set up clock and muxing for SSP1 interface */
		/* SSEL: P1.20: J3 PIN-6 [Serial Expansion Interface] */
		Chip_SCU_PinMuxSet(0x1, 20, (SCU_PINIO_FAST | SCU_MODE_FUNC1));
		/* MISO: P1.3: J3 PIN-5 [Serial Expansion Interface] */
		Chip_SCU_PinMuxSet(0x1, 3, (SCU_MODE_INACT | SCU_MODE_INBUFF_EN | SCU_MODE_ZIF_DIS | SCU_MODE_FUNC5));
		/* MOSI: P1.4: J3 PIN-4 [Serial Expansion Interface] */
		Chip_SCU_PinMuxSet(0x1, 4, (SCU_MODE_INACT | SCU_MODE_INBUFF_EN | SCU_MODE_ZIF_DIS | SCU_MODE_FUNC5));
		/* SCLK: PF.4: J3 PIN-3 [Serial Expansion Interface] */
		Chip_SCU_PinMuxSet(0xF, 4, (SCU_PINIO_FAST | SCU_MODE_FUNC0));
	}

	return (success);
}

void me_device_finalize_board(void)
{
	me_device_finalize_arch();
}

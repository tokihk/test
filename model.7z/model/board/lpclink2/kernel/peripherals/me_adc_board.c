#include "board/skelton/kernel/peripherals/me_adc_board.c"

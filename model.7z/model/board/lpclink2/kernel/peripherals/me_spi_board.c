#include "board/skelton/kernel/peripherals/me_spi_board.c"

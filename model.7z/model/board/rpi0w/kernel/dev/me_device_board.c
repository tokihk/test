#include "me_device_board.h"


void me_device_initialize_board(void)
{
	me_device_initialize_arch();
}

void me_device_finalize_board(void)
{
	me_device_finalize_arch();
}

#ifndef ME_BASE_CONFIG_BOARD_H_
#define ME_BASE_CONFIG_BOARD_H_

#include "kernel/base/me_base_config_arch.h"

#endif

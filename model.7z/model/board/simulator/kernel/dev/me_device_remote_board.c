#include "kernel/dev/me_device_remote_board.h"

#include "kernel/net/me_net.h"
#include "kernel/net/me_net_udp_client.h"

#include <stdio.h>


static struct me_device_remote
{
	me_net_udp_client_t			comm;
} g_me_device_remote;


me_bool_t me_device_remote_initialize_board(void)
{
	if (me_net_udp_client_create(&g_me_device_remote.comm, 50000)) {
		me_uint8_t recv_data[100];
		me_net_endpoint_t ep;
		me_achar_t ep_str[100];

		while (1) {
			if (me_net_udp_client_recvfrom(&g_me_device_remote.comm, recv_data, sizeof(recv_data), &ep, 5000) > 0) {
				me_net_endpoint_to_text(&ep, ME_NET_DOMAIN_TYPE_IPV4, ep_str, sizeof(ep_str));

				printf("recv from: %s\n", ep_str);
			} else {
				printf("timeout\n");
			}
			fflush(stdout);
		}
	}

	return (ME_TRUE);
}

void me_device_remote_finalize_board(void)
{

}

void me_device_remote_gpio_dir_set_board(me_uint16_t gpio_id, me_bool_t dir)
{

}

void me_device_remote_gpio_value_set_board(me_uint16_t gpio_id, me_bool_t value)
{

}



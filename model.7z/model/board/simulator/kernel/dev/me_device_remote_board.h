#ifndef ME_DEVICE_REMOTE_BOARD_H_
#define ME_DEVICE_REMOTE_BOARD_H_

#include "kernel/me_kernel.h"


me_bool_t			me_device_remote_initialize_board(void);
void				me_device_remote_finalize_board(void);

void				me_device_remote_gpio_dir_set_board(me_uint16_t gpio_id, me_bool_t dir);

void				me_device_remote_gpio_value_set_board(me_uint16_t gpio_id, me_bool_t value);


#endif

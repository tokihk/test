#include "drivers/display/drv_lcd_ili9341.h"

#include "kernel/base/me_task.h"


#define DRV_LCD_ILI9341_CMD_SLEEP_OUT					(0x11u)
#define DRV_LCD_ILI9341_CMD_DISPLAY_ON					(0x29u)
#define DRV_LCD_ILI9341_CMD_COLUMN_ADDRESS_SET			(0x2Au)
#define DRV_LCD_ILI9341_CMD_PAGE_ADDRESS_SET			(0x2Bu)
#define DRV_LCD_ILI9341_CMD_MEMORY_WRITE				(0x2Cu)
#define DRV_LCD_ILI9341_CMD_MEMORY_ACCESS_CONTROL		(0x36u)
#define DRV_LCD_ILI9341_CMD_COLMOD						(0x3Au)


#define DRV_LCD_ILI9341_CFG_MAC							(0xE8u)
#define DRV_LCD_ILI9341_CFG_COLMOD						(0x55u)


#define DRV_LCD_ILI9341_WIDTH							(320)
#define DRV_LCD_ILI9341_HEIGHT							(240)


static void drv_lcd_ili9341_write_command(const drv_display_interface_t *iface, me_uint8_t cmd)
{
	(iface->port)(DRV_DISPLAY_PORT_DCX, ME_FALSE);
	(iface->send)(&cmd, 1);
}

static void drv_lcd_ili9341_write_data8(const drv_display_interface_t *iface, const me_uint8_t data)
{
	(iface->port)(DRV_DISPLAY_PORT_DCX, ME_TRUE);
	(iface->send)(&data, 1);
}

static void drv_lcd_ili9341_write_data(const drv_display_interface_t *iface, const me_uint8_t *data, me_size_t size)
{
	(iface->port)(DRV_DISPLAY_PORT_DCX, ME_TRUE);
	(iface->send)(data, size);
}

me_bool_t drv_lcd_ili9341_initialize(const drv_display_interface_t *iface)
{
	(iface->port)(DRV_DISPLAY_PORT_RESET, ME_FALSE);

	me_task_sleep_msec(20);

	(iface->port)(DRV_DISPLAY_PORT_RESET, ME_TRUE);

	me_task_sleep_msec(20);

	drv_lcd_ili9341_write_command(iface, DRV_LCD_ILI9341_CMD_MEMORY_ACCESS_CONTROL);
	drv_lcd_ili9341_write_data8(iface, DRV_LCD_ILI9341_CFG_MAC);

	drv_lcd_ili9341_write_command(iface, DRV_LCD_ILI9341_CMD_COLMOD);
	drv_lcd_ili9341_write_data8(iface, DRV_LCD_ILI9341_CFG_COLMOD);

	drv_lcd_ili9341_write_command(iface, DRV_LCD_ILI9341_CMD_SLEEP_OUT);
	me_task_sleep_msec(60);
	drv_lcd_ili9341_write_command(iface, DRV_LCD_ILI9341_CMD_DISPLAY_ON);

	return (ME_TRUE);
}

void drv_lcd_ili9341_finalize(const drv_display_interface_t *iface)
{
}

me_bool_t drv_lcd_ili9341_transfer_rect16(const drv_display_interface_t *iface, me_uint16_t x_s, me_uint16_t x_e, me_uint16_t y_s, me_uint16_t y_e, const me_uint8_t *data, me_size_t size)
{
	me_uint16_t x_temp;
	me_uint16_t y_temp;
	me_uint16_t mem_size;

	if (x_s > DRV_LCD_ILI9341_WIDTH) {
		x_s = DRV_LCD_ILI9341_WIDTH;
	}
	if (x_e > DRV_LCD_ILI9341_WIDTH) {
		x_e = DRV_LCD_ILI9341_WIDTH;
	}
	if (x_e < x_s) {
		x_e = x_s;
	}
	if (y_s > DRV_LCD_ILI9341_HEIGHT) {
		y_s = DRV_LCD_ILI9341_HEIGHT;
	}
	if (y_e > DRV_LCD_ILI9341_HEIGHT) {
		y_e = DRV_LCD_ILI9341_HEIGHT;
	}
	if (y_e < y_s) {
		y_e = y_s;
	}

	drv_lcd_ili9341_write_command(iface, DRV_LCD_ILI9341_CMD_COLUMN_ADDRESS_SET);
	drv_lcd_ili9341_write_data(iface, &x_s, 2);
	drv_lcd_ili9341_write_data(iface, &x_e, 2);

	drv_lcd_ili9341_write_command(iface, DRV_LCD_ILI9341_CMD_PAGE_ADDRESS_SET);
	drv_lcd_ili9341_write_data(iface, &y_s, 2);
	drv_lcd_ili9341_write_data(iface, &y_e, 2);

	drv_lcd_ili9341_write_command(iface, DRV_LCD_ILI9341_CMD_MEMORY_WRITE);

	mem_size = ((x_e - x_s) * (y_e - y_x)) * 2;

	if (size > mem_size) {
		size = mem_size;
	}

	return (ME_TRUE);
}

#include "me_dev_gpio_board.h"


void me_dev_gpio_initialize_board(void)
{
	me_dev_gpio_initialize_arch();
}

void me_dev_gpio_finalize_board(void)
{
	me_dev_gpio_finalize_arch();
}

me_bool_t me_dev_gpio_direction_get_board(me_uint16_t gpio_id)
{
	return (me_dev_gpio_direction_get_arch(gpio_id));
}

void me_dev_gpio_direction_set_board(me_uint16_t gpio_id, me_bool_t dir)
{
	me_dev_gpio_direction_set_arch(gpio_id, dir);
}

me_bool_t me_dev_gpio_value_get_board(me_uint16_t gpio_id)
{
	return (me_dev_gpio_value_get_arch(gpio_id));
}

void me_dev_gpio_value_set_board(me_uint16_t gpio_id, me_bool_t value)
{
	me_dev_gpio_value_set_arch(gpio_id, value);
}


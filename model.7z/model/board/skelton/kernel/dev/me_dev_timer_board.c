#include "kernel/dev/me_dev_timer_board.h"


void me_dev_timer_initialize_board(void)
{
	me_dev_timer_initialize_arch();
}

void me_dev_timer_finalize_board(void)
{
	me_dev_timer_finalize_arch();
}

me_bool_t me_dev_timer_create_board(me_uint16_t tmr_id, me_uint32_t ival_hz)
{
	return (me_dev_timer_create_arch(tmr_id, ival_hz));
}

void me_dev_timer_destroy_board(me_uint16_t tmr_id)
{
	me_dev_timer_destroy_arch(tmr_id);
}

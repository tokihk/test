#ifndef ME_DEV_TYPEDEF_BOARD_H_
#define ME_DEV_TYPEDEF_BOARD_H_

#include "kernel/dev/me_dev_typedef_arch.h"

#endif

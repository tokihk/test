#ifndef ME_DEVICE_CONFIG_BOARD_H_
#define ME_DEVICE_CONFIG_BOARD_H_

#include "me_device_config_arch.h"


#endif

#include "kernel/me_kernel.h"


me_bool_t drv_display_initialize_board(me_uint16_t display_id)
{
	return (ME_FALSE);
}

void drv_display_finalize_board(me_uint16_t display_id)
{

}

me_bool_t drv_display_transfer_rect_board(me_uint16_t display_id, const me_uint8_t *data, me_size_t size)
{
	return (ME_FALSE);
}


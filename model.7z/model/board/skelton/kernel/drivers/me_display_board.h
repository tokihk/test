#ifndef ME_DISPLAY_BOARD_H_
#define ME_DISPLAY_BOARD_H_

#include "kernel/me_kernel.h"


me_bool_t			me_display_initialize_board(me_uint16_t display_id);
void				me_display_finalize_board(me_uint16_t display_id);

me_bool_t			me_display_transfer_rect_board(me_uint16_t display_id, const me_uint8_t *data, me_size_t size);


#endif

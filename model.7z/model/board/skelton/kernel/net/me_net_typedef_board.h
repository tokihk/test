#ifndef ME_NET_TYPEDEF_BOARD_H_
#define ME_NET_TYPEDEF_BOARD_H_

#include "kernel/me_kernel.h"

#include "kernel/net/me_net_typedef_arch.h"


typedef struct me_net_endpoint_board
{
	me_net_endpoint_arch_t		base;
} me_net_endpoint_board_t;

typedef struct me_net_tcp_server_board
{
	me_net_tcp_server_arch_t	base;
} me_net_tcp_server_board_t;

typedef struct me_net_tcp_client_board
{
	me_net_tcp_client_arch_t	base;
} me_net_tcp_client_board_t;

typedef struct me_net_udp_client_board
{
	me_net_udp_client_arch_t	base;
} me_net_udp_client_board_t;


#endif

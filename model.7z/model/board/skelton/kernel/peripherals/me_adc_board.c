#include "me_adc_board.h"


me_bool_t me_adc_initialize_board(void)
{
	return (me_adc_initialize_arch());
}

void me_adc_finalize_board(void)
{
	me_adc_finalize_arch();
}

me_bool_t me_adc_value_get_board(me_uint16_t adc_id)
{
	return (me_adc_value_get_arch(adc_id));
}

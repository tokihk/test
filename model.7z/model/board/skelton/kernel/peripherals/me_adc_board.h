#ifndef ME_ADC_BOARD_H_
#define ME_ADC_BOARD_H_

#include "kernel/peripherals/me_adc_stddef.h"


me_bool_t					me_adc_initialize_board(void);
void						me_adc_finalize_board(void);

me_bool_t					me_adc_value_get_board(me_uint16_t adc_id);


#endif

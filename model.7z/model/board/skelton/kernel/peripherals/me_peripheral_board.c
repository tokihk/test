#include "me_peripheral_board.h"


me_bool_t me_peripheral_initialize_board(void)
{
	return (me_peripheral_initialize_arch());
}

void me_peripheral_finalize_board(void)
{
	me_peripheral_finalize_arch();
}

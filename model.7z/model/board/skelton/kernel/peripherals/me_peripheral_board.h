#ifndef ME_PERIPHERAL_BOARD_H_
#define ME_PERIPHERAL_BOARD_H_

#include "kernel/peripherals/me_peripheral_arch.h"


me_bool_t			me_peripheral_initialize_board(void);
void				me_peripheral_finalize_board(void);


#endif

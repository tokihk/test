#ifndef ME_PERIPHERAL_CONFIG_BOARD_H_
#define ME_PERIPHERAL_CONFIG_BOARD_H_

#include "kernel/peripherals/me_peripheral_config_arch.h"


#endif

#include "me_rtc_board.h"

#include "kernel/peripherals/me_rtc_arch.h"


me_bool_t me_rtc_initialize_board(void)
{
	return (me_rtc_initialize_arch());
}

void me_rtc_finalize_board(void)
{
	me_rtc_finalize_arch();
}

me_bool_t me_rtc_datetime_get_board(struct me_datetime_t *dt)
{
	return (me_rtc_datetime_get_arch(dt));
}

me_bool_t me_rtc_datetime_set_board(const struct me_datetime_t *dt)
{
	return (me_rtc_datetime_set_arch(dt));
}

#ifndef ME_RTC_BOARD_H_
#define ME_RTC_BOARD_H_

#include "kernel/core/me_stddef.h"

#include "kernel/core/me_datetime.h"


me_bool_t					me_rtc_initialize_board(void);
void						me_rtc_finalize_board(void);

me_bool_t					me_rtc_datetime_get_board(struct me_datetime_t *dt);

me_bool_t					me_rtc_datetime_set_board(const struct me_datetime_t *dt);


#endif

#include "kernel/peripherals/me_timer_board.h"


me_bool_t me_timer_initialize_board(void)
{
	return (me_timer_initialize_arch());
}

void me_timer_finalize_board(void)
{
	me_timer_finalize_arch();
}

me_bool_t me_timer_create_board(me_uint16_t tmr_id, me_uint32_t ival_10nsec, me_timer_callback_t callback)
{
	return (me_timer_create_arch(tmr_id, ival_10nsec, callback));
}

void me_timer_destroy_board(me_uint16_t tmr_id)
{
	me_timer_destroy_arch(tmr_id);
}

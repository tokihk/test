#ifndef ME_TIMER_BOARD_H_
#define ME_TIMER_BOARD_H_

#include "kernel/peripherals/me_timer_arch.h"


me_bool_t				me_timer_initialize_board(void);
void					me_timer_finalize_board(void);

me_bool_t				me_timer_create_board(me_uint16_t tmr_id, me_uint32_t ival_10nsec, me_timer_callback_t callback);
void					me_timer_destroy_board(me_uint16_t tmr_id);


#endif

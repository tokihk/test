#ifndef ME_PROTOCOL_CONFIG_BOARD_H_
#define ME_PROTOCOL_CONFIG_BOARD_H_

#include "kernel/protocols/me_protocol_config_arch.h"

#endif

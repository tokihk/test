#include "system_main.h"

#include "apps/unit_test/unit_test.h"

#include "kernel/base/me_main_system.h"


static struct me_system_main_
{
	me_module_manager_t		mod_mgr;
	me_bool_t				exit_req;
} me_system_main_g;


static const me_module_profile_t mod_unit_test =
{
	.callback_init    = unit_test_init,
	.callback_exit    = unit_test_exit,
	.callback_poll    = unit_test_poll,
	.polling_interval = 0,
};


static void system_poll(void)
{
	while (!me_system_main_g.exit_req) {
		me_module_manager_poll(&me_system_main_g.mod_mgr);
	}
}

void me_system_on_signal(enum me_signal_type signal)
{
	me_system_main_g.exit_req = ME_TRUE;
}

me_int8_t me_system_main(me_int32_t argc, const me_achar_t *argv[])
{
	me_int8_t exit_code = 0;

	UNREFERENCED_PARAMETER(argc);
	UNREFERENCED_PARAMETER(argv);

	me_module_manager_initialize(&me_system_main_g.mod_mgr);

	/* --- ベースアプリケーション登録 --- */
	me_module_register(&me_system_main_g.mod_mgr, &mod_unit_test);

	system_poll();

	me_module_manager_finalize(&me_system_main_g.mod_mgr);

	return (exit_code);
}



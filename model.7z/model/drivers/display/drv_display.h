#ifndef DRV_DISPLAY_H_
#define DRV_DISPLAY_H_

#include "drivers/display/drv_display_board.h"


me_bool_t			drv_display_initialize(me_uint16_t display_id);
void				drv_display_finalize(me_uint16_t display_id);

me_bool_t			drv_display_transfer_rect(me_uint16_t display_id, const me_uint8_t *data, me_size_t size);


#endif

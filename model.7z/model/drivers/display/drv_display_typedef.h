#ifndef DRV_DISPLAY_TYPEDEF_H_
#define DRV_DISPLAY_TYPEDEF_H_

#include "kernel/me_kernel.h"


enum drv_display_port
{
	DRV_DISPLAY_PORT_RESET,
	DRV_DISPLAY_PORT_DCX,
};


typedef struct drv_display_interface
{
	void			(* port)(enum drv_display_port port, me_bool_t value);
	me_size_t		(* send)(const me_uint8_t *data, me_size_t size);
	me_size_t		(* recv)(me_uint8_t *buffer, me_size_t buffer_size);
} drv_display_interface_t;


#endif


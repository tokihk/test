#include "drivers/display/drv_lcd_ili9341.h"


me_bool_t drv_lcd_ili9341_initialize(const drv_display_interface_t *iface)
{
	return (ME_FALSE);
}

void drv_lcd_ili9341_finalize(const drv_display_interface_t *iface)
{
}

me_bool_t drv_lcd_ili9341_transfer_rect(const drv_display_interface_t *iface, const me_uint8_t *data, me_size_t size)
{
	return (ME_FALSE);
}

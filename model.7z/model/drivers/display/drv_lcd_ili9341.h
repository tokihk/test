#ifndef DRV_LCD_ILI9341_H_
#define DRV_LCD_ILI9341_H_

#include "drivers/display/drv_display_typedef.h"


me_bool_t			drv_lcd_ili9341_initialize(const drv_display_interface_t *iface);
void				drv_lcd_ili9341_finalize(const drv_display_interface_t *iface);

me_bool_t			drv_lcd_ili9341_transfer_rect(const drv_display_interface_t *iface, const me_uint8_t *data, me_size_t size);


#endif

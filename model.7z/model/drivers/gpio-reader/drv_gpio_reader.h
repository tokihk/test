#ifndef DRV_GPIO_READER_H_
#define DRV_GPIO_READER_H_

#include "kernel/me_kernel.h"


void			drv_gpio_reader_initialize(me_uint32_t clock_hz, me_size_t data_count_max);
void			drv_gpio_reader_finalize(void);

me_size_t		drv_gpio_reader_data_get(uint8_t *buffer, me_size_t buffer_size);


#endif

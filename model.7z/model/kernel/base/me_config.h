#ifndef ME_CONFIG_H_
#define ME_CONFIG_H_

#include "kernel/base/me_config_arch.h"

#ifndef ME_ROOTDIR
#define ME_ROOTDIR								"/tmp"
#endif

#ifndef ME_CHAR_IS_WCHAR
#define ME_CHAR_IS_WCHAR						(0)
#endif

#ifndef ME_SYSTEM_HEAP_SIZE
#define ME_SYSTEM_HEAP_SIZE						(0x000FFFFFu)
#endif

#ifndef ME_HEAP_STRING_LENGTH_INIT
#define ME_HEAP_STRING_LENGTH_INIT				(64)
#endif

#ifndef ME_HEAP_STRING_LENGTH_MAX
#define ME_HEAP_STRING_LENGTH_MAX				(1024)
#endif

#ifndef ME_HEAP_STRING_LENGTH_STRETCH_STEP
#define ME_HEAP_STRING_LENGTH_STRETCH_STEP		(32)
#endif

#ifndef ME_PATH_LENGTH_MAX
#define ME_PATH_LENGTH_MAX						(250)
#endif

#ifndef ME_STDOUT_FORMAT_LENGTH_MAX
#define ME_STDOUT_FORMAT_LENGTH_MAX				(250)
#endif

#ifndef ME_STDERR_FORMAT_LENGTH_MAX
#define ME_STDERR_FORMAT_LENGTH_MAX				(250)
#endif

#ifndef ME_SYSLOG_HOST_NAME
#define ME_SYSLOG_HOST_NAME						"Host"
#endif

#ifndef ME_SYSLOG_APP_NAME
#define ME_SYSLOG_APP_NAME						"App"
#endif

#ifndef ME_SYSLOG_MSGID
#define ME_SYSLOG_MSGID							"Msg"
#endif

#ifndef ME_SYSLOG_OUTPUT_QUEUE_MAX
#define ME_SYSLOG_OUTPUT_QUEUE_MAX				(10)
#endif

#ifndef ME_SYSLOG_MESSAGE_LENGTH_MAX
#define ME_SYSLOG_MESSAGE_LENGTH_MAX			(100)
#endif

#ifndef ME_SYSLOG_TARGET_STDOUT_ENABLE
#define ME_SYSLOG_TARGET_STDOUT_ENABLE			(0)
#endif

#ifndef ME_SYSLOG_TARGET_STDERR_ENABLE
#define ME_SYSLOG_TARGET_STDERR_ENABLE			(0)
#endif

#ifndef ME_SYSLOG_TARGET_FILE_ENABLE
#define ME_SYSLOG_TARGET_FILE_ENABLE			(0)
#endif

#ifndef ME_SYSLOG_TARGET_UDP_ENABLE
#define ME_SYSLOG_TARGET_UDP_ENABLE				(0)
#endif

#ifndef ME_SYSLOG_TARGET_TCP_ENABLE
#define ME_SYSLOG_TARGET_TCP_ENABLE				(0)
#endif

#endif

#ifndef ME_CONFIG_H_
#define ME_CONFIG_H_

#include "kernel/base/me_config_arch.h"

#ifndef ME_SYSLOG_HOST_NAME
#define ME_SYSLOG_HOST_NAME						"Hresvelgr"
#endif

#ifndef ME_SYSLOG_APP_NAME
#define ME_SYSLOG_APP_NAME						"model"
#endif

#ifndef ME_SYSLOG_MSGID
#define ME_SYSLOG_MSGID							"Hresvelgr"
#endif

#ifndef ME_SYSLOG_OUTPUT_QUEUE_MAX
#define ME_SYSLOG_OUTPUT_QUEUE_MAX				(50)
#endif

#ifndef ME_SYSLOG_MESSAGE_LENGTH_MAX
#define ME_SYSLOG_MESSAGE_LENGTH_MAX			(250)
#endif

#ifndef ME_SYSLOG_TARGET_STDOUT_ENABLE
#define ME_SYSLOG_TARGET_STDOUT_ENABLE			(0)
#endif

#ifndef ME_SYSLOG_TARGET_STDERR_ENABLE
#define ME_SYSLOG_TARGET_STDERR_ENABLE			(0)
#endif

#ifndef ME_SYSLOG_TARGET_FILE_ENABLE
#define ME_SYSLOG_TARGET_FILE_ENABLE			(0)
#endif

#ifndef ME_SYSLOG_TARGET_UDP_ENABLE
#define ME_SYSLOG_TARGET_UDP_ENABLE				(0)
#endif

#ifndef ME_SYSLOG_TARGET_TCP_ENABLE
#define ME_SYSLOG_TARGET_TCP_ENABLE				(0)
#endif

#endif

#include "me_datetime.h"


me_bool_t me_datetime_now(me_datetime_t *dt)
{

}

me_bool_t me_datetime_utc_now(me_datetime_t *dt)
{

}

me_bool_t me_epoch_time_now(me_epoch_time_t *epoch)
{

}

me_bool_t me_epoch_time_utc_now(me_epoch_time_t *epoch)
{

}

me_bool_t me_epoch_to_datetime(const me_epoch_time_t *epoch, me_datetime_t *dt)
{

}

me_bool_t me_datetime_to_epoch(const me_datetime_t *dt, me_epoch_time_t *epoch)
{

}

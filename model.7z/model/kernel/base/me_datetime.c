#include "me_datetime.h"

#include "kernel/base/me_datetime_arch.h"


me_bool_t me_datetime_now(me_datetime_t *dt)
{
	me_bool_t success = ME_FALSE;

	if (dt != NULL) {
		success = me_datetime_now_arch(dt);
	}

	return (success);
}

me_bool_t me_datetime_now_utc(me_datetime_t *dt)
{
	me_bool_t success = ME_FALSE;

	if (dt != NULL) {
		success = me_datetime_now_utc_arch(dt);
	}

	return (success);
}

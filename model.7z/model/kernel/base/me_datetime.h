#ifndef ME_DATETIME_H_
#define ME_DATETIME_H_

#include "kernel/me_kernel.h"


me_bool_t			me_datetime_now(me_datetime_t *dt);
me_bool_t			me_datetime_now_utc(me_datetime_t *dt);


#endif


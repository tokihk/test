#ifndef ME_DATETIME_H_
#define ME_DATETIME_H_

#include "kernel/me_kernel.h"

#include <time.h>


typedef struct me_datetime
{
	me_uint16_t			year;
	me_uint8_t			month;
	me_uint8_t			day;
	me_uint8_t			hour;
	me_uint8_t			min;
	me_uint8_t			sec;
	me_uint16_t			msec;
	me_bool_t			local;
} me_datetime_t;


me_bool_t			me_datetime_now(me_datetime_t *dt);
me_bool_t			me_datetime_utc_now(me_datetime_t *dt);

me_bool_t			me_epoch_time_now(me_epoch_time_t *epoch);
me_bool_t			me_epoch_time_utc_now(me_epoch_time_t *epoch);

me_bool_t			me_epoch_to_datetime(const me_epoch_time_t *epoch, me_datetime_t *dt);
me_bool_t			me_datetime_to_epoch(const me_datetime_t *dt, me_epoch_time_t *epoch);


#endif


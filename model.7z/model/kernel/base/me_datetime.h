#ifndef ME_DATETIME_H_
#define ME_DATETIME_H_

#include "kernel/me_kernel.h"

#include "kernel/base/me_datetime_arch.h"


me_bool_t			me_datetime_now(me_datetime_t *dt);
me_bool_t			me_datetime_now_utc(me_datetime_t *dt);

me_uint32_t			me_datetime_elapsed_msec(const me_datetime_t *dt_start, const me_datetime_t *dt_end);


#endif


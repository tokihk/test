/* ###################################################################### *//**
 *
 *	@addtogroup	Kernel
 *	@{
 *	@file		me_datetime_arch.h
 *	@brief		Datetime Module
 *	@author		Copyright (C) 2019 Hitoshi Kouno
 *
*//* ####################################################################### */
#ifndef ME_DATETIME_ARCH_H_
#define ME_DATETIME_ARCH_H_

#include "kernel/me_kernel.h"


typedef struct me_datetime
{
	me_uint16_t						year;
	me_uint16_t						msec;
	me_uint8_t						month;
	me_uint8_t						day;
	me_uint8_t						hour;
	me_uint8_t						min;
	me_uint8_t						sec;
	me_bool_t						local;
} me_datetime_t;


me_bool_t			me_datetime_now_arch(me_datetime_t *dt);
me_bool_t			me_datetime_now_utc_arch(me_datetime_t *dt);


#endif /* ME_DATETIME_ARCH_H_ */
/* ####### File End ###### */
/** @} */

#include "me_event_queue.h"


me_bool_t me_event_queue_create(me_event_queue_t *obj, me_size_t event_num_max)
{
	me_bool_t success = ME_FALSE;

	if (obj != NULL) {
		success = me_event_queue_create_arch(&obj->base, event_num_max);
	}

	return (success);
}

void me_event_queue_destroy(me_event_queue_t *obj)
{
	if (obj != NULL) {
		me_event_queue_destroy_arch(&obj->base);
	}
}

me_bool_t me_event_queue_send(me_event_queue_t *obj, me_uint16_t event_id)
{
	me_bool_t success = ME_FALSE;

	if (obj != NULL) {
		success = me_event_queue_send_arch(&obj->base, event_id);
	}

	return (success);
}

me_bool_t me_event_queue_send_isr(me_event_queue_t *obj, me_uint16_t event_id)
{
	me_bool_t success = ME_FALSE;

	if (obj != NULL) {
		success = me_event_queue_send_isr_arch(&obj->base, event_id);
	}

	return (success);
}

me_bool_t me_event_queue_recv(me_event_queue_t *obj, me_uint16_t *event_id, me_uint32_t timeout_msec)
{
	me_bool_t success = ME_FALSE;

	if ((obj != NULL) && (event_id != NULL)) {
		success = me_event_queue_recv_arch(&obj->base, event_id, timeout_msec);
	}

	return (success);
}

me_bool_t me_event_queue_recv_isr(me_event_queue_t *obj, me_uint16_t *event_id)
{
	me_bool_t success = ME_FALSE;

	if ((obj != NULL) && (event_id != NULL)) {
		success = me_event_queue_recv_isr_arch(&obj->base, event_id);
	}

	return (success);
}

/* ####### File End ###### */
/** @} */

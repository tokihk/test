/* ###################################################################### *//**
 *
 *	@addtogroup	Kernel
 *	@{
 *	@file		me_task.h
 *	@brief		Task Module
 *	@author		Copyright (C) 2019 Hitoshi Kouno
 *
*//* ####################################################################### */
#ifndef ME_EVENT_QUEUE_H_
#define ME_EVENT_QUEUE_H_

#include "kernel/me_kernel.h"

#include "kernel/base/me_event_queue_arch.h"


me_bool_t				me_event_queue_create(me_event_queue_t *obj, me_size_t event_num_max);
void					me_event_queue_destroy(me_event_queue_t *obj);

me_bool_t				me_event_queue_send(me_event_queue_t *obj, me_uint16_t event_id);
me_bool_t				me_event_queue_send_isr(me_event_queue_t *obj, me_uint16_t event_id);

me_bool_t				me_event_queue_recv(me_event_queue_t *obj, me_uint16_t *event_id, me_uint32_t timeout_msec);
me_bool_t				me_event_queue_recv_isr(me_event_queue_t *obj, me_uint16_t *event_id);


#endif /* ME_EVENT_QUEUE_H_ */
/* ####### File End ###### */
/** @} */

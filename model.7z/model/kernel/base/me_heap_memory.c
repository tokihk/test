/* ###################################################################### *//**
 *
 *	@addtogroup	Kernel
 *	@{
 *	@file		me_heap_memory.h
 *	@brief		Heap Memory Module
 *	@author		Copyright (C) 2019 Hitoshi Kouno
 *
*//* ####################################################################### */

#include "me_heap_memory.h"

#include <string.h>


struct me_heap_use_cell_header
{
	me_size_t						cell_size;
	void *							cell_addr_top;
	const me_achar_t *				source_file_name;
	me_uint32_t						source_line_no;
};

struct me_heap_use_cell_footer
{
	void *							cell_addr_top;
};


me_heap_manager_t *me_heap_initialize(void *ram_addr, me_size_t ram_size)
{
	me_heap_manager_t *mgr = NULL;

	if (   (ram_addr != NULL)
		&& (ram_size > sizeof(me_heap_manager_t))
	) {
		mgr = (me_heap_manager_t *)ram_addr;

		memset(mgr, 0, sizeof(*mgr));
		mgr->ram_addr = ram_addr;
		mgr->ram_size = ram_size;

		mgr->free_cell_top.cell_next = (struct me_heap_free_cell *)(mgr->ram_addr + sizeof(*mgr));
		mgr->free_cell_top.cell_next->cell_size = mgr->ram_size - sizeof(*mgr);
		mgr->free_cell_top.cell_next->cell_next = NULL;

		mgr->alloc_cell_top.cell_prev = &mgr->alloc_cell_top;
		mgr->alloc_cell_top.cell_next = &mgr->alloc_cell_top;

		me_mutex_initialize(&mgr->mtx);
	}

	return (mgr);
}

void me_heap_finalize(me_heap_manager_t *mgr)
{
	if (mgr != NULL) {
		me_mutex_finalize(&mgr->mtx);
	}
}

void me_heap_using_list(me_heap_manager_t *mgr, ME_HEAP_USING_CALLBACK callback)
{
	if ((mgr != NULL) && (callback != NULL)) {
		const struct me_heap_alloc_cell *cell_curr = mgr->alloc_cell_top.cell_next;
		me_uint32_t index = 0;

		while (cell_curr != &mgr->alloc_cell_top) {
			(callback)(mgr, index, &cell_curr->info);
			cell_curr = cell_curr->cell_next;
			index++;
		}
	}
}

void *me_heap_malloc_base(me_heap_manager_t *mgr, me_size_t size, const me_achar_t *file_name, int line_no)
{
	void *ptr = NULL;

	if (   (mgr != NULL)
		&& (size > 0)
	) {
		me_size_t cell_size = size;

		/* Cell Size */
		if ((cell_size & 0x03) != 0) {
			cell_size += 4 - (cell_size & 0x03);
		}
		cell_size += sizeof(struct me_heap_alloc_cell);

		me_mutex_lock(&mgr->mtx);
		{
			struct me_heap_free_cell *cell_free_prev = &mgr->free_cell_top;
			struct me_heap_free_cell *cell_free_curr = cell_free_prev->cell_next;

			/* Scan Free Cell */
			while ((cell_free_curr != NULL) && (cell_free_curr->cell_size < cell_size)) {
				cell_free_prev = cell_free_curr;
				cell_free_curr = cell_free_curr->cell_next;
			}

			/* Found Free Cell */
			if (cell_free_curr != NULL) {
				struct me_heap_alloc_cell *cell_alloc = (struct me_heap_alloc_cell *)cell_free_curr;

				/* データ領域を取得 */
				ptr = (me_uint8_t *)cell_free_curr + sizeof(struct me_heap_alloc_cell);

				if ((cell_free_curr->cell_size - cell_size) >= sizeof(struct me_heap_free_cell)) {
					/* --- フリーセルに十分な空きがある場合は残りをフリーセルとして登録 --- */
					struct me_heap_free_cell *cell_free_rest = (struct me_heap_free_cell *)((me_uint8_t *)cell_free_curr + cell_size);

					cell_free_rest->cell_next = cell_free_curr->cell_next;
					cell_free_rest->cell_size = cell_free_curr->cell_size - cell_size;
					cell_free_prev->cell_next = cell_free_rest;

				} else {
					/* --- フリーセルに十分な空きがない場合は全て割り当てる --- */
					cell_size = cell_free_curr->cell_size;
					cell_free_prev->cell_next = cell_free_curr->cell_next;
				}

				/* 確保セルの情報を更新 */
				cell_alloc->cell_size = cell_size;
				cell_alloc->guard_code = cell_alloc;

				cell_alloc->info.data_size = size;
				cell_alloc->info.data_addr = ptr;
				cell_alloc->info.source_file_name = file_name;
				cell_alloc->info.source_line_no = line_no;

				cell_alloc->cell_prev = mgr->alloc_cell_top.cell_prev;
				cell_alloc->cell_next = &mgr->alloc_cell_top;

				mgr->alloc_cell_top.cell_prev->cell_next = cell_alloc;
				mgr->alloc_cell_top.cell_prev = cell_alloc;
			}
		}
		me_mutex_unlock(&mgr->mtx);
	}

	return (ptr);
}

void *me_heap_calloc_base(me_heap_manager_t *mgr, me_size_t size, const me_achar_t *file_name, int line_no)
{
	void *ptr = me_heap_malloc_base(mgr, size, file_name, line_no);

	if (ptr != NULL) {
		memset(ptr, 0, size);
	}

	return (ptr);
}

void me_heap_free(me_heap_manager_t *mgr, void *ptr)
{
	if (ptr != NULL) {
		struct me_heap_free_cell *cell_free = ptr - sizeof(struct me_heap_alloc_cell);
		struct me_heap_alloc_cell *cell_free_alloc = (struct me_heap_alloc_cell *)cell_free;

		if (cell_free_alloc->guard_code == cell_free_alloc) {
			me_mutex_lock(&mgr->mtx);
			{
				struct me_heap_free_cell *cell_free_left  = &mgr->free_cell_top;
				struct me_heap_free_cell *cell_free_right = cell_free_left->cell_next;

				/* 確保済みリストから削除 */
				cell_free_alloc->cell_prev->cell_next = cell_free_alloc->cell_next;
				cell_free_alloc->cell_next->cell_prev = cell_free_alloc->cell_prev;
				cell_free_alloc->guard_code = NULL;

				/* 割り当てセルからフリーセルに変換 */
				cell_free->cell_size = cell_free_alloc->cell_size;

				/* 解放セルの両端のフリーセルを取得する */
				while ((cell_free_right != NULL) && (cell_free_right < cell_free)) {
					cell_free_left = cell_free_right;
					cell_free_right = cell_free_right->cell_next;
				}

				/* === 直前のフリーセルを整理 === */
				if (cell_free_right == NULL) {
					/* --- 後ろにフリーセルが存在しないとき --- */
					cell_free->cell_next = NULL;

				} else if ((struct me_heap_free_cell *)((me_uint8_t *)cell_free + cell_free->cell_size) == cell_free_right) {
					/* --- 解放セルと直後のフリーセルが隣接しているとき --- */
					/* 直後のフリーセルと結合 */
					cell_free->cell_size += cell_free_right->cell_size;
					cell_free->cell_next = cell_free_right->cell_next;

				} else {
					/* --- 解放セルがフリーセルと隣接していないとき --- */
					/* 自身を独立させて直後のフリーセルにリンクする */
					cell_free->cell_next = cell_free_right;
				}

				/* === 直前のフリーセルを整理 === */
				if ((struct me_heap_free_cell *)((me_uint8_t *)cell_free_left + cell_free_left->cell_size) == cell_free) {
					/* --- 解放セルと直前のフリーセルが隣接しているとき --- */
					/* 先頭のフリーセルを結合する */
					cell_free_left->cell_size += cell_free->cell_size;
					cell_free_left->cell_next = cell_free->cell_next;
				} else {
					/* --- 解放セルと直前のフリーセルが隣接していないとき --- */
					/* 直前のフリーセルと解放したフリーセルをリンクする */
					cell_free_left->cell_next = cell_free;
				}
			}
			me_mutex_unlock(&mgr->mtx);
		}
	}
}


/* ####### File End ###### */
/** @} */

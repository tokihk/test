/* ###################################################################### *//**
 *
 *	@addtogroup	Kernel
 *	@{
 *	@file		me_heap_memory.h
 *	@brief		Heap Memory Module
 *	@author		Copyright (C) 2019 Hitoshi Kouno
 *
*//* ####################################################################### */
#ifndef ME_HEAP_MEMORY_H_
#define ME_HEAP_MEMORY_H_

#include "kernel/me_kernel.h"

#include "kernel/base/me_mutex.h"


#define me_heap_malloc(mgr,size)	me_heap_malloc_base(mgr,size,__FILE__,__LINE__)
#define me_heap_calloc(mgr,size)	me_heap_calloc_base(mgr,size,__FILE__,__LINE__)


struct me_heap_alloc_cell_info
{
	const void *						data_addr;
	me_size_t							data_size;
	const me_achar_t *					source_file_name;
	me_uint32_t							source_line_no;
};

struct me_heap_alloc_cell
{
	me_size_t							cell_size;
	struct me_heap_alloc_cell *			cell_prev;
	struct me_heap_alloc_cell *			cell_next;
	struct me_heap_alloc_cell_info		info;
	void *								guard_code;
};

struct me_heap_free_cell
{
	me_size_t							cell_size;
	struct me_heap_free_cell *			cell_next;
};

typedef struct me_heap_manager
{
	me_uint8_t *						ram_addr;
	me_size_t							ram_size;
	struct me_heap_free_cell			free_cell_top;
	struct me_heap_alloc_cell			alloc_cell_top;
	me_mutex_t							mtx;
} me_heap_manager_t;


typedef void (* ME_HEAP_USING_CALLBACK)(me_heap_manager_t *mgr, me_uint32_t index, const struct me_heap_alloc_cell_info *info);


me_heap_manager_t *				me_heap_initialize(void *ram_addr, me_size_t ram_size);
void							me_heap_finalize(me_heap_manager_t *mgr);

void							me_heap_using_list(me_heap_manager_t *mgr, ME_HEAP_USING_CALLBACK callback);

void *							me_heap_malloc_base(me_heap_manager_t *mgr, me_size_t size, const me_achar_t *file_name, int line_no);
void *							me_heap_calloc_base(me_heap_manager_t *mgr, me_size_t size, const me_achar_t *file_name, int line_no);

void							me_heap_free(me_heap_manager_t *mgr, void *ptr);


#endif /* ME_THREAD_H_ */
/* ####### File End ###### */
/** @} */

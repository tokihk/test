#ifndef ME_KERNEL_MAIN_H_
#define ME_KERNEL_MAIN_H_

#include "kernel/me_kernel.h"

#include "kernel/base/me_system_main.h"


me_int8_t			me_kernel_main(me_int32_t argc, const me_achar_t *argv[]);

void				me_kernel_on_signal(enum me_signal_type signal);

void				me_kernel_tick_set(me_uint32_t tick);
void				me_kernel_tick_inc(void);


#endif

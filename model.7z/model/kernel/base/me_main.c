#include "kernel/base/me_kernel_main.h"
#include "kernel/base/me_system_main.h"

#include "kernel/base/me_heap_memory.h"


static struct me_main
{
	me_uint8_t				heap_buffer[ME_SPEC_SYSTEM_HEAP_SIZE];
	me_heap_manager_t *		heap_manager;

	me_uint32_t				tick;
} me_main_g;


me_uint32_t me_system_tick_get(void)
{
	return (me_main_g.tick);
}

void *me_system_malloc_base(me_size_t size, const me_achar_t *file_name, me_int32_t line_no)
{
	void *ptr = NULL;

	if (me_main_g.heap_manager != NULL) {
		ptr = me_heap_malloc_base(me_main_g.heap_manager, size, file_name, line_no);
	}

	return (ptr);
}

void *me_system_calloc_base(me_size_t size, const me_achar_t *file_name, me_int32_t line_no)
{
	void *ptr = NULL;

	if (me_main_g.heap_manager != NULL) {
		ptr = me_heap_calloc_base(me_main_g.heap_manager, size, file_name, line_no);
	}

	return (ptr);
}

void me_system_free_base(void *ptr)
{
	if (me_main_g.heap_manager != NULL) {
		me_heap_free(me_main_g.heap_manager, ptr);
	}
}

me_int8_t me_kernel_main(me_int32_t argc, const me_achar_t *argv[])
{
	me_int8_t	exit_code = 0;

	me_main_g.heap_manager = me_heap_initialize(me_main_g.heap_buffer, sizeof(me_main_g.heap_buffer));

	me_main_g.tick = 0;

	exit_code = me_system_main(argc, argv);

	return (exit_code);
}

void me_kernel_on_signal(enum me_signal_type signal)
{
	me_system_on_signal(signal);
}

void me_kernel_tick_set(me_uint32_t tick)
{
	me_main_g.tick = tick;
}

void me_kernel_tick_inc(void)
{
	me_main_g.tick++;
}



#include "kernel/base/me_main_kernel.h"
#include "kernel/base/me_main_system.h"
#include "kernel/base/me_main_arch.h"

#include "kernel/base/me_heap_memory.h"
#include "kernel/base/me_string.h"


static struct me_main
{
	me_uint8_t				heap_buffer[ME_SYSTEM_HEAP_SIZE];
	me_heap_manager_t *		heap_manager;

	me_uint32_t				tick;
} g_me_main;


me_uint32_t me_system_tick_get(void)
{
	return (g_me_main.tick);
}

me_size_t me_stdin(me_uint8_t *buffer, me_size_t size)
{
	me_size_t recv_size = 0;

	if (   (buffer != NULL)
		&& (size > 0)
	) {
		recv_size = me_stdin_arch(buffer, size);
	}

	return (recv_size);
}

me_size_t me_stdout(const me_uint8_t *data, me_size_t size)
{
	me_size_t out_size = 0;

	if (   (data != NULL)
		&& (size > 0)
	) {
		out_size = me_stdout_arch(data, size);
	}

	return (out_size);
}

void me_stdout_format(const me_char_t *format, ... )
{
	va_list args = {0};

	/* 可変引数初期化 */
	va_start(args, format);

	/* 処理開始 */
	me_stdout_vformat(format, args);

	/* 可変引数終了 */
	va_end(args);
}

void me_stdout_vformat(const me_char_t *format, va_list args)
{
	me_static_string_t(ME_STDOUT_FORMAT_LENGTH_MAX) str;

	me_static_string_initialize(&str);

	me_string_assign_vformat(me_static_string_to_basic(&str), format, args);

	me_stdout((const me_uint8_t *)me_string_c_str(me_static_string_to_basic(&str)), me_string_length(me_static_string_to_basic(&str)));

	me_string_finalize(me_static_string_to_basic(&str));
}

me_size_t me_stderr(const me_uint8_t *data, me_size_t size)
{
	me_size_t out_size = 0;

	if (   (data != NULL)
		&& (size > 0)
	) {
		out_size = me_stderr_arch(data, size);
	}

	return (out_size);
}

void me_stderr_format(const me_char_t *format, ... )
{
	va_list args = {0};

	/* 可変引数初期化 */
	va_start(args, format);

	/* 処理開始 */
	me_stderr_vformat(format, args);

	/* 可変引数終了 */
	va_end(args);
}

void me_stderr_vformat(const me_char_t *format, va_list args)
{
	me_static_string_t(ME_STDERR_FORMAT_LENGTH_MAX) str;

	me_static_string_initialize(&str);

	me_string_assign_vformat(me_static_string_to_basic(&str), format, args);

	me_stderr((const me_uint8_t *)me_string_c_str(me_static_string_to_basic(&str)), me_string_length(me_static_string_to_basic(&str)));

	me_string_finalize(me_static_string_to_basic(&str));
}

void *me_system_malloc_base(me_size_t size, const me_achar_t *file_name, me_int_t line_no)
{
	void *ptr = NULL;

	if (g_me_main.heap_manager != NULL) {
		ptr = me_heap_malloc_base(g_me_main.heap_manager, size, file_name, line_no);
	}

	return (ptr);
}

void *me_system_calloc_base(me_size_t size, const me_achar_t *file_name, me_int_t line_no)
{
	void *ptr = NULL;

	if (g_me_main.heap_manager != NULL) {
		ptr = me_heap_calloc_base(g_me_main.heap_manager, size, file_name, line_no);
	}

	return (ptr);
}

void me_system_free_base(void *ptr)
{
	if (g_me_main.heap_manager != NULL) {
		me_heap_free(g_me_main.heap_manager, ptr);
	}
}

me_int8_t me_kernel_main(me_int32_t argc, const me_achar_t *argv[])
{
	me_int8_t	exit_code = 0;

	g_me_main.heap_manager = me_heap_initialize(g_me_main.heap_buffer, sizeof(g_me_main.heap_buffer));

	g_me_main.tick = 0;

	exit_code = me_system_main(argc, argv);

	return (exit_code);
}

void me_kernel_on_signal(enum me_signal_type signal)
{
	me_system_on_signal(signal);
}

void me_kernel_tick_set(me_uint32_t tick)
{
	g_me_main.tick = tick;
}

void me_kernel_tick_inc(void)
{
	g_me_main.tick++;
}



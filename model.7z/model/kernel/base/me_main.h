#ifndef ME_MAIN_H_
#define ME_MAIN_H_

#include "kernel/me_kernel.h"


me_int8_t			me_system_main(me_int32_t argc, const me_achar_t *argv[]);

me_int8_t			me_kernel_main(me_int32_t argc, const me_achar_t *argv[]);

me_uint32_t			me_kernel_tick_get(void);
void				me_kernel_tick_set(me_uint32_t tick);
void				me_kernel_tick_inc(void);


#endif

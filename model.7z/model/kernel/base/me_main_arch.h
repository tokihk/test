/* ###################################################################### *//**
 *
 *	@addtogroup	Kernel
 *	@{
 *	@file		me_main_arch.h
 *	@brief		Main Module (for Linux GCC)
 *	@author		Copyright (C) 2019 Hitoshi Kouno
 *
*//* ####################################################################### */
#ifndef ME_MAIN_ARCH_H_
#define ME_MAIN_ARCH_H_

#include "kernel/me_kernel.h"


me_int8_t							me_main_arch(me_int8_t argc, me_achar_t **argv);

me_uint32_t							me_system_tick_msec_get_arch(void);

me_size_t							me_stdin_arch(me_uint8_t *buffer, me_size_t size);

me_size_t							me_stdout_arch(const me_uint8_t *data, me_size_t size);

me_size_t							me_stderr_arch(const me_uint8_t *data, me_size_t size);


#endif /* ME_MAIN_ARCH_H_ */
/* ####### File End ###### */
/** @} */

#ifndef ME_SYSTEM_MAIN_H_
#define ME_SYSTEM_MAIN_H_

#include "kernel/me_kernel.h"

#include <stdarg.h>


enum me_signal_type
{
	ME_SIGNAL_TERM
};


me_int8_t							me_system_main(me_int32_t argc, const me_achar_t *argv[]);
void								me_system_on_signal(enum me_signal_type signal);

me_int32_t							me_system_startup_argument_count(void);
const me_achar_t **					me_system_startup_argument_value(void);

me_uint32_t							me_system_tick_msec_get(void);
me_uint32_t							me_system_tick_msec_elapsed(me_uint32_t tick_start);

me_size_t							me_stdin(me_uint8_t *buffer, me_size_t size);

me_size_t							me_stdout(const me_uint8_t *data, me_size_t size);
void								me_stdout_format(const me_char_t *format, ... );
void								me_stdout_vformat(const me_char_t *format, va_list args);

me_size_t							me_stderr(const me_uint8_t *data, me_size_t size);
void								me_stderr_format(const me_char_t *format, ... );
void								me_stderr_vformat(const me_char_t *format, va_list args);

#define me_malloc(size)				me_system_malloc_base(size, __FILE__, __LINE__)
#define me_calloc(size)				me_system_calloc_base(size, __FILE__, __LINE__)
#define me_free(ptr)				me_system_free_base(ptr)

void *								me_system_malloc_base(me_size_t size, const me_achar_t *file_name, me_int_t line_no);
void *								me_system_calloc_base(me_size_t size, const me_achar_t *file_name, me_int_t line_no);
void								me_system_free_base(void *ptr);


#endif

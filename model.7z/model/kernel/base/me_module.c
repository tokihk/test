#include "kernel/base/me_module.h"
#include "kernel/base/me_main_system.h"

#include <string.h>


static void me_module_initialize(me_module_t *obj)
{
	if (!obj->init_status) {
		obj->init_status = ME_TRUE;
		if ((obj->profile.callback_init != NULL) && (!obj->exit_req)) {
			if (!(obj->profile.callback_init)(obj)) {
				/* 初期化失敗時はすぐに終了 */
				me_module_exit(obj, -128);
			}
		}
	}
}

static void me_module_finalize(me_module_t *obj)
{
	if (obj != NULL) {
		if (obj->profile.callback_exit != NULL) {
			(obj->profile.callback_exit)(obj, obj->exit_reason, obj->exit_code);
		}

		me_free(obj);
	}
}

static void me_module_poll(me_module_t *obj)
{
	if ((obj->profile.callback_poll != NULL) && (!obj->exit_req)) {
		if (obj->polling_count < obj->profile.polling_interval) {
			obj->polling_count++;
		} else {
			(obj->profile.callback_poll)(obj);
			obj->polling_count = 0;
		}
	}
}

static void me_module_list_clear(me_module_t *root)
{
	me_module_t *mod_curr = root->prev;
	me_module_t *mod_temp;

	/* 逆順に開放する */
	while (mod_curr != root) {
		mod_temp = mod_curr;
		mod_curr = mod_curr->prev;

		me_module_finalize(mod_temp);
	}
}

static void me_module_manager_join_new_module(me_module_manager_t *mgr)
{
	if (mgr->module_root_new.next != &mgr->module_root_new) {
		/* 実行中リストの終端に新規モジュールを追加 */
		me_mutex_lock(&mgr->mtx_module);
		{
			struct me_module *mod_new_first = mgr->module_root_new.next;
			struct me_module *mod_new_last  = mgr->module_root_new.prev;
			struct me_module *mod_busy_last = mgr->module_root_busy.prev;

			if (mod_new_first != &mgr->module_root_new) {
				mod_busy_last->next = mod_new_first;
				mod_new_first->prev = mod_busy_last;
				mod_new_last->next = &mgr->module_root_busy;

				mgr->module_root_new.prev = &mgr->module_root_new;
				mgr->module_root_new.next = &mgr->module_root_new;
			}
		}
		me_mutex_unlock(&mgr->mtx_module);
	}
}

static void me_module_manager_poll_base(me_module_manager_t *mgr)
{
	me_module_t *mod_prev = &mgr->module_root_busy;
	me_module_t *mod_curr = mod_prev->next;
	me_module_t *mod_next;

	while (mod_curr != &mgr->module_root_busy) {
		mod_next = mod_curr->next;

		/* 初期化 */
		if (!mod_curr->init_status) {
			me_module_initialize(mod_curr);
		}

		/* ポーリング */
		me_module_poll(mod_curr);

		/* 終了 */
		if (mod_curr->exit_req) {
			me_module_finalize(mod_curr);

			mod_prev->next = mod_next;
			mod_next->prev = mod_prev;
		} else {
			mod_prev = mod_curr;
		}

		mod_curr = mod_next;
	}
}

void me_module_manager_initialize(me_module_manager_t *mgr)
{
	if (mgr != NULL) {
		mgr->guard_code = mgr;
		mgr->module_root_busy.prev = &mgr->module_root_busy;
		mgr->module_root_busy.next = &mgr->module_root_busy;

		mgr->module_root_new.prev = &mgr->module_root_new;
		mgr->module_root_new.next = &mgr->module_root_new;

		me_mutex_create(&mgr->mtx_module);
	}
}

void me_module_manager_finalize(me_module_manager_t *mgr)
{
	if ((mgr != NULL) && (mgr->guard_code == mgr)) {
		me_module_list_clear(&mgr->module_root_busy);
		me_module_list_clear(&mgr->module_root_new);

		me_mutex_destroy(&mgr->mtx_module);

		mgr->guard_code = NULL;
	}
}

void me_module_manager_poll(me_module_manager_t *mgr)
{
	if ((mgr != NULL) && (mgr->guard_code == mgr)) {
		me_module_manager_join_new_module(mgr);

		me_module_manager_poll_base(mgr);
	}
}

me_module_t *me_module_register(me_module_manager_t *mgr, const me_module_profile_t *profile)
{
	me_module_t *mod = NULL;

	if ((mgr != NULL) && (mgr->guard_code == mgr) && (profile != NULL)) {
		mod = me_calloc(sizeof(*mod));
		if (mod != NULL) {
			mod->guard_code = mod;
			mod->profile = *profile;

			/* 新規モジュールリストの終端に挿入 */
			me_mutex_lock(&mgr->mtx_module);
			{
				mod->prev = mgr->module_root_new.next;
				mod->next = &mgr->module_root_new;

				mgr->module_root_new.next->next = mod;
				mgr->module_root_new.prev = mod;
			}
			me_mutex_unlock(&mgr->mtx_module);
		}
	}

	return (mod);
}

void me_module_exit(me_module_t *obj, me_int32_t exit_code)
{
	if ((obj != NULL) && (obj->guard_code == obj) && (!obj->exit_req)) {
		obj->exit_reason = ME_MODULE_EXIT_REASON_USER;
		obj->exit_code = exit_code;
		obj->exit_req = ME_TRUE;
	}
}

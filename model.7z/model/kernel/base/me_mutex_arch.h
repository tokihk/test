/* ###################################################################### *//**
 *
 *	@addtogroup	Kernel
 *	@{
 *	@file		me_mutex_arch.h
 *	@brief		Mutex Module (for Linux GCC)
 *	@author		Copyright (C) 2019 Hitoshi Kouno
 *
*//* ####################################################################### */
#ifndef ME_MUTEX_ARCH_H_
#define ME_MUTEX_ARCH_H_

#include "kernel/me_kernel.h"

#include "kernel/base/me_mutex_param_arch.h"


typedef struct me_mutex_arch
{
	me_mutex_param_arch_t			param;
} me_mutex_arch_t;


me_bool_t			me_mutex_initialize_arch(me_mutex_arch_t *obj);
void				me_mutex_finalize_arch(me_mutex_arch_t *obj);

void				me_mutex_lock_arch(me_mutex_arch_t *obj);
me_bool_t			me_mutex_trylock_arch(me_mutex_arch_t *obj);

void				me_mutex_unlock_arch(me_mutex_arch_t *obj);


#endif /* ME_MUTEX_ARCH_H_ */
/* ####### File End ###### */
/** @} */

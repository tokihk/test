#include "me_string.h"

#include "me_string_utility.h"

#include "me_main_system.h"


#define ME_STRING_ATTR_USE_HEAP_MEMORY			(0x01u)
#define ME_STRING_ATTR_STRETCH_ENABLE			(0x02u)



static void me_string_free(struct me_string *obj)
{
	if ((obj->attr & ME_STRING_ATTR_USE_HEAP_MEMORY) != 0) {
		me_free(obj->value);
	}
}

static me_bool_t me_string_realloc(struct me_string *obj, me_size_t length)
{
	me_bool_t realloc_ok = ME_FALSE;

	if ((obj->attr & (ME_STRING_ATTR_USE_HEAP_MEMORY | ME_STRING_ATTR_STRETCH_ENABLE)) != 0) {

		/* ME_HEAP_STRING_LENGTH_STRETCH_STEPの倍数かつME_HEAP_STRING_LENGTH_MAX以下になるように調整 */
		length = ((length + ME_HEAP_STRING_LENGTH_STRETCH_STEP - 1) / ME_HEAP_STRING_LENGTH_STRETCH_STEP) * ME_HEAP_STRING_LENGTH_STRETCH_STEP;
		if (length > ME_HEAP_STRING_LENGTH_MAX) {
			length = ME_HEAP_STRING_LENGTH_MAX;
		}

		if (obj->length_max < length) {
			me_char_t *value_new;

			value_new = me_malloc(sizeof(me_char_t) * (length + 1));
			if (value_new != NULL) {
				if (obj->length_use > 0) {
					me_strcncpy(value_new, obj->value, obj->length_use);
				}
				me_free(obj->value);

				obj->value = value_new;
				obj->value[obj->length_use] = ME_TEXT('\0');
				obj->length_max = length;

				realloc_ok = ME_TRUE;
			}
		}
	}

	return (realloc_ok);
}


me_bool_t me_string_initialize_heap(struct me_string *obj)
{
	me_bool_t init_ok = ME_FALSE;

	if (obj != NULL) {
		obj->guard_code = obj;
		obj->length_max = 0;
		obj->length_use = 0;
		obj->value = NULL;
		obj->attr = 0;

		init_ok = me_string_realloc(obj, ME_HEAP_STRING_LENGTH_INIT);
	}

	return (init_ok);
}

me_bool_t me_string_initialize_placement(struct me_string *obj, me_uint8_t *buffer, me_size_t buffer_size)
{
	me_bool_t init_ok = ME_FALSE;

	if ((obj != NULL) && (buffer != NULL) && (buffer_size >= (sizeof(me_char_t)))) {
		obj->guard_code = obj;
		obj->length_max = buffer_size / sizeof(me_char_t) - 1;
		obj->length_use = 0;
		obj->value = (me_char_t *)buffer;
		obj->attr = ME_STRING_ATTR_USE_HEAP_MEMORY | ME_STRING_ATTR_STRETCH_ENABLE;

		init_ok = ME_TRUE;
	}

	return (init_ok);
}

void me_string_finalize(struct me_string *obj)
{
	if (obj != NULL) {
		me_string_free(obj);

		obj->length_max = 0;
		obj->length_use = 0;
		obj->value = NULL;
		obj->guard_code = NULL;
	}
}

me_size_t me_string_length(const struct me_string *obj)
{
	me_size_t length = 0;

	if ((obj != NULL) && (obj->guard_code == obj)) {
		length = obj->length_use;
	}

	return (length);
}

const me_char_t *me_string_c_str(const struct me_string *obj)
{
	const me_char_t *text = NULL;

	if ((obj != NULL) && (obj->guard_code == obj)) {
		text = obj->value;
	}

	return (text);
}

me_char_t me_string_get_at(const struct me_string *obj, me_size_t pos)
{
	me_char_t value = ME_TEXT('\0');

	if ((obj != NULL) && (obj->guard_code == obj) && (pos < obj->length_use)) {
		value = obj->value[pos];
	}

	return (value);
}

void me_string_set_at(struct me_string *obj, me_size_t pos, me_char_t value)
{
	if ((obj != NULL) && (obj->guard_code == obj) && (pos < obj->length_use)) {
		obj->value[pos] = value;
	}
}

void me_string_clear(struct me_string *obj)
{
	if ((obj != NULL) && (obj->guard_code == obj)) {
		obj->length_use = 0;
		if (obj->value != NULL) {
			obj->value[obj->length_use] = ME_TEXT('\0');
		}
	}
}

me_int8_t me_string_compare(const struct me_string *obj1, const struct me_string *obj2)
{
	me_int8_t comp = -2;

	if (   (obj1 != NULL)
		&& (obj1->guard_code == obj1)
		&& (obj2 != NULL)
		&& (obj2->guard_code == obj2)
		&& (obj1->value != NULL)
		&& (obj2->value != NULL)
	) {
		const me_char_t *obj1_value = obj1->value;
		const me_char_t *obj2_value = obj2->value;

		while ((*obj1_value != ME_TEXT('\0')) && (*obj2_value != ME_TEXT('\0')) && (*obj1_value == *obj2_value)) {
			obj1_value++;
			obj2_value++;
		}

		if (*obj1_value == *obj2_value) {
			comp = 0;
		} else if (*obj1_value < *obj2_value) {
			comp = -1;
		} else {
			comp = 1;
		}
	}

	return (comp);
}

void me_string_assign(struct me_string *obj, const struct me_string *str)
{
	if (   (obj != NULL)
		&& (obj->guard_code == obj)
		&& (str != NULL)
		&& (str->guard_code == str)
		&& (obj->value != NULL)
		&& (str->value != NULL)
	) {
		me_size_t copy_len = str->length_use;

		if (copy_len > obj->length_max) {
			copy_len = obj->length_max;
		}

		if (copy_len > 0) {
			me_strcncpy(obj->value, str->value, copy_len + 1);
		}
		obj->value[copy_len] = ME_TEXT('\0');
	}
}

void me_string_assign_text(struct me_string *obj, const me_char_t *text, me_size_t maxlen)
{
	if (   (obj != NULL)
		&& (obj->guard_code == obj)
		&& (text != NULL)
		&& (obj->value != NULL)
	) {
		me_size_t copy_len = me_strcnlen(text, ME_HEAP_STRING_LENGTH_MAX);

		if (copy_len > maxlen) {
			copy_len = maxlen;
		}

		if (copy_len > obj->length_max) {
			copy_len = obj->length_max;
		}

		if (copy_len > 0) {
			me_strcncpy(obj->value, text, copy_len + 1);
		}
		obj->value[copy_len] = ME_TEXT('\0');
	}
}

me_bool_t me_string_assign_format(struct me_string *obj, const me_char_t *format, ... )
{
	me_bool_t success = ME_FALSE;

	if ((obj != NULL) && (obj->guard_code == obj) && (format != NULL)) {
		va_list args = {0};

		/* 可変引数初期化 */
		va_start(args, format);

		/* 処理開始 */
		success = me_string_assign_vformat(obj, format, args);

		/* 可変引数終了 */
		va_end(args);
	}

	return (success);
}

me_bool_t me_string_assign_vformat(struct me_string *obj, const me_char_t *format, va_list args)
{
	me_bool_t success = ME_FALSE;

	if ((obj != NULL) && (obj->guard_code == obj) && (format != NULL)) {
		va_list args_temp = {0};
		me_int32_t vsn_temp;

		do {
			/* セットアップ */
			va_copy(args_temp, args);
			vsn_temp = me_string_vsnprintf_arch(obj->value, obj->length_max + 1, format, args_temp);
			va_end(args_temp);

			if (vsn_temp >= 0) {
				/* 成功 */
				success = ME_TRUE;
				break;
			}

			/* バッファを拡張 */
			if (!me_string_realloc(obj, obj->length_max + ME_HEAP_STRING_LENGTH_STRETCH_STEP)) {
				/* 拡張失敗時は終了 */
				break;
			}
		} while (ME_TRUE);

		obj->value[obj->length_use] = ME_TEXT('\0');
	}

	return (success);
}

void me_string_append(struct me_string *obj, const struct me_string *str)
{
	if (   (obj != NULL)
		&& (obj->guard_code == obj)
		&& (str != NULL)
		&& (str->guard_code == str)
	) {
		me_size_t copy_len;

		me_string_realloc(obj, obj->length_use + str->length_use);

		copy_len = str->length_use;
		if (copy_len > (obj->length_max - obj->length_use)) {
			copy_len = obj->length_max - obj->length_use;
		}

		me_strcncpy(obj->value + obj->length_use, str->value, copy_len);
		obj->length_use += copy_len;
		obj->value[obj->length_use] = ME_TEXT('\0');
	}
}

void me_string_append_char(struct me_string *obj, me_char_t value)
{
	if ((obj != NULL) && (obj->guard_code == obj) && (value != ME_TEXT('\0'))) {
		me_string_realloc(obj, obj->length_use + 1);

		if ((obj->length_max - obj->length_use) > 0) {
			obj->value[obj->length_use] = value;
			obj->length_use++;
			obj->value[obj->length_use] = ME_TEXT('\0');
		}
	}
}

void me_string_append_text(struct me_string *obj, const me_char_t *text, me_size_t maxlen)
{
	if ((obj != NULL) && (obj->guard_code == obj) && (text != NULL) && (maxlen > 0)) {
		me_size_t copy_len;

		copy_len = me_strcnlen(text, maxlen);

		me_string_realloc(obj, obj->length_use + copy_len);

		if (copy_len > (obj->length_max - obj->length_use)) {
			copy_len = obj->length_max - obj->length_use;
		}

		me_strcncpy(obj->value + obj->length_use, text, copy_len);
		obj->length_use += copy_len;
		obj->value[obj->length_use] = ME_TEXT('\0');
	}
}

me_bool_t me_string_append_format(struct me_string *obj, const me_char_t *format, ... )
{
	me_bool_t success = ME_FALSE;

	if ((obj != NULL) && (obj->guard_code == obj) && (format != NULL)) {
		va_list args = {0};

		/* 可変引数初期化 */
		va_start(args, format);

		/* 処理開始 */
		success = me_string_append_vformat(obj, format, args);

		/* 可変引数終了 */
		va_end(args);
	}

	return (success);
}

me_bool_t me_string_append_vformat(struct me_string *obj, const me_char_t *format, va_list args)
{
	me_bool_t success = ME_FALSE;

	if ((obj != NULL) && (obj->guard_code == obj) && (format != NULL)) {
		va_list args_temp = {0};
		me_int32_t vsn_temp;

		do {
			/* セットアップ */
			va_copy(args_temp, args);
			vsn_temp = me_string_vsnprintf_arch(obj->value + obj->length_use, obj->length_max - obj->length_use + 1, format, args_temp);
			va_end(args_temp);

			if (vsn_temp >= 0) {
				/* 成功 */
				success = ME_TRUE;
				break;
			}

			/* バッファを拡張 */
			if (!me_string_realloc(obj, obj->length_max + ME_HEAP_STRING_LENGTH_STRETCH_STEP)) {
				/* 拡張失敗時は終了 */
				break;
			}
		} while (ME_TRUE);

		obj->value[obj->length_use] = ME_TEXT('\0');
	}

	return (success);
}


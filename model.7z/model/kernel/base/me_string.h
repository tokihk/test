#ifndef ME_STRING_H_
#define ME_STRING_H_

#include "kernel/me_kernel.h"
#include "kernel/base/me_string_arch.h"

#include <stdarg.h>


typedef struct me_string
{
	me_size_t			length_max;
	me_size_t			length_use;
	me_char_t *			value;
	me_uint8_t			attr;
	void *				guard_code;
} me_string_t;


me_bool_t				me_string_initialize_heap(struct me_string *obj);
me_bool_t				me_string_initialize_placement(struct me_string *obj, me_uint8_t *buffer, me_size_t buffer_size);

void					me_string_finalize(struct me_string *obj);

me_size_t				me_string_length(const struct me_string *obj);

const me_char_t *		me_string_c_str(const struct me_string *obj);

me_char_t				me_string_get_at(const struct me_string *obj, me_size_t pos);
void					me_string_set_at(struct me_string *obj, me_size_t pos, me_char_t value);

void					me_string_clear(struct me_string *obj);

me_int8_t				me_string_compare(const struct me_string *obj1, const struct me_string *obj2);

void					me_string_assign(struct me_string *obj, const struct me_string *str);
void					me_string_assign_text(struct me_string *obj, const me_char_t *text, me_size_t maxlen);
me_bool_t				me_string_assign_format(struct me_string *obj, const me_char_t *format, ... );
me_bool_t				me_string_assign_vformat(struct me_string *obj, const me_char_t *format, va_list args);

void					me_string_append(struct me_string *obj, const struct me_string *str);
void					me_string_append_char(struct me_string *obj, me_char_t value);
void					me_string_append_text(struct me_string *obj, const me_char_t *text, me_size_t maxlen);
me_bool_t				me_string_append_format(struct me_string *obj, const me_char_t *format, ... );
me_bool_t				me_string_append_vformat(struct me_string *obj, const me_char_t *format, va_list args);


#define me_static_string_t(length)					struct { struct me_string basic; me_uint8_t buffer[length * sizeof(me_char_t) + 1]; }

#define me_static_string_to_basic(obj)				(&((obj)->basic))

#define me_static_string_initialize(obj)			me_string_initialize_placement(&((obj)->basic), (obj)->buffer, sizeof((obj)->buffer))


#endif

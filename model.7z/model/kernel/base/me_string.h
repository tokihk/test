#ifndef ME_STRING_H_
#define ME_STRING_H_

#include "kernel/me_kernel.h"
#include "kernel/base/me_string_arch.h"

#include <stdarg.h>


typedef struct me_string_base
{
	me_size_t			length_max;
	me_size_t			length_use;
	me_char_t *			value;
	me_uint8_t			attr;
	void *				guard_code;
} me_string_base_t;


me_bool_t				me_string_initialize_placement_base(struct me_string_base *obj, me_uint8_t *buffer, me_size_t buffer_size, const me_char_t *text);

void					me_string_finalize_base(struct me_string_base *obj);

me_size_t				me_string_length_base(const struct me_string_base *obj);

const me_char_t *		me_string_c_str_base(const struct me_string_base *obj);

me_char_t				me_string_get_at_base(const struct me_string_base *obj, me_size_t pos);
void					me_string_set_at_base(struct me_string_base *obj, me_size_t pos, me_char_t value);

void					me_string_clear_base(struct me_string_base *obj);

me_int8_t				me_string_compare_base(const struct me_string_base *obj1, const struct me_string *obj2);

void					me_string_assign_base(struct me_string_base *obj, const struct me_string *str);
void					me_string_assign_text_base(struct me_string_base *obj, const me_char_t *text, me_size_t maxlen);
me_bool_t				me_string_assign_format_base(struct me_string_base *obj, const me_char_t *format, ... );
me_bool_t				me_string_assign_vformat_base(struct me_string_base *obj, const me_char_t *format, va_list args);

void					me_string_append_base(struct me_string_base *obj, const struct me_string *str);
void					me_string_append_char_base(struct me_string_base *obj, me_char_t value);
void					me_string_append_text_base(struct me_string_base *obj, const me_char_t *text, me_size_t maxlen);
me_bool_t				me_string_append_format_base(struct me_string_base *obj, const me_char_t *format, ... );
me_bool_t				me_string_append_vformat_base(struct me_string_base *obj, const me_char_t *format, va_list args);


#define me_string_t(length)								struct { struct me_string_base base; me_uint8_t buffer[length * sizeof(me_char_t) + 1]; }

#define me_string_initialize(obj, text)					me_string_initialize_placement_base((obj)->base, (obj)->buffer, sizeof((obj)->buffer), text)

#define me_string_finalize(obj)							me_string_finalize_base((obj)->base)

#define me_string_length(obj)							me_string_length_base((obj)->base)

#define me_string_c_str(obj)							me_string_c_str_base((obj)->base)

#define me_string_get_at(obj, pos)						me_string_get_at_base((obj)->base, pos)
#define me_string_set_at(obj, pos, value)				me_string_set_at_base((obj)->base, pos, value)

#define me_string_clear(obj)							me_string_clear_base((obj)->base)

#define me_string_compare(obj1, obj2)					me_string_compare_base((obj1)->base, (obj2)->obj)

#define me_string_assign(obj, str)						me_string_assign_base((obj)->base, str)
#define me_string_assign_text(obj, text, maxlen)		me_string_assign_text_base((obj)->base, text, maxlen)
#define me_string_assign_format(obj, format, ... )		me_string_assign_format_base((obj)->base, format, __VA_ARGS__ )
#define me_string_assign_vformat(obj, format, args)		me_string_assign_vformat_base((obj)->base, format, args)

#define me_string_append(obj, str)						me_string_append_base((obj)->base, str)
#define me_string_append_char(obj, value)				me_string_append_char_base((obj)->base, value)
#define me_string_append_text(obj, text, maxlen)		me_string_append_text_base((obj)->base, text, maxlen)
#define me_string_append_format(obj, format, ... )		me_string_append_format_base((obj)->base, format, __VA_ARGS__ )
#define me_string_append_vformat(obj, format, args)		me_string_append_vformat_base((obj)->base, format, args)


#endif

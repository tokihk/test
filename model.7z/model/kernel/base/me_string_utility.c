#include "me_string_utility.h"

#include <string.h>
#include <wchar.h>


me_size_t me_strcnlen(const me_char_t *str, me_size_t maxlen)
{
#if ME_OPTION_CHAR_IS_WCHAR
	return (me_strwnlen(str, maxlen));
#else
	return (me_stranlen(str, maxlen));
#endif
}

me_size_t me_stranlen(const me_achar_t *str, me_size_t maxlen)
{
	me_size_t length = 0;

	if (str != NULL) {
		length = (me_size_t)strnlen(str, maxlen);
	}

	return (length);
}

me_size_t me_strwnlen(const me_wchar_t *str, me_size_t maxlen)
{
	me_size_t length = 0;

	if (str != NULL) {
		length = (me_size_t)wcsnlen(str, maxlen);
	}

	return (length);
}

void me_strcncpy(me_char_t *dst, const me_char_t *src, me_size_t maxlen)
{
#if ME_OPTION_CHAR_IS_WCHAR
	me_strwncpy(dst, src, maxlen);
#else
	me_strancpy(dst, src, maxlen);
#endif
}

void me_strancpy(me_achar_t *dst, const me_achar_t *src, me_size_t maxlen)
{
	if ((dst != NULL) && (src != NULL)) {
		strncpy(dst, src, maxlen);
	}
}

void me_strwncpy(me_wchar_t *dst, const me_wchar_t *src, me_size_t maxlen)
{
	if ((dst != NULL) && (src != NULL)) {
		wcsncpy(dst, src, maxlen);
	}
}

void me_stratocn(me_char_t *dst, const me_achar_t *src, me_size_t maxlen)
{
#if ME_OPTION_CHAR_IS_WCHAR
	me_stratown(dst, src, maxlen);
#else
	me_strancpy(dst, src, maxlen);
#endif
}

void me_stratown(me_wchar_t *dst, const me_achar_t *src, me_size_t maxlen)
{
	if ((dst != NULL) && (src != NULL)) {
		mbstate_t mbs = {0};
		size_t conv_size;

		while (maxlen > 0) {
			conv_size = mbrtowc(dst, src, maxlen, &mbs);
			if ((conv_size == (size_t)-1) || (conv_size == (size_t)-2)) {
				/* Error */
				break;
			} else if (conv_size == 0) {
				/* 終端 */
			} else {
				/* 変換成功 */
				dst++;
				src += conv_size;
				maxlen -= conv_size;
			}
		}

		*dst = L'\0';
	}
}

void me_strwtocn(me_char_t *dst, const me_wchar_t *src, me_size_t maxlen)
{
#if ME_OPTION_CHAR_IS_WCHAR
	me_strwncpy(dst, src, maxlen);
#else
	me_strwtoan(dst, src, maxlen);
#endif
}

void me_strwtoan(me_achar_t *dst, const me_wchar_t *src, me_size_t maxlen)
{
	if ((dst != NULL) && (src != NULL)) {
		mbstate_t mbs = {0};
		size_t conv_size;

		while ((*src != L'\0') && (maxlen > 0)) {
			conv_size = wcrtomb(dst, *src, &mbs);
			if ((conv_size == (size_t)-1) || (conv_size == (size_t)-2)) {
				/* Error */
				break;
			} else {
				/* 変換成功 */
				dst += conv_size;
			}
			src++;
			maxlen--;
		}

		*dst = '\0';
	}
}

void me_strctoan(me_achar_t *dst, const me_char_t *src, me_size_t maxlen)
{
#if ME_OPTION_CHAR_IS_WCHAR
	me_strwtoan(dst, src, maxlen);
#else
	me_strancpy(dst, src, maxlen);
#endif
}

void me_strctown(me_wchar_t *dst, const me_char_t *src, me_size_t maxlen)
{
#if ME_OPTION_CHAR_IS_WCHAR
	me_strwncpy(dst, src, maxlen);
#else
	me_stratown(dst, src, maxlen);
#endif
}



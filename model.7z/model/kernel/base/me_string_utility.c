#include "me_string_utility.h"

#include <string.h>
#include <wchar.h>


me_size_t me_strcnlen(const me_char_t *str, me_size_t maxlen)
{
#if ME_CHAR_IS_WCHAR
	return (me_strwnlen(str, maxlen));
#else
	return (me_stranlen(str, maxlen));
#endif
}

me_size_t me_stranlen(const me_achar_t *str, me_size_t maxlen)
{
	me_size_t length = 0;

	if (str != NULL) {
		while ((str[length] != '\0') && (length < maxlen)) {
			length++;
		}
	}

	return (length);
}

me_size_t me_strwnlen(const me_wchar_t *str, me_size_t maxlen)
{
	me_size_t length = 0;

	if (str != NULL) {
		while ((str[length] != L'\0') && (length < maxlen)) {
			length++;
		}
	}

	return (length);
}

me_int_t me_strcncmp(const me_char_t *str1, const me_char_t *str2, me_size_t maxlen)
{
	me_int_t result = -2;

#if ME_CHAR_IS_WCHAR
	result = me_strwncmp(str1, str2, maxlen);
#else
	result = me_strancmp(str1, str2, maxlen);
#endif

	return (result);
}

me_int_t me_strancmp(const me_achar_t *str1, const me_achar_t *str2, me_size_t maxlen)
{
	me_int_t result = -2;

	if ((str1 != NULL) && (str2 != NULL)) {
		result = strncmp(str1, str2, maxlen);
	}

	return (result);
}

me_int_t me_strwncmp(const me_wchar_t *str1, const me_wchar_t *str2, me_size_t maxlen)
{
	me_int_t result = -2;

	if ((str1 != NULL) && (str2 != NULL)) {
		result = wcsncmp(str1, str2, maxlen);
	}

	return (result);
}

void me_strcncpy(me_char_t *dst, const me_char_t *src, me_size_t maxlen)
{
#if ME_CHAR_IS_WCHAR
	me_strwncpy(dst, src, maxlen);
#else
	me_strancpy(dst, src, maxlen);
#endif
}

void me_strancpy(me_achar_t *dst, const me_achar_t *src, me_size_t maxlen)
{
	if ((dst != NULL) && (src != NULL)) {
		strncpy(dst, src, maxlen);
	}
}

void me_strwncpy(me_wchar_t *dst, const me_wchar_t *src, me_size_t maxlen)
{
	if ((dst != NULL) && (src != NULL)) {
		wcsncpy(dst, src, maxlen);
	}
}

void me_stratocn(me_char_t *dst, const me_achar_t *src, me_size_t maxlen)
{
#if ME_CHAR_IS_WCHAR
	me_stratown(dst, src, maxlen);
#else
	me_strancpy(dst, src, maxlen);
#endif
}

void me_stratown(me_wchar_t *dst, const me_achar_t *src, me_size_t maxlen)
{
	if ((dst != NULL) && (src != NULL)) {
		mbstate_t mbs = {0};
		size_t conv_size;

		while (maxlen > 0) {
			conv_size = mbrtowc(dst, src, maxlen, &mbs);
			if (conv_size == 0) {
				/* 終端 */
				break;
			} else {
				if ((conv_size == (size_t)-1) || (conv_size == (size_t)-2)) {
					/* Error */
					conv_size = 1;
					*dst = (me_wchar_t)((me_uint16_t)*src);
				}

				dst++;
				src += conv_size;
				maxlen -= conv_size;
			}
		}

		*dst = L'\0';
	}
}

void me_strwtocn(me_char_t *dst, const me_wchar_t *src, me_size_t maxlen)
{
#if ME_CHAR_IS_WCHAR
	me_strwncpy(dst, src, maxlen);
#else
	me_strwtoan(dst, src, maxlen);
#endif
}

void me_strwtoan(me_achar_t *dst, const me_wchar_t *src, me_size_t maxlen)
{
	if ((dst != NULL) && (src != NULL)) {
		mbstate_t mbs = {0};
		size_t conv_size;

		while ((*src != L'\0') && (maxlen > 0)) {
			conv_size = wcrtomb(dst, *src, &mbs);
			if ((conv_size == (size_t)-1) || (conv_size == (size_t)-2)) {
				/* Error */
				*dst = (me_achar_t)((me_uint8_t)*src);
				conv_size = 1;
			}

			dst += conv_size;
			src++;
			maxlen--;
		}

		*dst = '\0';
	}
}

void me_strctoan(me_achar_t *dst, const me_char_t *src, me_size_t maxlen)
{
#if ME_CHAR_IS_WCHAR
	me_strwtoan(dst, src, maxlen);
#else
	me_strancpy(dst, src, maxlen);
#endif
}

void me_strctown(me_wchar_t *dst, const me_char_t *src, me_size_t maxlen)
{
#if ME_CHAR_IS_WCHAR
	me_strwncpy(dst, src, maxlen);
#else
	me_stratown(dst, src, maxlen);
#endif
}

me_size_t me_stratocnlen(const me_achar_t *src, me_size_t maxlen)
{
	me_size_t conv_size = 0;

#if ME_CHAR_IS_WCHAR
	conv_size = me_stratownlen(src, maxlen);
#else
	conv_size = me_stranlen(src, maxlen);
#endif

	return (conv_size);
}

me_size_t me_stratownlen(const me_achar_t *src, me_size_t maxlen)
{
	me_size_t conv_size_all = 0;

	if (src != NULL) {
		mbstate_t mbs = {0};
		me_wchar_t dst[2];
		size_t conv_size;

		while (maxlen > 0) {
			conv_size = mbrtowc(dst, src, maxlen, &mbs);
			if (conv_size == 0) {
				/* 終端 */
				break;
			} else {
				if ((conv_size == (size_t)-1) || (conv_size == (size_t)-2)) {
					/* Error */
					conv_size = 1;
				}

				src += conv_size;
				maxlen -= conv_size;
				conv_size_all += conv_size;
			}
		}
	}

	return (conv_size_all);
}

me_size_t me_strwtocnlen(const me_wchar_t *src, me_size_t maxlen)
{
	me_size_t conv_size = 0;

#if ME_CHAR_IS_WCHAR
	conv_size = me_strwnlen(src, maxlen);
#else
	conv_size = me_strwtoanlen(src, maxlen);
#endif

	return (conv_size);
}

me_size_t me_strwtoanlen(const me_wchar_t *src, me_size_t maxlen)
{
	me_size_t conv_size_all = 0;

	if (src != NULL) {
		mbstate_t mbs = {0};
		me_achar_t dst[ME_MB_LEN_MAX + 1];
		me_size_t conv_size;

		while ((*src != L'\0') && (maxlen > 0)) {
			conv_size = wcrtomb(dst, *src, &mbs);
			if ((conv_size == (size_t)-1) || (conv_size == (size_t)-2)) {
				/* Error */
				conv_size = 1;
			}

			conv_size_all += conv_size;
			src++;
			maxlen--;
		}
	}

	return (conv_size_all);
}

me_size_t me_strctoanlen(const me_char_t *src, me_size_t maxlen)
{
	me_size_t conv_size = 0;

#if ME_CHAR_IS_WCHAR
	conv_size = me_strwtoanlen(src, maxlen);
#else
	conv_size = me_stranlen(src, maxlen);
#endif

	return (conv_size);
}

me_size_t me_strctownlen(const me_char_t *src, me_size_t maxlen)
{
	me_size_t conv_size = 0;

#if ME_CHAR_IS_WCHAR
	conv_size = me_strwnlen(src, maxlen);
#else
	conv_size = me_stratownlen(src, maxlen);
#endif

	return (conv_size);
}


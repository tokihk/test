#ifndef ME_STRING_UTILITY_H_
#define ME_STRING_UTILITY_H_

#include "kernel/me_kernel.h"


me_size_t				me_strcnlen(const me_char_t *str, me_size_t maxlen);
me_size_t				me_stranlen(const me_achar_t *str, me_size_t maxlen);
me_size_t				me_strwnlen(const me_wchar_t *str, me_size_t maxlen);

me_int_t				me_strcncmp(const me_char_t *str1, const me_char_t *str2, me_size_t maxlen);
me_int_t				me_strancmp(const me_achar_t *str1, const me_achar_t *str2, me_size_t maxlen);
me_int_t				me_strwncmp(const me_wchar_t *str1, const me_wchar_t *str2, me_size_t maxlen);

void					me_strcncpy(me_char_t *dst, const me_char_t *src, me_size_t maxlen);
void					me_strancpy(me_achar_t *dst, const me_achar_t *src, me_size_t maxlen);
void					me_strwncpy(me_wchar_t *dst, const me_wchar_t *src, me_size_t maxlen);

void					me_stratocn(me_char_t *dst, const me_achar_t *src, me_size_t maxlen);
void					me_stratown(me_wchar_t *dst, const me_achar_t *src, me_size_t maxlen);

void					me_strwtocn(me_char_t *dst, const me_wchar_t *src, me_size_t maxlen);
void					me_strwtoan(me_achar_t *dst, const me_wchar_t *src, me_size_t maxlen);

void					me_strctoan(me_achar_t *dst, const me_char_t *src, me_size_t maxlen);
void					me_strctown(me_wchar_t *dst, const me_char_t *src, me_size_t maxlen);

me_size_t				me_stratocnlen(const me_achar_t *src, me_size_t maxlen);
me_size_t				me_stratownlen(const me_achar_t *src, me_size_t maxlen);

me_size_t				me_strwtocnlen(const me_wchar_t *src, me_size_t maxlen);
me_size_t				me_strwtoanlen(const me_wchar_t *src, me_size_t maxlen);

me_size_t				me_strctoanlen(const me_char_t *src, me_size_t maxlen);
me_size_t				me_strctownlen(const me_char_t *src, me_size_t maxlen);

#endif

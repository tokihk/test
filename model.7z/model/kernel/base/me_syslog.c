/* ###################################################################### *//**
 *
 *	@addtogroup	Base
 *	@{
 *	@file		ic_syslog.c
 *	@brief		Syslog
 *	@author		Copyright (C) 2019 Hitoshi Kouno
 *
*//* ####################################################################### */

#include "me_syslog.h"

#include "me_string.h"
#include "me_string_utility.h"


#define ME_SYSLOG_OUTPUT_BUFFER_SIZE		(1152)
#define ME_SYSLOG_TCP_CLOSE_DELAY			(2000)


static const me_uint8_t me_syslog_utf8_bom[] = { 0xEF, 0xBB, 0xBF };


static me_bool_t me_syslog_record_enqueue(me_syslog_t *obj, time_t dt_epoch, enum en_me_syslog_facility fac, enum en_me_syslog_severity sev, const me_string_base_t *msg)
{
	me_bool_t success = ME_TRUE;
	struct me_syslog_record *record;

	record = (struct me_syslog_record *)me_malloc(sizeof(*record));
	if (record != NULL) {
		me_size_t msg_len = me_string_length_base(msg) + 1;

		record->dt_epoch = dt_epoch;
		record->fac = fac;
		record->sev = sev;
		record->msg = (me_char_t *)me_malloc(sizeof(me_char_t) * msg_len);
		if (record->msg != NULL) {
			me_strcncpy(record->msg, msg, msg_len);

			me_mutex_lock(&obj->output_mutex);
			{
				record->prev = obj->record_top->prev;
				record->next = &obj->record_top;
				obj->record_top->prev->next = record;
				obj->record_top->prev = record;
			}
			me_mutex_unlock(&obj->output_mutex);

			success = ME_TRUE;
		}
	}

	return (success);
}


static struct me_syslog_record *me_syslog_record_dequeue(me_syslog_t *obj)
{
	struct me_syslog_record *record = NULL;

	if (obj->record_top.next != &obj->record_top) {
		me_mutex_lock(&obj->output_mutex);
		{
			record = obj->record_top.next;
			obj->record_top.next = obj->record_top.next->next;
			obj->record_top.next->prev = &obj->record_top;
		}
		me_mutex_unlock(&obj->output_mutex);
	}

	return (record);
}

#if 0
static const me_char_t *me_syslog_month_code[] = {
	"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
};
#endif

#if 0
static void me_syslog_file_output(me_syslog_t *obj, const me_uint8_t *data, me_uint16_t size)
{
	me_file_t *file;

	file = me_file_open(obj->profile.file.path, IC_FILE_READWRITE_ADD);
	if (file != NULL) {
		me_file_write(file, data, size);
		me_file_close(file);
	}
}
#endif

#if 0
static void me_syslog_tcp_client_output(me_syslog_t *obj, const me_uint8_t *data, me_uint16_t size)
{
	if (obj->tcp_client.obj == NULL) {
		IC_TRAP_PTR_ERROR(obj->tcp_client.obj = me_tcp_client_new(&obj->profile.tcp_client.remote));
	}

	if (obj->tcp_client.obj != NULL) {
		me_tcp_client_send(obj->tcp_client.obj, data, size);
		obj->tcp_client.last_send_time = me_clock_time_msec();
	}
}
#endif

#if 0
static void me_syslog_tcp_client_poll(me_syslog_t *obj)
{
	if (obj->tcp_client.obj != NULL) {
		if (   (!me_tcp_client_send_is_busy(obj->tcp_client.obj))
			&& (me_clock_elapsed_msec(obj->tcp_client.last_send_time) >= IC_SYSLOG_TCP_CLOSE_DELAY)
		) {
			/* 送信が完了していれば閉じる */
			me_tcp_client_delete(obj->tcp_client.obj);
			obj->tcp_client.obj = NULL;
		}
	}
}
#endif

static void me_syslog_setup_header(me_syslog_t *obj, me_string_base_t *log, const struct me_syslog_record *record)
{
	me_datetime_t dt;

	if (me_datetime_utc_time_get(&dt)) {
#if 0
		/* RFC 3164 */
		/* <Code> Jan  1 00:00:00 app_name: 2016-01-01T00:00:00.000 MSG */
		me_string_append_format(
			obj,
			"<%d> %s %2d %02d:%02d:%02d %s: %02d-%02d-%02dT%02d:%02d:%02d.%03d ",
			(me_uint16_t)fac * 8 + (me_uint16_t)sev,
			me_syslog_month_code[dt.month], dt.day, dt.hour, dt.min, dt.sec,
			IC_SPEC_OBJECT_NAME,
			dt.year, dt.month, dt.day, dt.hour, dt.min, dt.sec, dt.msec);
#else
		/* RFC 5424 (https://tools.ietf.org/html/rfc5424) */
		/* <PRI>VERSION TIMESTAMP HOSTNAME APP-NAME - MSGID - MSG */
		/* <PRI>1 2016-01-23T01:23:45.678Z ICOM nx-3761-app-main - NX-3761 - BOMmessage */
		me_string_append_format(
			obj,
			"<%d>1 %04d-%02d-%02dT%02d:%02d:%02d.%03dZ ICOM %s - %s - ",
			(me_uint16_t)fac * 8 + (me_uint16_t)sev,
			dt.year, dt.month, dt.day, dt.hour, dt.min, dt.sec, dt.msec,
			IC_SPEC_OBJECT_NAME,
			IC_SPEC_MACHINE_NAME);

		me_string_append_text(obj, (me_char_t *)me_syslog_utf8_bom, me_countof(me_syslog_utf8_bom));

#endif
	}
}

static void me_syslog_setup_footer(me_string_t *obj)
{
	me_string_append_char(obj, '\n');
}

static void me_syslog_setup(me_syslog_t *obj, me_string_base_t *log)
{

}

static void me_syslog_output_exec(me_syslog_t *obj, const struct me_syslog_record *record)
{


	/* 標準出力 */
	if (   (obj->profile.target, SyslogTargetFlag_Stdout))
		&& (sev <= obj->profile.std_out.filter)
	) {
		me_system_stdout_format(me_string_c_str(str));
	}

	/* 標準エラー出力 */
	if (   (me_has_flag(obj->profile.target, SyslogTargetFlag_Stderr))
		&& (sev <= obj->profile.std_err.filter)
	) {
		me_system_stderr_format(me_string_c_str(str));
	}

	/* ファイル出力 */
	if (   (me_has_flag(obj->profile.target, SyslogTargetFlag_File))
		&& (sev <= obj->profile.file.filter)
	) {
		me_syslog_file_output(obj, (me_uint8_t *)me_string_c_str(str), me_string_length(str));
	}

	/* UDP Client出力 */
	if (   (me_has_flag(obj->profile.target, SyslogTargetFlag_UdpClient))
		&& (sev <= obj->profile.udp_client.filter)
	) {
		/* 最後のNUL文字まで出力 */
		me_udp_client_send(obj->udp_client.obj, (me_uint8_t *)me_string_c_str(str), me_string_length(str) + 1, &obj->profile.udp_client.remote);
	}

	/* TCP Client出力 */
	if (   (me_has_flag(obj->profile.target, SyslogTargetFlag_TcpClient))
		&& (sev <= obj->profile.tcp_client.filter)
	) {
		/* 最後のNUL文字まで出力 */
		me_syslog_tcp_client_output(obj, (me_uint8_t *)me_string_c_str(str), me_string_length(str) + 1);
	}
}

static void me_syslog_thread(me_thread_t *obj, void *param)
{
	me_syslog_t *syslog = (me_syslog_t *)param;
	struct me_syslog_record *record_curr;

	while ((!syslog->exit_req) || (syslog->record_top.next != &syslog->record_top)) {
		while ((record_curr = me_syslog_record_dequeue(syslog)) != NULL) {

		}

		while (syslog->record_top.next != &syslog->record_top) {

		}
	}
}

me_bool_t me_syslog_initialize(me_syslog_t *obj, const struct me_syslog_profile *profile)
{
	me_bool_t success = ME_FALSE;

	if ((obj != NULL) && (profile != NULL)) {
		obj->guard_code = obj;

		obj->profile = *profile;

		obj->record_top.prev = &obj->record_top;
		obj->record_top.next = &obj->record_top;

		me_string_initialize(&obj->output_buffer, NULL);

		obj->exit_req = ME_FALSE;

		if (   (me_mutex_initialize(&obj->output_mutex))
			&& (me_thread_initialize(&obj->output_thread))
		) {
			success = ME_TRUE;
		}

#if 0
		/* UDP Client Setup */
		if (me_has_flag(obj->profile.target, SyslogTargetFlag_UdpClient)) {
			IC_EVENT_OUT_MESSAGE("Syslog UDP Enable");
			IC_TRAP_PTR_ERROR_SET(obj->udp_client.obj = me_udp_client_new(IC_IPDOMAIN_TYPE_IPV4, NULL), error);
		}

		/* TCP Client Setup */
		if (me_has_flag(obj->profile.target, SyslogTargetFlag_TcpClient)) {
			IC_EVENT_OUT_MESSAGE("Syslog TCP Enable");
		}
#endif
	}

	/* === エラー処理 === */
	if (!success) {
		me_syslog_finalize(obj);
	}

	return (success);
}

void me_syslog_finalize(me_syslog_t *obj)
{
	if ((obj != NULL) && (obj->guard_code == obj)) {
		obj->exit_req = ME_TRUE;
		while (me_thread_is_active()) {}

		me_thread_finalize(&obj->output_thread);
		me_mutex_finalize(&obj->output_mutex);

#if 0
		me_udp_client_delete(obj->udp_client.obj);
		me_tcp_client_delete(obj->tcp_client.obj);
#endif

		me_string_finalize(&obj->output_buffer);

		obj->guard_code = NULL;
	}
}

void me_syslog_poll(me_syslog_t *obj)
{
	if ((obj != NULL) && (obj->guard_code == obj)) {
#if 0
		me_syslog_tcp_client_poll(obj);
#endif
	}
}

void me_syslog_output_format(me_syslog_t *obj, enum en_me_syslog_facility fac, enum en_me_syslog_severity sev, const me_char_t *format, ... )
{
	if ((obj != NULL) && (obj->guard_code == obj)) {
		va_list args = {0};

		/* 可変引数初期化 */
		va_start(args, format);

		/* 処理開始 */
		me_syslog_output_vformat(obj, fac, sev, format, args);

		/* 可変引数終了 */
		va_end(args);
	}
}

void me_syslog_output_vformat(me_syslog_t *obj, enum en_me_syslog_facility fac, enum en_me_syslog_severity sev, const me_char_t *format, va_list args)
{
	if ((obj != NULL) && (obj->guard_code == obj)) {
		me_string_t(ME_SYSLOG_MESSAGE_LENGTH_MAX) str_temp;

		if (me_string_initialize(&str_temp, NULL)) {
			/* メッセージ作成 */
			me_string_append_vformat(str_temp, format, args);

			/* 登録 */
			me_syslog_record_enqueue(obj, fac, sev, &str_temp->base);

			me_string_finalize(str_temp);
		}
	}
}

/* ####### File End ###### */
/** @} */

/* ###################################################################### *//**
 *
 *	@addtogroup	Kernel
 *	@{
 *	@file		me_syslog.h
 *	@brief		Syslog Module
 *	@author		Copyright (C) 2019 Hitoshi Kouno
 *
*//* ####################################################################### */
#ifndef ME_SYSLOG_H_
#define ME_SYSLOG_H_

#include "kernel/me_kernel.h"

#include "kernel/base/me_mutex.h"
#include "kernel/base/me_string.h"

#include "kernel/fs/me_path.h"
#include "kernel/fs/me_file.h"

#include <time.h>


#define ME_SYSLOG_RECORD_LENGTH_MAX			(ME_SYSLOG_MESSAGE_LENGTH_MAX + 150)


enum me_syslog_target
{
	MeSyslogTarget_Stdout			= 1 << 0,
	MeSyslogTarget_Stderr			= 1 << 1,
	MeSyslogTarget_File				= 1 << 2,
	MeSyslogTarget_UdpClient		= 1 << 3,
	MeSyslogTarget_TcpClient		= 1 << 4,
};


enum me_syslog_facility
{
	SyslogFacility_Kernel			= 0,
	SyslogFacility_User				= 1,
	SyslogFacility_Mail				= 2,
	SyslogFacility_Daemon			= 3,
	SyslogFacility_Auth0			= 4,
	SyslogFacility_Syslogd			= 5,
	SyslogFacility_LinePrinter		= 6,
	SyslogFacility_News				= 7,
	SyslogFacility_UUCP				= 8,
	SyslogFacility_ClockDaemon0		= 9,
	SyslogFacility_Auth1			= 10,
	SyslogFacility_FTP				= 11,
	SyslogFacility_NTP				= 12,
	SyslogFacility_LogAudit			= 13,
	SyslogFacility_LogAlert			= 14,
	SyslogFacility_ClockDaemon1		= 15,
	SyslogFacility_Local0			= 16,
	SyslogFacility_Local1			= 17,
	SyslogFacility_Local2			= 18,
	SyslogFacility_Local3			= 19,
	SyslogFacility_Local4			= 20,
	SyslogFacility_Local5			= 21,
	SyslogFacility_Local6			= 22,
	SyslogFacility_Local7			= 23,
};

enum me_syslog_severity
{
	SyslogSeverity_Emergency		= 0,
	SyslogSeverity_Alert			= 1,
	SyslogSeverity_Critical			= 2,
	SyslogSeverity_Error			= 3,
	SyslogSeverity_Warning			= 4,
	SyslogSeverity_Notice			= 5,
	SyslogSeverity_Information		= 6,
	SyslogSeverity_Debug			= 7,
};

struct me_syslog_record
{
	struct me_syslog_record *		prev;
	struct me_syslog_record *		next;

	time_t							dt_epoch;
	enum me_syslog_facility			fac;
	enum me_syslog_severity			sev;
	me_char_t *						msg;
};

struct me_syslog_profile_file
{
	me_path_t						output_path;
};

#if 0
struct me_syslog_profile_udp_client
{
	struct me_net_endpoint			remote_ep;
};

struct me_syslog_profile_tcp_client
{
	struct me_net_endpoint			server_ep;
};
#endif

struct me_syslog_profile
{
	enum me_syslog_target					target_flags;
	enum me_syslog_severity					enable_severity_level;

	struct me_syslog_profile_file			file;
//	struct me_syslog_profile_udp_client		udp_client;
//	struct me_syslog_profile_tcp_client		tcp_client;
};

typedef struct me_syslog {
	struct me_syslog_profile					profile;
	struct me_syslog_record						record_top;
	me_thread_t									output_thread;
	me_mutex_t									output_mutex;
	me_string_t(ME_SYSLOG_RECORD_LENGTH_MAX)	output_buffer;
	me_bool_t									exit_req;

	struct {
		me_file_t *							obj;
	} file;

#if 0
	struct {
		me_udp_client_t *					obj;
	} udp_client;

	struct {
		me_tcp_client_t *					obj;
		me_uint32_t							last_send_time;
	} tcp_client;
#endif

	void *									guard_code;
} me_syslog_t;


me_bool_t				me_syslog_initialize(me_syslog_t *obj, const struct me_syslog_profile *profile);
void					me_syslog_finalize(me_syslog_t *obj);
void					me_syslog_poll(me_syslog_t *obj);

void					me_syslog_output_format(me_syslog_t *obj, enum me_syslog_facility fac, enum me_syslog_severity sev, const me_char_t *format, ... );
void					me_syslog_output_vformat(me_syslog_t *obj, enum me_syslog_facility fac, enum me_syslog_severity sev, const me_char_t *format, va_list args);

#endif /* ME_SYSLOG_H_ */
/* ####### File End ###### */
/** @} */


#ifndef ME_SYSTEM_MAIN_H_
#define ME_SYSTEM_MAIN_H_

#include "kernel/me_kernel.h"


enum me_signal_type
{
	ME_SIGNAL_TERM
};


me_int8_t							me_system_main(me_int32_t argc, const me_achar_t *argv[]);
void								me_system_on_signal(enum me_signal_type signal);

me_uint32_t							me_system_tick_get(void);

#define me_malloc(size)				me_system_malloc_base(size, __FILE__, __LINE__)
#define me_calloc(size)				me_system_calloc_base(size, __FILE__, __LINE__)
#define me_free(ptr)				me_system_free_base(ptr)

void *								me_system_malloc_base(me_size_t size, const me_achar_t *file_name, me_int32_t line_no);
void *								me_system_calloc_base(me_size_t size, const me_achar_t *file_name, me_int32_t line_no);
void								me_system_free_base(void *ptr);


#endif

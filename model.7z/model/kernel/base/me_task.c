#include "me_task.h"


static void me_task_main(me_task_arch_t *obj, void *param)
{
	me_task_t *task = (me_task_t *)param;

	UNREFERENCED_PARAMETER(obj);

	if (task->callback != NULL) {
		(task->callback)(task, obj->callback_param);
	}
}

void me_task_scheduler_initialize(void)
{
	me_task_scheduler_initialize_arch();
}

void me_task_scheduler_finalize(void)
{
	me_task_scheduler_finalize_arch();
}

void me_task_scheduler_exec(void)
{
	me_task_scheduler_exec_arch();
}

me_bool_t me_task_create(me_task_t *obj, me_size_t stack_size, me_uint8_t priority, void (* callback)(struct me_task *, void *), void *param)
{
	me_bool_t init_ok = ME_FALSE;

	if ((obj != NULL) && (callback != NULL)) {
		obj->guard_code = obj;

		obj->callback = callback;
		obj->callback_param = param;

		if (me_task_create_arch(&obj->base, stack_size, priority, me_task_main, obj)) {
			init_ok = ME_TRUE;
		}
	}

	if (!init_ok) {
		me_task_destroy(obj);
	}

	return (init_ok);
}

void me_task_destroy(me_task_t *obj)
{
	if ((obj != NULL) && (obj->guard_code == obj)) {
		me_task_destroy_arch(&obj->base);
		obj->guard_code = NULL;
	}
}

void me_task_sleep(me_uint32_t time_msec)
{
	me_task_sleep_arch(time_msec);
}

/* ####### File End ###### */
/** @} */

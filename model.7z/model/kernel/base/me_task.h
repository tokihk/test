/* ###################################################################### *//**
 *
 *	@addtogroup	Kernel
 *	@{
 *	@file		me_task.h
 *	@brief		Task Module
 *	@author		Copyright (C) 2019 Hitoshi Kouno
 *
*//* ####################################################################### */
#ifndef ME_TASK_H_
#define ME_TASK_H_

#include "kernel/me_kernel.h"

#include "kernel/base/me_task_arch.h"


typedef struct me_task
{
	me_task_arch_t			arch_param;

	void					(* callback)(struct me_task *obj, void *param);
	void *					callback_param;

	void *					guard_code;
} me_task_t;


me_bool_t				me_task_create(me_task_t *obj, me_uint8_t *stack_area, me_size_t stack_size, me_uint8_t priority, void (* callback)(struct me_task *, void *), void *param);
void					me_task_destroy(me_task_t *obj);

void					me_task_suspend(me_task_t *obj);
void					me_task_resume(me_task_t *obj);

void					me_task_sleep(me_uint32_t time_ms);


#endif /* ME_TASK_H_ */
/* ####### File End ###### */
/** @} */

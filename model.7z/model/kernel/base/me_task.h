/* ###################################################################### *//**
 *
 *	@addtogroup	Kernel
 *	@{
 *	@file		me_task.h
 *	@brief		Task Module
 *	@author		Copyright (C) 2019 Hitoshi Kouno
 *
*//* ####################################################################### */
#ifndef ME_TASK_H_
#define ME_TASK_H_

#include "kernel/me_kernel.h"

#include "kernel/base/me_task_arch.h"


void					me_task_scheduler_initialize(void);
void					me_task_scheduler_finalize(void);
void					me_task_scheduler_exec(void);

me_bool_t				me_task_create(me_task_t *obj, me_size_t stack_size, me_uint8_t priority, void (* callback)(struct me_task *, void *), void *param);
void					me_task_destroy(me_task_t *obj);

void					me_task_sleep(me_uint32_t time_ms);


#endif /* ME_TASK_H_ */
/* ####### File End ###### */
/** @} */

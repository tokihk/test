/* ###################################################################### *//**
 *
 *	@addtogroup	Kernel
 *	@{
 *	@file		me_task_arch.h
 *	@brief		Task Module
 *	@author		Copyright (C) 2019 Hitoshi Kouno
 *
*//* ####################################################################### */
#ifndef ME_TASK_ARCH_H_
#define ME_TASK_ARCH_H_

#include "kernel/me_kernel.h"


void					me_task_scheduler_initialize_arch(void);
void					me_task_scheduler_finalize_arch(void);
void					me_task_scheduler_exec_arch(void);

me_bool_t				me_task_create_arch(me_task_arch_t *obj, me_uint8_t *stack_area, me_size_t stack_size, me_uint8_t priority, void (* callback)(struct me_task_arch *, void *), void *param);
void					me_task_destroy_arch(me_task_arch_t *obj);

void					me_task_sleep_arch(me_uint32_t time_msec);

me_bool_t				me_task_event_create_arch(me_task_event_arch_t *obj);
void					me_task_event_destroy_arch(me_task_event_arch_t *obj);

me_bool_t				me_task_event_send_arch(me_task_event_arch_t *obj);
me_bool_t				me_task_event_wait_arch(me_task_event_arch_t *obj);


#endif /* ME_TASK_ARCH_H_ */
/* ####### File End ###### */
/** @} */

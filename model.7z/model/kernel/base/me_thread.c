/* ###################################################################### *//**
 *
 *	@addtogroup	Module
 *	@{
 *	@file		ic_thread.c
 *	@brief		エントリポイント
 *	@author		Copyright (C) 2015 Icom.Inc
 *
*//* ####################################################################### */

#include "me_thread.h"


static void me_thread_main(me_thread_arch_t *obj_arch, void *param)
{
	me_thread_t *obj = (me_thread_t *)param;

	UNREFERENCED_PARAMETER(obj_arch);

	if (obj->callback != NULL) {
		(obj->callback)(obj, obj->callback_param);
	}
}

me_bool_t me_thread_initialize(me_thread_t *obj, void (* callback)(struct me_thread *, void *), void *param)
{
	me_bool_t init_ok = ME_FALSE;

	if ((obj != NULL) && (callback != NULL)) {
		obj->guard_code = obj;

		obj->callback = callback;
		obj->callback_param = param;

		if (me_thread_initialize_arch(&obj->arch_param, me_thread_main, obj)) {
			me_thread_start_arch(&obj->arch_param);
			init_ok = ME_TRUE;
		}
	}

	if (!init_ok) {
		me_thread_finalize(obj);
	}

	return (init_ok);
}

void me_thread_finalize(me_thread_t *obj)
{
	if ((obj != NULL) && (obj->guard_code == obj)) {
		me_thread_finalize_arch(&obj->arch_param);
		obj->guard_code = NULL;
	}
}

me_bool_t me_thread_is_active(me_thread_t *obj)
{
	me_bool_t active = ME_FALSE;

	if (obj != NULL) {
		active = me_thread_is_active_arch(&obj->arch_param);
	}

	return (active);
}

void me_thread_exit(void)
{
	me_thread_exit_arch();
}

void me_thread_sleep(me_uint32_t time_s)
{
	me_thread_sleep_arch(time_s);
}

void me_thread_sleep_ms(me_uint32_t time_ms)
{
	me_thread_sleep_ms_arch(time_ms);
}


/* ####### File End ###### */
/** @} */

/* ###################################################################### *//**
 *
 *	@addtogroup	Kernel
 *	@{
 *	@file		me_thread.h
 *	@brief		Thread Module
 *	@author		Copyright (C) 2019 Hitoshi Kouno
 *
*//* ####################################################################### */
#ifndef ME_THREAD_H_
#define ME_THREAD_H_

#include "kernel/me_kernel.h"

#include "kernel/base/me_thread_arch.h"


typedef struct me_thread
{
	void *					guard_code;
	me_thread_arch_t		arch_param;

	void					(* callback)(struct me_thread *obj, void *param);
	void *					callback_param;
} me_thread_t;




me_bool_t				me_thread_initialize(me_thread_t *obj, void (* callback)(struct me_thread *, void *), void *param);
void					me_thread_finalize(me_thread_t *obj);

me_bool_t				me_thread_is_active(me_thread_t *obj);

void					me_thread_exit(void);

void					me_thread_sleep(me_uint32_t time_s);
void					me_thread_sleep_ms(me_uint32_t time_ms);


#endif /* ME_THREAD_H_ */
/* ####### File End ###### */
/** @} */

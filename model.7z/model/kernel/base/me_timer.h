#ifndef ME_TIMER_H_
#define ME_TIMER_H_

#include "kernel/me_kernel.h"

#include "kernel/base/me_timer_arch.h"


typedef struct me_timer
{
	me_timer_arch_t			arch_param;
	void					(* callback)(struct me_timer *obj, void *obj);
} me_timer_t;


me_bool_t				me_timer_initialize(me_timer_t *obj, me_uint32_t clock_hz, void (* callback)(struct me_timer *obj), void *param);
void					me_timer_finalize(me_timer_t *obj);


#endif



#ifndef ME_TYPEDEF_H_
#define ME_TYPEDEF_H_

	#include "kernel/base/me_typedef_arch.h"


	typedef int							me_int_t;

#if ME_CHAR_IS_WCHAR
	typedef me_wchar_t					me_char_t;
	#define ME_TEXT_(text)				L ## text
#else
	typedef me_achar_t					me_char_t;
	#define ME_TEXT_(text)				text
#endif

	#define ME_TEXT(text)				ME_TEXT_(text)
	#define ME_PATH(path)				ME_ROOTDIR path

	typedef struct me_datetime
	{
		me_uint16_t						year;
		me_uint16_t						msec;
		me_uint8_t						month;
		me_uint8_t						day;
		me_uint8_t						hour;
		me_uint8_t						min;
		me_uint8_t						sec;
		me_bool_t						local;
	} me_datetime_t;

	#define ME_TRUE						(1)
	#define ME_FALSE					(0)

	enum me_file_mode {
		ME_FILE_READONLY,
		ME_FILE_READWRITE_NEW,
		ME_FILE_READWRITE_ADD,
	};


#endif

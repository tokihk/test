#ifndef ME_CORE_CONFIG_H_
#define ME_CORE_CONFIG_H_

#include "kernel/core/me_core_config_board.h"


#ifndef ME_ROOTDIR
#define ME_ROOTDIR								"/tmp"
#endif

#ifndef ME_CHAR_IS_WCHAR
#define ME_CHAR_IS_WCHAR						(0)
#endif

#ifndef ME_SYSTEM_HEAP_SIZE
#define ME_SYSTEM_HEAP_SIZE						(0x0000FFFFu)
#endif

#ifndef ME_HEAP_STRING_LENGTH_INIT
#define ME_HEAP_STRING_LENGTH_INIT				(64)
#endif

#ifndef ME_HEAP_STRING_LENGTH_MAX
#define ME_HEAP_STRING_LENGTH_MAX				(1024)
#endif

#ifndef ME_HEAP_STRING_LENGTH_STRETCH_STEP
#define ME_HEAP_STRING_LENGTH_STRETCH_STEP		(32)
#endif

#ifndef ME_PATH_LENGTH_MAX
#define ME_PATH_LENGTH_MAX						(250)
#endif

#ifndef ME_STDOUT_FORMAT_LENGTH_MAX
#define ME_STDOUT_FORMAT_LENGTH_MAX				(250)
#endif

#ifndef ME_STDERR_FORMAT_LENGTH_MAX
#define ME_STDERR_FORMAT_LENGTH_MAX				(250)
#endif

#endif

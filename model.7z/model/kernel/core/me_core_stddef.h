#ifndef ME_CORE_STDDEF_H_
#define ME_CORE_STDDEF_H_

#include "kernel/core/me_stddef.h"


enum me_signal_type
{
	ME_SIGNAL_TERM
};


#endif

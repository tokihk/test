#include "me_datetime.h"

#include "kernel/core/me_datetime_arch.h"


me_bool_t me_datetime_now(struct me_datetime *dt)
{
	me_bool_t success = ME_FALSE;

	if (dt != NULL) {
		success = me_datetime_now_arch(dt);
	}

	return (success);
}

me_bool_t me_datetime_now_utc(struct me_datetime *dt)
{
	me_bool_t success = ME_FALSE;

	if (dt != NULL) {
		success = me_datetime_now_utc_arch(dt);
	}

	return (success);
}

me_uint32_t me_datetime_elapsed_msec(const struct me_datetime *dt_start, const struct me_datetime *dt_end)
{
	return (0);
}


#ifndef ME_DATETIME_STDDEF_H_
#define ME_DATETIME_STDDEF_H_

#include "kernel/core/me_typedef.h"


typedef struct me_datetime
{
	me_uint16_t						year;
	me_uint16_t						msec;
	me_uint8_t						month;
	me_uint8_t						day;
	me_uint8_t						hour;
	me_uint8_t						min;
	me_uint8_t						sec;
	me_bool_t						local;
} me_datetime_t;


#endif

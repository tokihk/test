/* ###################################################################### *//**
 *
 *	@addtogroup	Kernel
 *	@{
 *	@file		me_event.h
 *	@brief		Event Queue Module
 *	@author		Copyright (C) 2019 Hitoshi Kouno
 *
*//* ####################################################################### */
#ifndef ME_EVENT_H_
#define ME_EVENT_H_

#include "kernel/core/me_stddef.h"

#include "kernel/core/me_event_arch.h"


struct me_event_queue
{
	struct me_event_queue_arch		base;
};


me_bool_t				me_event_queue_create(struct me_event_queue *obj, me_size_t event_num_max);
void					me_event_queue_destroy(struct me_event_queue *obj);

me_bool_t				me_event_queue_send(struct me_event_queue *obj, me_uint16_t event_id);
me_bool_t				me_event_queue_send_isr(struct me_event_queue *obj, me_uint16_t event_id);

me_bool_t				me_event_queue_recv(struct me_event_queue *obj, me_uint16_t *event_id, me_uint32_t timeout_msec);
me_bool_t				me_event_queue_recv_isr(struct me_event_queue *obj, me_uint16_t *event_id);


#endif /* ME_EVENT_QUEUE_H_ */
/* ####### File End ###### */
/** @} */

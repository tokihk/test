/* ###################################################################### *//**
 *
 *	@addtogroup	Kernel
 *	@{
 *	@file		me_heap_memory.h
 *	@brief		Heap Memory Module
 *	@author		Copyright (C) 2019 Hitoshi Kouno
 *
*//* ####################################################################### */
#ifndef ME_HEAP_MEMORY_H_
#define ME_HEAP_MEMORY_H_

#include "kernel/core/me_heap_memory_stddef.h"




typedef void (* ME_HEAP_USING_CALLBACK)(me_heap_manager_t *mgr, me_uint32_t index, const struct me_heap_alloc_cell_info *info);


me_bool_t						me_heap_create(struct me_heap_manager *mgr, void *ram_addr, me_size_t ram_size);
void							me_heap_destroy(struct me_heap_manager *mgr);

void							me_heap_using_list(struct me_heap_manager *mgr, ME_HEAP_USING_CALLBACK callback);

#define me_heap_malloc(mgr,size)	me_heap_malloc_base(mgr,size,__FILE__,__LINE__)
#define me_heap_calloc(mgr,size)	me_heap_calloc_base(mgr,size,__FILE__,__LINE__)

void *							me_heap_malloc_base(struct me_heap_manager *mgr, me_size_t size, const me_achar_t *file_name, int line_no);
void *							me_heap_calloc_base(struct me_heap_manager *mgr, me_size_t size, const me_achar_t *file_name, int line_no);

void							me_heap_free(struct me_heap_manager *mgr, void *ptr);


#endif /* ME_HEAP_MEMORY_H_ */
/* ####### File End ###### */
/** @} */

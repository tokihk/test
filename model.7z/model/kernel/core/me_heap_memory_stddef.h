#ifndef ME_HEAP_MEMORY_STDDEF_H_
#define ME_HEAP_MEMORY_STDDEF_H_

#include "kernel/core/me_stddef.h"

#include "kernel/core/me_mutex.h"


struct me_heap_alloc_cell_info
{
	const void *						data_addr;
	me_size_t							data_size;
	const me_achar_t *					source_file_name;
	me_uint32_t							source_line_no;
};

struct me_heap_alloc_cell
{
	me_size_t							cell_size;
	struct me_heap_alloc_cell *			cell_prev;
	struct me_heap_alloc_cell *			cell_next;
	struct me_heap_alloc_cell_info		info;
	void *								guard_code;
};

struct me_heap_free_cell
{
	me_size_t							cell_size;
	struct me_heap_free_cell *			cell_next;
};

struct me_heap_manager
{
	me_uint8_t *						ram_addr;
	me_size_t							ram_size;
	struct me_heap_free_cell			free_cell_top;
	struct me_heap_alloc_cell			alloc_cell_top;
	me_mutex_t							mtx;
};


typedef void (* ME_HEAP_USING_CALLBACK)(struct me_heap_manager *mgr, me_uint32_t index, const struct me_heap_alloc_cell_info *info);


#endif

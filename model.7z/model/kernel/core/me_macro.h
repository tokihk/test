#ifndef ME_MACRO_H_
#define ME_MACRO_H_

	#define UNREFERENCED_PARAMETER(var)		(void)var

	#define ME_COUNTOF(arr)					(sizeof(arr) / sizeof((arr)[0]))

	#define ME_OFFSETOF(st,name)			(me_size_t)(&(((st *)0)->name))
	#define ME_MEMBER_SIZEOF(st,name)		(me_size_t)(sizeof(((st *)0)->name))

	#define ME_TOBOOL(v)					((v) ? (ME_TRUE) : (ME_FALSE))

	#define ME_MIN(v1,v2)					(((v1) < (v2)) ? (v1) : (v2))
	#define ME_MAX(v1,v2)					(((v1) > (v2)) ? (v1) : (v2))

#endif

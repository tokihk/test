#ifndef ME_MODULE_H_
#define ME_MODULE_H_

#include "kernel/core/me_typedef.h"

#include "kernel/core/me_mutex.h"


enum me_module_exit_reason
{
	ME_MODULE_EXIT_REASON_AUTO,
	ME_MODULE_EXIT_REASON_USER,
};


typedef struct me_module			me_module_t;
typedef struct me_module_manager	me_module_manager_t;


typedef struct me_module_profile
{
	me_bool_t						(* callback_init)(me_module_t *obj);
	void							(* callback_exit)(me_module_t *obj, enum me_module_exit_reason reason, me_int32_t exit_code);
	void							(* callback_poll)(me_module_t *obj);

	void *							user_param;

	me_uint8_t						polling_interval;
} me_module_profile_t;

typedef struct me_module
{
	struct me_module *				prev;
	struct me_module *				next;

	struct me_module_profile		profile;

	me_bool_t						init_status;

	enum me_module_exit_reason		exit_reason;
	me_int32_t						exit_code;
	me_bool_t						exit_req;

	me_uint8_t						polling_count;
} me_module_t;

typedef struct me_module_manager
{
	me_mutex_t						mtx_module;

	struct me_module				module_root_busy;
	struct me_module				module_root_new;
} me_module_manager_t;


void								me_module_manager_initialize(me_module_manager_t *mgr);
void								me_module_manager_finalize(me_module_manager_t *mgr);
void								me_module_manager_poll(me_module_manager_t *mgr);

me_module_t *						me_module_register(me_module_manager_t *mgr, const me_module_profile_t *profile);
void								me_module_exit(me_module_t *obj, me_int32_t exit_code);


#endif

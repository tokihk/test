#ifndef ME_MODULE_H_
#define ME_MODULE_H_

#include "kernel/core/me_stddef.h"

#include "kernel/core/me_mutex.h"


struct me_module_manager
{
	me_mutex_t						mtx_module;

	struct me_module				module_root_busy;
	struct me_module				module_root_new;
};

struct me_module
{
	struct me_module *				prev;
	struct me_module *				next;

	struct me_module_profile		profile;

	me_bool_t						init_status;

	enum me_module_exit_reason		exit_reason;
	me_int32_t						exit_code;
	me_bool_t						exit_req;

	me_uint8_t						polling_count;
};


void								me_module_manager_initialize(struct me_module_manager *mgr);
void								me_module_manager_finalize(struct me_module_manager *mgr);
void								me_module_manager_poll(struct me_module_manager *mgr);

struct me_module_t *				me_module_register(struct me_module_manager *mgr, const struct me_module_profile *profile);
void								me_module_unregister(struct me_module *obj, me_int32_t exit_code);


#endif

#ifndef ME_MODULE_STDDEF_H_
#define ME_MODULE_STDDEF_H_

#include "kernel/core/me_stddef.h"


enum me_module_exit_reason
{
	ME_MODULE_EXIT_REASON_AUTO,
	ME_MODULE_EXIT_REASON_USER,
};


struct me_module_manager;
struct me_module;


struct me_module_profile
{
	me_bool_t						(* callback_init)(struct me_module *obj);
	void							(* callback_exit)(struct me_module *obj, enum me_module_exit_reason reason, me_int32_t exit_code);
	void							(* callback_poll)(struct me_module *obj);

	void *							user_param;

	me_uint8_t						polling_interval;
};


#endif

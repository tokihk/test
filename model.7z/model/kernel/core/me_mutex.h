/* ###################################################################### *//**
 *
 *	@addtogroup	Kernel
 *	@{
 *	@file		me_mutex.h
 *	@brief		Mutex Module
 *	@author		Copyright (C) 2019 Hitoshi Kouno
 *
*//* ####################################################################### */
#ifndef ME_MUTEX_H_
#define ME_MUTEX_H_

#include "kernel/core/me_stddef.h"

#include "kernel/core/me_mutex_arch.h"


struct me_mutex
{
	struct me_mutex_arch		base;
};


me_bool_t			me_mutex_create(struct me_mutex *obj);
void				me_mutex_destroy(struct me_mutex *obj);

void				me_mutex_lock(struct me_mutex *obj);
me_bool_t			me_mutex_trylock(struct me_mutex *obj);

void				me_mutex_unlock(struct me_mutex *obj);


#endif /* ME_MUTEX_H_ */
/* ####### File End ###### */
/** @} */

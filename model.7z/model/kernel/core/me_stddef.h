#ifndef ME_STDDEF_H_
#define ME_STDDEF_H_

#include "kernel/core/me_core_config.h"

#include "kernel/core/me_typedef_arch.h"


typedef short							me_short_t;
typedef int								me_int_t;
typedef long							me_long_t;


#if ME_CHAR_IS_WCHAR
	typedef me_wchar_t					me_char_t;
	#define ME_TEXT_(text)				L ## text
#else
	typedef me_achar_t					me_char_t;
	#define ME_TEXT_(text)				text
#endif

#define ME_TEXT(text)					ME_TEXT_(text)

#define ME_TRUE							(1)
#define ME_FALSE						(0)

#define UNREFERENCED_PARAMETER(var)		(void)var

#define ME_COUNTOF(arr)					(sizeof(arr) / sizeof((arr)[0]))
#define ME_OFFSETOF(st,name)			(me_size_t)(&(((st *)0)->name))
#define ME_MEMBER_SIZEOF(st,name)		(me_size_t)(sizeof(((st *)0)->name))

#define ME_TOBOOL(v)					((v) ? (ME_TRUE) : (ME_FALSE))

#define ME_MIN(v1,v2)					(((v1) < (v2)) ? (v1) : (v2))
#define ME_MAX(v1,v2)					(((v1) > (v2)) ? (v1) : (v2))


#endif

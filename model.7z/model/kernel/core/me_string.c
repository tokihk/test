#include "me_string.h"

#include "kernel/core/me_string_arch.h"

#include "me_core.h"


#define ME_STRING_ATTR_USE_HEAP_MEMORY			(0x01u)
#define ME_STRING_ATTR_STRETCH_ENABLE			(0x02u)


static void me_string_free(struct me_string *obj)
{
	if ((obj->attr & ME_STRING_ATTR_USE_HEAP_MEMORY) != 0) {
		me_free(obj->value);
	}
}

static me_bool_t me_string_realloc(struct me_string *obj, me_size_t length)
{
	me_bool_t realloc_ok = ME_FALSE;

	if ((obj->attr & (ME_STRING_ATTR_USE_HEAP_MEMORY | ME_STRING_ATTR_STRETCH_ENABLE)) != 0) {

		/* ME_HEAP_STRING_LENGTH_STRETCH_STEPの倍数かつME_HEAP_STRING_LENGTH_MAX以下になるように調整 */
		length = ((length + ME_HEAP_STRING_LENGTH_STRETCH_STEP - 1) / ME_HEAP_STRING_LENGTH_STRETCH_STEP) * ME_HEAP_STRING_LENGTH_STRETCH_STEP;
		if (length > ME_HEAP_STRING_LENGTH_MAX) {
			length = ME_HEAP_STRING_LENGTH_MAX;
		}

		if (obj->length_max < length) {
			me_char_t *value_new;

			value_new = me_malloc(sizeof(me_char_t) * (length + 1));
			if (value_new != NULL) {
				if (obj->length_use > 0) {
					me_strcncpy(value_new, obj->value, obj->length_use);
				}
				me_free(obj->value);

				obj->value = value_new;
				obj->value[obj->length_use] = ME_TEXT('\0');
				obj->length_max = length;

				realloc_ok = ME_TRUE;
			}
		}
	}

	return (realloc_ok);
}


me_bool_t me_string_initialize_heap(struct me_string *obj)
{
	me_bool_t init_ok = ME_FALSE;

	if (obj != NULL) {
		obj->length_max = 0;
		obj->length_use = 0;
		obj->value = NULL;
		obj->attr = ME_STRING_ATTR_USE_HEAP_MEMORY | ME_STRING_ATTR_STRETCH_ENABLE;

		init_ok = me_string_realloc(obj, ME_HEAP_STRING_LENGTH_INIT);
	}

	return (init_ok);
}

me_bool_t me_string_initialize_placement(struct me_string *obj, me_uint8_t *buffer, me_size_t buffer_size)
{
	me_bool_t init_ok = ME_FALSE;

	if ((obj != NULL) && (buffer != NULL) && (buffer_size >= (sizeof(me_char_t)))) {
		obj->length_max = buffer_size / sizeof(me_char_t) - 1;
		obj->length_use = 0;
		obj->value = (me_char_t *)buffer;
		obj->attr = 0;

		init_ok = ME_TRUE;
	}

	return (init_ok);
}

void me_string_finalize(struct me_string *obj)
{
	if (obj != NULL) {
		me_string_free(obj);

		obj->length_max = 0;
		obj->length_use = 0;
		obj->value = NULL;
	}
}

me_size_t me_string_length(const struct me_string *obj)
{
	me_size_t length = 0;

	if (obj != NULL) {
		length = obj->length_use;
	}

	return (length);
}

const me_char_t *me_string_c_str(const struct me_string *obj)
{
	const me_char_t *text = NULL;

	if (obj != NULL) {
		text = obj->value;
	}

	return (text);
}

me_char_t me_string_get_at(const struct me_string *obj, me_size_t pos)
{
	me_char_t value = ME_TEXT('\0');

	if ((obj != NULL) && (pos < obj->length_use)) {
		value = obj->value[pos];
	}

	return (value);
}

void me_string_set_at(struct me_string *obj, me_size_t pos, me_char_t value)
{
	if ((obj != NULL) && (pos < obj->length_use)) {
		obj->value[pos] = value;
	}
}

void me_string_clear(struct me_string *obj)
{
	if (obj != NULL) {
		obj->length_use = 0;
		if (obj->value != NULL) {
			obj->value[obj->length_use] = ME_TEXT('\0');
		}
	}
}

me_int8_t me_string_compare(const struct me_string *obj1, const struct me_string *obj2)
{
	me_int8_t comp = -2;

	if (   (obj1 != NULL)
		&& (obj2 != NULL)
		&& (obj1->value != NULL)
		&& (obj2->value != NULL)
	) {
		const me_char_t *obj1_value = obj1->value;
		const me_char_t *obj2_value = obj2->value;

		while ((*obj1_value != ME_TEXT('\0')) && (*obj2_value != ME_TEXT('\0')) && (*obj1_value == *obj2_value)) {
			obj1_value++;
			obj2_value++;
		}

		if (*obj1_value == *obj2_value) {
			comp = 0;
		} else if (*obj1_value < *obj2_value) {
			comp = -1;
		} else {
			comp = 1;
		}
	}

	return (comp);
}

void me_string_assign(struct me_string *obj, const struct me_string *str)
{
	if (   (obj != NULL)
		&& (str != NULL)
		&& (obj->value != NULL)
		&& (str->value != NULL)
	) {
		me_size_t copy_len = str->length_use;

		if (copy_len > obj->length_max) {
			copy_len = obj->length_max;
		}

		if (copy_len > 0) {
			me_strcncpy(obj->value, str->value, copy_len + 1);
		}

		obj->length_use = copy_len;

		obj->value[obj->length_use] = ME_TEXT('\0');
	}
}

void me_string_assign_text(struct me_string *obj, const me_char_t *text, me_size_t maxlen)
{
	if (   (obj != NULL)
		&& (obj->value != NULL)
		&& (text != NULL)
	) {
		me_size_t copy_len = me_strcnlen(text, ME_HEAP_STRING_LENGTH_MAX);

		if (copy_len > maxlen) {
			copy_len = maxlen;
		}

		if (copy_len > obj->length_max) {
			copy_len = obj->length_max;
		}

		if (copy_len > 0) {
			me_strcncpy(obj->value, text, copy_len + 1);
		}

		obj->length_use = copy_len;

		obj->value[obj->length_use] = ME_TEXT('\0');
	}
}

me_bool_t me_string_assign_format(struct me_string *obj, const me_char_t *format, ... )
{
	me_bool_t success = ME_FALSE;

	if ((obj != NULL) && (format != NULL)) {
		va_list args = {0};

		/* 可変引数初期化 */
		va_start(args, format);

		/* 処理開始 */
		success = me_string_assign_vformat(obj, format, args);

		/* 可変引数終了 */
		va_end(args);
	}

	return (success);
}

me_bool_t me_string_assign_vformat(struct me_string *obj, const me_char_t *format, va_list args)
{
	me_bool_t success = ME_FALSE;

	if ((obj != NULL) && (format != NULL)) {
		va_list args_temp = {0};
		me_int32_t vsn_temp;

		do {
			/* セットアップ */
			va_copy(args_temp, args);
			vsn_temp = me_string_vsnprintf_arch(obj->value, obj->length_max + 1, format, args_temp);
			va_end(args_temp);

			if (vsn_temp >= 0) {
				/* 成功 */
				obj->length_use = (me_size_t)vsn_temp;
				success = ME_TRUE;
				break;
			}

			/* バッファを拡張 */
			if (!me_string_realloc(obj, obj->length_max + ME_HEAP_STRING_LENGTH_STRETCH_STEP)) {
				/* 拡張失敗時は終了 */
				break;
			}
		} while (ME_TRUE);

		obj->value[obj->length_use] = ME_TEXT('\0');
	}

	return (success);
}

void me_string_append(struct me_string *obj, const struct me_string *str)
{
	if (   (obj != NULL)
		&& (str != NULL)
	) {
		me_size_t copy_len;

		me_string_realloc(obj, obj->length_use + str->length_use);

		copy_len = str->length_use;
		if (copy_len > (obj->length_max - obj->length_use)) {
			copy_len = obj->length_max - obj->length_use;
		}

		me_strcncpy(obj->value + obj->length_use, str->value, copy_len);

		obj->length_use += copy_len;

		obj->value[obj->length_use] = ME_TEXT('\0');
	}
}

void me_string_append_char(struct me_string *obj, me_char_t value)
{
	if ((obj != NULL) && (value != ME_TEXT('\0'))) {
		me_string_realloc(obj, obj->length_use + 1);

		if ((obj->length_max - obj->length_use) > 0) {
			obj->value[obj->length_use] = value;

			obj->length_use++;

			obj->value[obj->length_use] = ME_TEXT('\0');
		}
	}
}

void me_string_append_text(struct me_string *obj, const me_char_t *text, me_size_t maxlen)
{
	if ((obj != NULL) && (text != NULL) && (maxlen > 0)) {
		me_size_t copy_len;

		copy_len = me_strcnlen(text, maxlen);

		me_string_realloc(obj, obj->length_use + copy_len);

		if (copy_len > (obj->length_max - obj->length_use)) {
			copy_len = obj->length_max - obj->length_use;
		}

		me_strcncpy(obj->value + obj->length_use, text, copy_len);

		obj->length_use += copy_len;

		obj->value[obj->length_use] = ME_TEXT('\0');
	}
}

me_bool_t me_string_append_format(struct me_string *obj, const me_char_t *format, ... )
{
	me_bool_t success = ME_FALSE;

	if ((obj != NULL) && (format != NULL)) {
		va_list args = {0};

		/* 可変引数初期化 */
		va_start(args, format);

		/* 処理開始 */
		success = me_string_append_vformat(obj, format, args);

		/* 可変引数終了 */
		va_end(args);
	}

	return (success);
}

me_bool_t me_string_append_vformat(struct me_string *obj, const me_char_t *format, va_list args)
{
	me_bool_t success = ME_FALSE;

	if ((obj != NULL) && (format != NULL)) {
		va_list args_temp = {0};
		me_int32_t vsn_temp;

		do {
			/* セットアップ */
			va_copy(args_temp, args);
			vsn_temp = me_string_vsnprintf_arch(obj->value + obj->length_use, obj->length_max - obj->length_use + 1, format, args_temp);
			va_end(args_temp);

			if (vsn_temp >= 0) {
				/* 成功 */
				obj->length_use += (me_size_t)vsn_temp;
				success = ME_TRUE;
				break;
			}

			/* バッファを拡張 */
			if (!me_string_realloc(obj, obj->length_max + ME_HEAP_STRING_LENGTH_STRETCH_STEP)) {
				/* 拡張失敗時は終了 */
				break;
			}
		} while (ME_TRUE);

		obj->value[obj->length_use] = ME_TEXT('\0');
	}

	return (success);
}

me_size_t me_strcnlen(const me_char_t *str, me_size_t maxlen)
{
#if ME_CHAR_IS_WCHAR
	return (me_strwnlen(str, maxlen));
#else
	return (me_stranlen(str, maxlen));
#endif
}

me_size_t me_stranlen(const me_achar_t *str, me_size_t maxlen)
{
	me_size_t length = 0;

	if (str != NULL) {
		while ((str[length] != '\0') && (length < maxlen)) {
			length++;
		}
	}

	return (length);
}

me_size_t me_strwnlen(const me_wchar_t *str, me_size_t maxlen)
{
	me_size_t length = 0;

	if (str != NULL) {
		while ((str[length] != L'\0') && (length < maxlen)) {
			length++;
		}
	}

	return (length);
}

me_int_t me_strcncmp(const me_char_t *str1, const me_char_t *str2, me_size_t maxlen)
{
	me_int_t result = -2;

#if ME_CHAR_IS_WCHAR
	result = me_strwncmp(str1, str2, maxlen);
#else
	result = me_strancmp(str1, str2, maxlen);
#endif

	return (result);
}

me_int_t me_strancmp(const me_achar_t *str1, const me_achar_t *str2, me_size_t maxlen)
{
	me_int_t result = -2;

	if ((str1 != NULL) && (str2 != NULL)) {
		while ((*str1 == *str2) && (*str1 != '\0') && (maxlen > 0)) {
			str1++;
			str2++;
			maxlen--;
		}

		if (maxlen > 0) {
			result = (me_int_t)(*str1) - (me_int_t)(*str2);
		}
	}

	return (result);
}

me_int_t me_strwncmp(const me_wchar_t *str1, const me_wchar_t *str2, me_size_t maxlen)
{
	me_int_t result = -2;

	if ((str1 != NULL) && (str2 != NULL)) {
		while ((*str1 == *str2) && (*str1 != L'\0') && (maxlen > 0)) {
			str1++;
			str2++;
			maxlen--;
		}

		if (maxlen > 0) {
			result = (me_int_t)(*str1) - (me_int_t)(*str2);
		}
	}

	return (result);
}

void me_strcncpy(me_char_t *dst, const me_char_t *src, me_size_t maxlen)
{
#if ME_CHAR_IS_WCHAR
	me_strwncpy(dst, src, maxlen);
#else
	me_strancpy(dst, src, maxlen);
#endif
}

void me_strancpy(me_achar_t *dst, const me_achar_t *src, me_size_t maxlen)
{
	if ((dst != NULL) && (src != NULL)) {
		while ((*src != '\0') && (maxlen > 0)) {
			*dst = *src;
			src++;
			dst++;
			maxlen--;
		}

		if (maxlen > 0) {
			*dst = '\0';
		}
	}
}

void me_strwncpy(me_wchar_t *dst, const me_wchar_t *src, me_size_t maxlen)
{
	if ((dst != NULL) && (src != NULL)) {
		while ((*src != L'\0') && (maxlen > 0)) {
			*dst = *src;
			src++;
			dst++;
			maxlen--;
		}

		if (maxlen > 0) {
			*dst = L'\0';
		}
	}
}

void me_stratocn(me_char_t *dst, const me_achar_t *src, me_size_t maxlen)
{
#if ME_CHAR_IS_WCHAR
	me_stratown(dst, src, maxlen);
#else
	me_strancpy(dst, src, maxlen);
#endif
}

void me_stratown(me_wchar_t *dst, const me_achar_t *src, me_size_t maxlen)
{
	if ((dst != NULL) && (src != NULL)) {
		mbstate_t mbs = {0};
		size_t conv_size;

		while (maxlen > 0) {
			conv_size = mbrtowc(dst, src, maxlen, &mbs);
			if (conv_size == 0) {
				/* 終端 */
				break;
			} else {
				if ((conv_size == (size_t)-1) || (conv_size == (size_t)-2)) {
					/* Error */
					conv_size = 1;
					*dst = (me_wchar_t)((me_uint16_t)*src);
				}

				dst++;
				src += conv_size;
				maxlen -= conv_size;
			}
		}

		*dst = L'\0';
	}
}

void me_strwtocn(me_char_t *dst, const me_wchar_t *src, me_size_t maxlen)
{
#if ME_CHAR_IS_WCHAR
	me_strwncpy(dst, src, maxlen);
#else
	me_strwtoan(dst, src, maxlen);
#endif
}

void me_strwtoan(me_achar_t *dst, const me_wchar_t *src, me_size_t maxlen)
{
	if ((dst != NULL) && (src != NULL)) {
		mbstate_t mbs = {0};
		size_t conv_size;

		while ((*src != L'\0') && (maxlen > 0)) {
			conv_size = wcrtomb(dst, *src, &mbs);
			if ((conv_size == (size_t)-1) || (conv_size == (size_t)-2)) {
				/* Error */
				*dst = (me_achar_t)((me_uint8_t)*src);
				conv_size = 1;
			}

			dst += conv_size;
			src++;
			maxlen--;
		}

		*dst = '\0';
	}
}

void me_strctoan(me_achar_t *dst, const me_char_t *src, me_size_t maxlen)
{
#if ME_CHAR_IS_WCHAR
	me_strwtoan(dst, src, maxlen);
#else
	me_strancpy(dst, src, maxlen);
#endif
}

void me_strctown(me_wchar_t *dst, const me_char_t *src, me_size_t maxlen)
{
#if ME_CHAR_IS_WCHAR
	me_strwncpy(dst, src, maxlen);
#else
	me_stratown(dst, src, maxlen);
#endif
}

me_size_t me_stratocnlen(const me_achar_t *src, me_size_t maxlen)
{
	me_size_t conv_size = 0;

#if ME_CHAR_IS_WCHAR
	conv_size = me_stratownlen(src, maxlen);
#else
	conv_size = me_stranlen(src, maxlen);
#endif

	return (conv_size);
}

me_size_t me_stratownlen(const me_achar_t *src, me_size_t maxlen)
{
	me_size_t conv_size_all = 0;

	if (src != NULL) {
		mbstate_t mbs = {0};
		me_wchar_t dst[2];
		size_t conv_size;

		while (maxlen > 0) {
			conv_size = mbrtowc(dst, src, maxlen, &mbs);
			if (conv_size == 0) {
				/* 終端 */
				break;
			} else {
				if ((conv_size == (size_t)-1) || (conv_size == (size_t)-2)) {
					/* Error */
					conv_size = 1;
				}

				src += conv_size;
				maxlen -= conv_size;
				conv_size_all += conv_size;
			}
		}
	}

	return (conv_size_all);
}

me_size_t me_strwtocnlen(const me_wchar_t *src, me_size_t maxlen)
{
	me_size_t conv_size = 0;

#if ME_CHAR_IS_WCHAR
	conv_size = me_strwnlen(src, maxlen);
#else
	conv_size = me_strwtoanlen(src, maxlen);
#endif

	return (conv_size);
}

me_size_t me_strwtoanlen(const me_wchar_t *src, me_size_t maxlen)
{
	me_size_t conv_size_all = 0;

	if (src != NULL) {
		mbstate_t mbs = {0};
		me_achar_t dst[ME_MB_LEN_MAX + 1];
		me_size_t conv_size;

		while ((*src != L'\0') && (maxlen > 0)) {
			conv_size = wcrtomb(dst, *src, &mbs);
			if ((conv_size == (size_t)-1) || (conv_size == (size_t)-2)) {
				/* Error */
				conv_size = 1;
			}

			conv_size_all += conv_size;
			src++;
			maxlen--;
		}
	}

	return (conv_size_all);
}

me_size_t me_strctoanlen(const me_char_t *src, me_size_t maxlen)
{
	me_size_t conv_size = 0;

#if ME_CHAR_IS_WCHAR
	conv_size = me_strwtoanlen(src, maxlen);
#else
	conv_size = me_stranlen(src, maxlen);
#endif

	return (conv_size);
}

me_size_t me_strctownlen(const me_char_t *src, me_size_t maxlen)
{
	me_size_t conv_size = 0;

#if ME_CHAR_IS_WCHAR
	conv_size = me_strwnlen(src, maxlen);
#else
	conv_size = me_stratownlen(src, maxlen);
#endif

	return (conv_size);
}


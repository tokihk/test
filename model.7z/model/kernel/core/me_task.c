#include "me_task.h"


static void me_task_main(struct me_task_arch *obj, void *param)
{
	struct me_task *task = (struct me_task *)param;

	UNREFERENCED_PARAMETER(obj);

	if (task->callback != NULL) {
		(task->callback)(task, obj->callback_param);
	}
}

void me_task_scheduler_initialize(void)
{
	me_task_scheduler_initialize_arch();
}

void me_task_scheduler_finalize(void)
{
	me_task_scheduler_finalize_arch();
}

void me_task_scheduler_exec(void)
{
	me_task_scheduler_exec_arch();
}

me_bool_t me_task_create(struct me_task *obj, const struct me_task_profile *profile)
{
	me_bool_t init_ok = ME_FALSE;

	if (   (obj != NULL)
		&& (profile != NULL)
		&& (profile->callback != NULL)
	) {
		obj->callback = profile->callback;
		obj->callback_param = profile->param;

		if (me_task_create_arch(&obj->base, profile->stack_size, profile->priority, me_task_main, obj)) {
			init_ok = ME_TRUE;
		}
	}

	if (!init_ok) {
		me_task_destroy(obj);
	}

	return (init_ok);
}

void me_task_destroy(struct me_task *obj)
{
	if (obj != NULL) {
		me_task_destroy_arch(&obj->base);
	}
}

void me_task_sleep_msec(me_uint32_t time_msec)
{
	me_task_sleep_msec_arch(time_msec);
}

/* ####### File End ###### */
/** @} */

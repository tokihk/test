/* ###################################################################### *//**
 *
 *	@addtogroup	Kernel
 *	@{
 *	@file		me_task.h
 *	@brief		Task Module
 *	@author		Copyright (C) 2019 Hitoshi Kouno
 *
*//* ####################################################################### */
#ifndef ME_TASK_H_
#define ME_TASK_H_

#include "kernel/core/me_task_stddef.h"

#include "kernel/core/me_task_arch.h"


struct me_task
{
	struct me_task_arch			base;

	void						(* callback)(struct me_task *obj, void *param);
	void *						callback_param;
};


void					me_task_scheduler_initialize(void);
void					me_task_scheduler_finalize(void);
void					me_task_scheduler_exec(void);

me_bool_t				me_task_create(me_task_t *obj, const struct me_task_profile *profile);
void					me_task_destroy(me_task_t *obj);

void					me_task_sleep_msec(me_uint32_t time_ms);


#endif /* ME_TASK_H_ */
/* ####### File End ###### */
/** @} */

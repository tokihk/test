#ifndef ME_TASK_STDDEF_H_
#define ME_TASK_STDDEF_H_

#include "kernel/core/me_stddef.h"


struct me_task_profile
{
	me_size_t		stack_size;
	me_uint8_t		priority;
	void			(* callback)(struct me_task *, void *);
	void *			param;
};


#endif

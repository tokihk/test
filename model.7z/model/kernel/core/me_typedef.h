#ifndef ME_TYPEDEF_H_
#define ME_TYPEDEF_H_

#include "kernel/core/me_core_config.h"

#include "kernel/base/me_typedef_arch.h"


typedef short						me_short_t;
typedef int							me_int_t;
typedef long						me_long_t;


#if ME_CHAR_IS_WCHAR
	typedef me_wchar_t				me_char_t;
	#define ME_TEXT_(text)			L ## text
#else
	typedef me_achar_t				me_char_t;
	#define ME_TEXT_(text)			text
#endif

#define ME_TEXT(text)				ME_TEXT_(text)

#define ME_TRUE						(1)
#define ME_FALSE					(0)

	enum me_file_mode {
		ME_FILE_READONLY,
		ME_FILE_READWRITE_NEW,
		ME_FILE_READWRITE_ADD,
	};

	typedef struct me_task
	{
		me_task_arch_t				base;

		void						(* callback)(struct me_task *obj, void *param);
		void *						callback_param;

		void *						guard_code;
	} me_task_t;

	typedef struct me_event_queue
	{
		me_event_queue_arch_t		base;
	} me_event_queue_t;

	typedef struct me_mutex
	{
		me_mutex_arch_t				base;
		void *						guard_code;
	} me_mutex_t;

#endif

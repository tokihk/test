#ifndef ME_DEV_ADC_H_
#define ME_DEV_ADC_H_

#include "kernel/dev/me_dev_gpio_board.h"


me_bool_t					me_dev_adc_initialize(void);
void						me_dev_adc_finalize(void);

me_bool_t					me_dev_adc_value_get(me_uint16_t adc_id);


#endif

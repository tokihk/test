#include "me_dev_gpio.h"

#include "kernel/dev/me_dev_gpio_board.h"


void me_dev_gpio_initialize(void)
{
	me_dev_gpio_initialize_board();
}

void me_dev_gpio_finalize(void)
{
	me_dev_gpio_finalize_board();
}

me_bool_t me_dev_gpio_direction_get(me_uint16_t pin)
{
	return (me_dev_gpio_direction_get_board(pin));
}

void me_dev_gpio_direction_set(me_uint16_t pin, me_bool_t dir)
{
	me_dev_gpio_direction_set_arch(pin, dir);
}

me_bool_t me_dev_gpio_value_get(me_uint16_t pin)
{
	return (me_dev_gpio_value_get_arch(pin));
}

void me_dev_gpio_value_set(me_uint16_t pin, me_bool_t value)
{
	me_dev_gpio_value_set_arch(pin, value);
}

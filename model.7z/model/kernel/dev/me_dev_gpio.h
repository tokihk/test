#ifndef ME_DEV_GPIO_H_
#define ME_DEV_GPIO_H_

#include "kernel/dev/me_dev_gpio_board.h"


void						me_dev_gpio_initialize(void);
void						me_dev_gpio_finalize(void);

me_bool_t					me_dev_gpio_direction_get(me_uint16_t gpio_id);
void						me_dev_gpio_direction_set(me_uint16_t gpio_id, me_bool_t dir);

me_bool_t					me_dev_gpio_value_get(me_uint16_t gpio_id);
void						me_dev_gpio_value_set(me_uint16_t gpio_id, me_bool_t value);


#endif

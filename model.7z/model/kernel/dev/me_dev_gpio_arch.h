#ifndef ME_DEV_GPIO_ARCH_H_
#define ME_DEV_GPIO_ARCH_H_

#include "kernel/me_kernel.h"


#define ME_DEV_GPIO_FUNC_TOP						(0xF000)
#define ME_DEV_GPIO_FUNC_INFRARED_RECEIVER			(ME_DEV_GPIO_FUNC_TOP + 0)


me_bool_t					me_dev_gpio_initialize_arch(void);
void						me_dev_gpio_finalize_arch(void);

me_bool_t					me_dev_gpio_direction_get_arch(me_uint16_t gpio_id);
void						me_dev_gpio_direction_set_arch(me_uint16_t gpio_id, me_bool_t dir);

me_bool_t					me_dev_gpio_value_get_arch(me_uint16_t gpio_id);
void						me_dev_gpio_value_set_arch(me_uint16_t gpio_id, me_bool_t value);


#endif

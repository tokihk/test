#ifndef ME_DEV_GPIO_BOARD_H_
#define ME_DEV_GPIO_BOARD_H_

#include "kernel/dev/me_dev_gpio_arch.h"


void						me_dev_gpio_initialize_board(void);
void						me_dev_gpio_finalize_board(void);

me_bool_t					me_dev_gpio_direction_get_board(me_uint16_t gpio_id);
void						me_dev_gpio_direction_set_board(me_uint16_t gpio_id, me_bool_t dir);

me_bool_t					me_dev_gpio_value_get_board(me_uint16_t gpio_id);
void						me_dev_gpio_value_set_board(me_uint16_t gpio_id, me_bool_t value);


#endif

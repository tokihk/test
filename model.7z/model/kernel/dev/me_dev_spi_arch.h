#ifndef ME_DEV_SPI_ARCH_H_
#define ME_DEV_SPI_ARCH_H_

#include "kernel/me_kernel.h"

#include "kernel/dev/me_dev_typedef.h"


me_bool_t					me_dev_spi_initialize_arch(void);
void						me_dev_spi_finalize_arch(void);

me_bool_t					me_dev_spi_setup_arch(me_uint16_t spi_id, enum me_dev_spi_mode mode, me_uint32_t clock_hz);

me_size_t					me_dev_spi_send_arch(me_uint16_t spi_id, const me_uint8_t *data, me_size_t size);

me_bool_t					me_dev_spi_send_async_arch(me_uint16_t spi_id, const me_uint8_t *data, me_size_t size);
me_bool_t					me_dev_spi_send_async_is_busy_arch(me_uint16_t spi_id);

me_size_t					me_dev_spi_recv_arch(me_uint16_t spi_id, me_uint8_t *buffer, me_size_t buffer_size);

me_bool_t					me_dev_spi_recv_async_arch(me_uint16_t spi_id, me_uint8_t *buffer, me_size_t buffer_size);
me_bool_t					me_dev_spi_recv_async_is_busy_arch(me_uint16_t spi_id);


#endif

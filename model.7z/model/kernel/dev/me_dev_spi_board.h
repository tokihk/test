#ifndef ME_DEV_SPI_H_
#define ME_DEV_SPI_H_

#include "kernel/dev/me_dev_spi_board.h"


me_bool_t					me_dev_spi_initialize(void);
void						me_dev_spi_finalize(void);

me_bool_t					me_dev_spi_mode_set(me_uint16_t spi_id, enum me_dev_spi_mode mode, me_size_t cache_size);

me_size_t					me_dev_spi_send(me_uint16_t spi_id, const me_uint8_t *data, me_size_t size);

me_size_t					me_dev_spi_recv(me_uint16_t spi_id, me_uint8_t *buffer, me_size_t buffer_size);


#endif

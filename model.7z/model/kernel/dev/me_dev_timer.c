#include "me_dev_timer.h"


void me_dev_timer_initialize(void)
{
	me_dev_timer_initialize_board();
}

void me_dev_timer_finalize(void)
{
	me_dev_timer_finalize_board();
}

me_bool_t me_dev_timer_create(me_uint16_t tmr_id, me_uint32_t ival_hz)
{
	me_bool_t success = ME_FALSE;

	if (ival_hz > 0) {
		success = me_dev_timer_create_board(tmr_id, ival_hz);
	}

	return (success);
}

void me_dev_timer_destroy(me_uint16_t tmr_id)
{
	me_dev_timer_destroy_board(tmr_id);
}

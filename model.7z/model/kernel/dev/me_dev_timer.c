#include "me_dev_timer.h"


static void me_dev_timer_callback_base_isr(me_dev_timer_arch_t *obj, void *param)
{
	me_dev_timer_t *tmr_obj = (me_dev_timer_t *)param;

	(tmr_obj->callback_isr)(tmr_obj, tmr_obj->callback_param);
}

void me_dev_timer_initialize(void)
{
	me_dev_timer_initialize_arch();
}

void me_dev_timer_finalize(void)
{
	me_dev_timer_finalize_arch();
}

me_bool_t me_dev_timer_create(me_dev_timer_t *obj, const me_dev_timer_config_t *config)
{
	me_bool_t success = ME_FALSE;

	if (   (obj != NULL)
		&& (config != NULL)
		&& (config->interval_hz > 0)
	) {
		me_dev_timer_config_arch_t	config_arch = {0};

		config_arch.callback_isr = me_dev_timer_callback_base_isr;
		config_arch.callback_param = obj;

		obj->callback_isr = config->callback_isr;
		obj->callback_param = config->callback_param;

		if (me_dev_timer_create_arch(&obj->arch_obj, &config_arch)) {
			success = ME_TRUE;
		}
	}

	return (success);
}

void me_dev_timer_destroy(me_dev_timer_t *obj)
{
	if (obj != NULL) {
		me_dev_timer_destroy_arch(&obj->arch_obj);
	}
}

void me_dev_timer_start(me_dev_timer_t *obj)
{
	if (obj != NULL) {
		me_dev_timer_start_arch(&obj->arch_obj);
	}
}

void me_dev_timer_stop(me_dev_timer_t *obj)
{
	if (obj != NULL) {
		me_dev_timer_stop_arch(&obj->arch_obj);
	}
}


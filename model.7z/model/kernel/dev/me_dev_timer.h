#ifndef ME_DEV_TIMER_H_
#define ME_DEV_TIMER_H_

#include "kernel/dev/me_dev_timer_board.h"


me_bool_t				me_dev_timer_initialize(void);
void					me_dev_timer_finalize(void);

me_bool_t				me_dev_timer_create(me_uint16_t tmr_id, me_uint32_t ival_10nsec, me_dev_timer_callback_t callback);
void					me_dev_timer_destroy(me_uint16_t tmr_id);


#endif



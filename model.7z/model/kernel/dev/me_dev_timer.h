#ifndef ME_DEV_TIMER_H_
#define ME_DEV_TIMER_H_

#include "kernel/me_kernel.h"

#include "kernel/dev/me_dev_timer_arch.h"


typedef struct me_dev_timer me_dev_timer_t;

typedef struct me_dev_timer_config
{
	me_uint32_t			interval_hz;
	void				(* callback_isr)(me_dev_timer_t *obj, void *param);
	void *				callback_param;
} me_dev_timer_config_t;


typedef struct me_dev_timer
{
	me_dev_timer_arch_t		arch_obj;
	void					(* callback_isr)(me_dev_timer_t *obj, void *param);
	void *					callback_param;
} me_dev_timer_t;


void					me_dev_timer_initialize(void);
void					me_dev_timer_finalize(void);

me_bool_t				me_dev_timer_create(me_dev_timer_t *obj, const me_dev_timer_config_t *config);
void					me_dev_timer_destroy(me_dev_timer_t *obj);

void					me_dev_timer_start(me_dev_timer_t *obj);
void					me_dev_timer_stop(me_dev_timer_t *obj);

#endif



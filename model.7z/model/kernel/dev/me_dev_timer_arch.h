#ifndef ME_DEV_TIMER_ARCH_H_
#define ME_DEV_TIMER_ARCH_H_

#include "kernel/me_kernel.h"


#define ME_DEV_TIMER_FUNC_TOP			(0xF000u)
#define ME_DEV_TIMER_FUNC_GENERAL_0		(ME_DEV_TIMER_FUNC_TOP + 0u)
#define ME_DEV_TIMER_FUNC_GENERAL_1		(ME_DEV_TIMER_FUNC_TOP + 1u)
#define ME_DEV_TIMER_FUNC_GENERAL_2		(ME_DEV_TIMER_FUNC_TOP + 2u)
#define ME_DEV_TIMER_FUNC_GENERAL_3		(ME_DEV_TIMER_FUNC_TOP + 3u)


void					me_dev_timer_initialize_arch(void);
void					me_dev_timer_finalize_arch(void);

me_bool_t				me_dev_timer_create_arch(me_uint16_t tmr_id, me_uint32_t ival_hz);
void					me_dev_timer_destroy_arch(me_uint16_t tmr_id);


#endif

#ifndef ME_DEV_TIMER_BOARD_H_
#define ME_DEV_TIMER_BOARD_H_

#include "kernel/dev/me_dev_timer_arch.h"


me_bool_t				me_dev_timer_initialize_board(void);
void					me_dev_timer_finalize_board(void);

me_bool_t				me_dev_timer_create_board(me_uint16_t tmr_id, me_uint32_t ival_10nsec, me_dev_timer_callback_t callback);
void					me_dev_timer_destroy_board(me_uint16_t tmr_id);


#endif

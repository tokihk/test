#ifndef ME_DEV_TYPEDEF_H_
#define ME_DEV_TYPEDEF_H_

#include <kernel/dev/me_dev_typedef_arch.h>


enum me_dev_gpio_id
{
	ME_DEV_GPIO_ID_DEBUG_00,
	ME_DEV_GPIO_ID_DEBUG_01,
};


typedef void (* me_dev_timer_callback_t)(me_uint16_t tmr_id);


enum me_dev_spi_mode
{
	ME_DEV_SPI_MODE_MASTER,
	ME_DEV_SPI_MODE_SLAVE,
};


#endif

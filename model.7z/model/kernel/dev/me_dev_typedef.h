#ifndef ME_DEV_TYPEDEF_H_
#define ME_DEV_TYPEDEF_H_

#include "kernel/me_kernel.h"

#include "kernel/net/me_dev_typedef_board.h"



#endif

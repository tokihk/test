#include "me_device.h"


void me_device_initialize(void)
{
	me_device_initialize_arch();
}

void me_device_finalize(void)
{
	me_device_finalize_arch();
}

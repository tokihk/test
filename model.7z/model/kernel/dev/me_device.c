#include "me_device.h"

#include "kernel/dev/me_device_arch.h"


void me_device_initialize(void)
{
	me_device_initialize_arch();
}

void me_device_finalize(void)
{
	me_device_finalize_arch();
}

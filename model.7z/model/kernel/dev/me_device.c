#include "me_device.h"

#include "me_dev_timer.h"


me_bool_t me_device_initialize(void)
{
	if (!me_device_initialize_board()) {
		return (ME_FALSE);
	}

	if (!me_dev_timer_initialize()) {
		return (ME_FALSE);
	}

	return (ME_TRUE);
}

void me_device_finalize(void)
{
	me_dev_timer_finalize();

	me_device_finalize_board();
}


#ifndef ME_DEVICE_H_
#define ME_DEVICE_H_

#include "kernel/dev/me_device_board.h"


me_bool_t			me_device_initialize(void);
void				me_device_finalize(void);


#endif

#ifndef ME_DEVICE_ARCH_H_
#define ME_DEVICE_ARCH_H_

#include "kernel/me_kernel.h"


me_bool_t			me_device_initialize_arch(void);
void				me_device_finalize_arch(void);


#endif

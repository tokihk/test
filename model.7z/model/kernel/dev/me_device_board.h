#ifndef ME_DEVICE_BOARD_H_
#define ME_DEVICE_BOARD_H_

#include "kernel/dev/me_device_arch.h"


void				me_device_initialize_board(void);
void				me_device_finalize_board(void);


#endif

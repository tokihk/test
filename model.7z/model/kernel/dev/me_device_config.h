#ifndef ME_DEVICE_CONFIG_H_
#define ME_DEVICE_CONFIG_H_

#include "kernel/dev/me_device_config_board.h"


#ifndef ME_DEVICE_CONFIG_TIMER_NUMBER
#define ME_DEVICE_CONFIG_TIMER_NUMBER			(1)
#endif

#endif

#ifndef ME_DEVICE_TYPEDEF_H_
#define ME_DEVICE_TYPEDEF_H_

#include "kernel/me_kernel.h"


enum me_gpio_direction
{
	MeGpioDir_Input,
	MeGpioDir_Output,
};

enum me_gpio_logic
{
	MeGpioLogic_Low,
	MeGpioLogic_High,
};


#endif

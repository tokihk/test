#ifndef ME_DEVICE_TYPEDEF_H_
#define ME_DEVICE_TYPEDEF_H_

#include "kernel/me_kernel.h"

#include "kernel/dev/me_device_config_arch.h"


enum me_dev_gpio_dir
{
	MeDevGpioDir_Input,
	MeDevGpioDir_Output,
};


typedef struct me_dev_timer_arch me_dev_timer_arch_t;


typedef struct me_dev_timer_config_arch
{
	me_uint32_t			interval_hz;
	void				(* callback_isr)(me_dev_timer_arch_t *obj, void *param);
	void *				callback_param;
} me_dev_timer_config_arch_t;

#endif

#include "drivers/display/drv_display.h"


me_bool_t drv_display_initialize(me_uint16_t display_id)
{
	return (drv_display_initialize_board(display_id));
}

void drv_display_finalize(me_uint16_t display_id)
{
	drv_display_finalize_board(display_id);
}

me_bool_t drv_display_transfer_rect16(me_uint16_t display_id, const me_uint8_t *data, me_size_t size)
{
	me_bool_t success = ME_FALSE;

	if ((data != NULL) && (size > 0)) {
		success = drv_display_transfer_rect_board(display_id, data, size);
	}

	return (success);
}

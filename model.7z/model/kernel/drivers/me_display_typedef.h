#ifndef DRV_DISPLAY_TYPEDEF_H_
#define DRV_DISPLAY_TYPEDEF_H_

#include "kernel/me_kernel.h"


enum drv_display_port
{
	DRV_DISPLAY_PORT_RESET,
	DRV_DISPLAY_PORT_DCX,
};


struct drv_display_api
{
	void			(* port_out)(enum drv_display_port port, me_bool_t value);
	me_size_t		(* data_send)(const me_uint8_t *data, me_size_t size);
	me_size_t		(* data_recv)(me_uint8_t *buffer, me_size_t buffer_size);
};


struct drv_display_config
{
	/* 0: Device Default. */
	me_size_t		width;

	/* 0: Device Default. */
	me_size_t		height;
};


#endif


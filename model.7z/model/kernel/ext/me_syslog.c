/* ###################################################################### *//**
 *
 *	@addtogroup	Base
 *	@{
 *	@file		ic_syslog.c
 *	@brief		Syslog
 *	@author		Copyright (C) 2019 Hitoshi Kouno
 *
*//* ####################################################################### */

#include "me_syslog.h"

#include "kernel/base/me_main_system.h"
#include "kernel/base/me_string_utility.h"


#define ME_SYSLOG_OUTPUT_POLLING_IVAL		(10)

#define ME_SYSLOG_TCP_CLIENT_CLOSE_DELAY	(2000)


static const me_uint8_t me_syslog_utf8_bom[] = { 0xEF, 0xBB, 0xBF };


static void me_syslog_record_delete(struct me_syslog_record *record)
{
	if (record != NULL) {
		me_string_finalize(&record->msg);
		me_free(record);
	}
}

static struct me_syslog_record *me_syslog_record_new(enum me_syslog_facility fac, enum me_syslog_severity sev, const me_char_t *format, va_list args)
{
	struct me_syslog_record *record = NULL;
	me_bool_t success = ME_FALSE;

	record = (struct me_syslog_record *)me_calloc(sizeof(*record));
	if (record != NULL) {
		record->fac = fac;
		record->sev = sev;

		if (me_datetime_now_utc(&record->dt_utc)) {
			if (me_string_initialize_heap(&record->msg)) {
				me_string_append_vformat(&record->msg, format, args);
				success = ME_TRUE;
			}
		}
	}

	if (!success) {
		me_syslog_record_delete(record);
		record = NULL;
	}

	return (record);
}

static me_bool_t me_syslog_record_enqueue(me_syslog_t *obj, struct me_syslog_record *record)
{
	me_bool_t success = ME_TRUE;

	if (record != NULL) {
		me_mutex_lock(&obj->output_mutex);
		{
			record->prev = obj->record_top.prev;
			record->next = &obj->record_top;
			obj->record_top.prev->next = record;
			obj->record_top.prev = record;
		}
		me_mutex_unlock(&obj->output_mutex);

		success = ME_TRUE;
	}

	return (success);
}

static struct me_syslog_record *me_syslog_record_dequeue(me_syslog_t *obj)
{
	struct me_syslog_record *record = NULL;

	if (obj->record_top.next != &obj->record_top) {
		me_mutex_lock(&obj->output_mutex);
		{
			record = obj->record_top.next;
			obj->record_top.next = obj->record_top.next->next;
			obj->record_top.next->prev = &obj->record_top;
		}
		me_mutex_unlock(&obj->output_mutex);
	}

	return (record);
}

static void me_syslog_file_output(me_syslog_t *obj, const me_uint8_t *data, me_uint16_t size)
{
	me_file_t file;

	if (me_file_open(&file, me_path_c_str(&obj->profile.file.output_path), ME_FILE_READWRITE_ADD)) {
		me_file_write(&file, data, size);
		me_file_close(&file);
	}
}

#if 0
static void me_syslog_tcp_client_output(me_syslog_t *obj, const me_uint8_t *data, me_uint16_t size)
{
	if (obj->tcp_client.obj == NULL) {
		IC_TRAP_PTR_ERROR(obj->tcp_client.obj = me_tcp_client_new(&obj->profile.tcp_client.remote));
	}

	if (obj->tcp_client.obj != NULL) {
		me_tcp_client_send(obj->tcp_client.obj, data, size);
		obj->tcp_client.last_send_time = me_clock_time_msec();
	}
}
#endif

#if 0
static void me_syslog_tcp_client_poll(me_syslog_t *obj)
{
	if (obj->tcp_client.obj != NULL) {
		if (   (!me_tcp_client_send_is_busy(obj->tcp_client.obj))
			&& (me_clock_elapsed_msec(obj->tcp_client.last_send_time) >= IC_SYSLOG_TCP_CLOSE_DELAY)
		) {
			/* 送信が完了していれば閉じる */
			me_tcp_client_delete(obj->tcp_client.obj);
			obj->tcp_client.obj = NULL;
		}
	}
}
#endif

static void me_syslog_setup_header(me_syslog_t *obj, me_string_t *str, const struct me_syslog_record *record)
{
#if 0
	/* RFC 3164 */
	/* <Code> Jan  1 00:00:00 app_name: 2016-01-01T00:00:00.000 MSG */
	me_string_append_format(
		str,
		"<%d> %s %2d %02d:%02d:%02d %s: %02d-%02d-%02dT%02d:%02d:%02d.%03d ",
		(me_uint16_t)fac * 8 + (me_uint16_t)sev,
		me_syslog_month_code[dt.month], dt.day, dt.hour, dt.min, dt.sec,
		IC_SPEC_OBJECT_NAME,
		dt.year, dt.month, dt.day, dt.hour, dt.min, dt.sec, dt.msec);
#else
	/* RFC 5424 (https://tools.ietf.org/html/rfc5424) */
	/* <PRI>VERSION TIMESTAMP HOSTNAME APP-NAME - MSGID - MSG */
	/* <PRI>1 2016-01-23T01:23:45.678Z ICOM nx-3761-app-main - NX-3761 - BOMmessage */
	me_string_append_format(
		str,
		"<%d>1 %04d-%02d-%02dT%02d:%02d:%02d.%03dZ %s %s - %s - ",
		(me_uint16_t)record->fac * 8 + (me_uint16_t)record->sev,
		record->dt_utc.year, record->dt_utc.month, record->dt_utc.day, record->dt_utc.hour, record->dt_utc.min, record->dt_utc.sec, record->dt_utc.msec,
		ME_SYSLOG_HOST_NAME,
		ME_SYSLOG_APP_NAME,
		ME_SYSLOG_MSGID);

	me_string_append_text(str, (me_char_t *)me_syslog_utf8_bom, ME_COUNTOF(me_syslog_utf8_bom));

#endif
}

static void me_syslog_setup_footer(me_syslog_t *obj, me_string_t *str, const struct me_syslog_record *record)
{
	me_string_append_char(str, '\n');
}

static void me_syslog_setup(me_syslog_t *obj, me_string_t *str, const struct me_syslog_record *record)
{
	me_syslog_setup_header(obj, str, record);

	me_string_append(str, &record->msg);

	me_syslog_setup_footer(obj, str, record);
}

static void me_syslog_output(me_syslog_t *obj, const me_string_t *str)
{
	/* 標準出力 */
	if ((obj->profile.target_flags & MeSyslogTarget_Stdout) != 0) {
		me_stdout((const me_uint8_t *)me_string_c_str(str), me_string_length(str));
	}

	/* 標準エラー出力 */
	if ((obj->profile.target_flags & MeSyslogTarget_Stderr) != 0) {
		me_stderr((const me_uint8_t *)me_string_c_str(str), me_string_length(str));
	}

	/* ファイル出力 */
	if ((obj->profile.target_flags & MeSyslogTarget_File) != 0) {
		me_syslog_file_output(obj, (me_uint8_t *)me_string_c_str(str), me_string_length(str));
	}

#if 0
	/* UDP Client出力 */
	if ((obj->profile.target_flags & MeSyslogTarget_UdpClient) != 0) {
		/* 最後のNUL文字まで出力 */
		me_udp_client_send(obj->udp_client.obj, (me_uint8_t *)me_string_c_str(str), me_string_length(str) + 1, &obj->profile.udp_client.remote);
	}

	/* TCP Client出力 */
	if ((obj->profile.target_flags & MeSyslogTarget_TcpClient) != 0) {
		/* 最後のNUL文字まで出力 */
		me_syslog_tcp_client_output(obj, (me_uint8_t *)me_string_c_str(str), me_string_length(str) + 1);
	}
#endif
}

static void me_syslog_thread(me_thread_t *obj, void *param)
{
	me_syslog_t *									syslog = (me_syslog_t *)param;
	struct me_syslog_record *						record;
	me_static_string_t(ME_SYSLOG_RECORD_LENGTH_MAX)	output_str;

	me_static_string_initialize(&output_str);

	/* 出力するログが無くなるまでループを続ける */
	while ((!syslog->exit_req) || (syslog->record_top.next != &syslog->record_top)) {

		/* 溜まっているログを全て出力する */
		while ((record = me_syslog_record_dequeue(syslog)) != NULL) {

			/* 指定優先度以上のログのみを出力する */
			if (record->sev <= syslog->profile.enable_severity_level) {
				me_syslog_setup(syslog, me_static_string_to_basic(&output_str), record);
				me_syslog_output(syslog, me_static_string_to_basic(&output_str));
			}

			me_syslog_record_delete(record);
		}

		me_thread_sleep_ms(10);
	}

	me_string_finalize(me_static_string_to_basic(&output_str));
}

me_bool_t me_syslog_initialize(me_syslog_t *obj, const struct me_syslog_profile *profile)
{
	me_bool_t success = ME_FALSE;

	if ((obj != NULL) && (profile != NULL)) {
		obj->guard_code = obj;

		obj->profile = *profile;

		obj->record_top.prev = &obj->record_top;
		obj->record_top.next = &obj->record_top;

#if 0
		/* UDP Client Setup */
		if (me_has_flag(obj->profile.target, SyslogTargetFlag_UdpClient)) {
			IC_EVENT_OUT_MESSAGE("Syslog UDP Enable");
			IC_TRAP_PTR_ERROR_SET(obj->udp_client.obj = me_udp_client_new(IC_IPDOMAIN_TYPE_IPV4, NULL), error);
		}

		/* TCP Client Setup */
		if (me_has_flag(obj->profile.target, SyslogTargetFlag_TcpClient)) {
			IC_EVENT_OUT_MESSAGE("Syslog TCP Enable");
		}
#endif

		obj->exit_req = ME_FALSE;

		if (   (me_mutex_initialize(&obj->output_mutex))
			&& (me_thread_initialize(&obj->output_thread, me_syslog_thread, obj))
		) {
			success = ME_TRUE;
		}
	}

	/* === エラー処理 === */
	if (!success) {
		me_syslog_finalize(obj);
	}

	return (success);
}

void me_syslog_finalize(me_syslog_t *obj)
{
	if ((obj != NULL) && (obj->guard_code == obj)) {
		obj->exit_req = ME_TRUE;
		while (me_thread_is_active(&obj->output_thread)) {}

		me_thread_finalize(&obj->output_thread);
		me_mutex_finalize(&obj->output_mutex);

#if 0
		me_udp_client_delete(obj->udp_client.obj);
		me_tcp_client_delete(obj->tcp_client.obj);
#endif

		obj->guard_code = NULL;
	}
}

void me_syslog_poll(me_syslog_t *obj)
{
	if ((obj != NULL) && (obj->guard_code == obj)) {
#if 0
		me_syslog_tcp_client_poll(obj);
#endif
	}
}

void me_syslog_output_format(me_syslog_t *obj, enum me_syslog_facility fac, enum me_syslog_severity sev, const me_char_t *format, ... )
{
	if ((obj != NULL) && (obj->guard_code == obj)) {
		va_list args = {0};

		/* 可変引数初期化 */
		va_start(args, format);

		/* 処理開始 */
		me_syslog_output_vformat(obj, fac, sev, format, args);

		/* 可変引数終了 */
		va_end(args);
	}
}

void me_syslog_output_vformat(me_syslog_t *obj, enum me_syslog_facility fac, enum me_syslog_severity sev, const me_char_t *format, va_list args)
{
	if ((obj != NULL) && (obj->guard_code == obj)) {
		struct me_syslog_record *record;

		record = me_syslog_record_new(fac, sev, format, args);
		if (record != NULL) {
			if (!me_syslog_record_enqueue(obj, record)) {
				me_syslog_record_delete(record);
			}
		}
	}
}

/* ####### File End ###### */
/** @} */

/* ###################################################################### *//**
 *
 *	@addtogroup	Base
 *	@{
 *	@file		ic_syslog.c
 *	@brief		Syslog
 *	@author		Copyright (C) 2019 Hitoshi Kouno
 *
*//* ####################################################################### */

#include "me_syslog.h"

#include "kernel/base/me_main_system.h"
#include "kernel/base/me_datetime.h"
#include "kernel/base/me_string.h"
#include "kernel/base/me_string_utility.h"


#define ME_SYSLOG_OUTPUT_POLLING_IVAL			(10)
#define ME_SYSLOG_OUTPUT_TIMEOUT				(3000)

#define ME_SYSLOG_TCP_CLIENT_CLOSE_DELAY		(2000)


static const me_char_t me_syslog_utf8_bom[] = { 0xEF, 0xBB, 0xBF };


static me_achar_t *me_syslog_build_data(me_size_t *build_data_size, me_syslog_t *obj, const me_datetime_t *dt, enum me_syslog_facility fac, enum me_syslog_severity sev, const me_char_t *format, va_list args)
{
	me_achar_t *	str_a = NULL;
	me_size_t		str_a_len = 0;
	me_string_t		str;

	if (me_string_initialize_heap(&str)) {

#if 0
		/* RFC 3164 */
		/* <Code> Jan  1 00:00:00 app_name: 2016-01-01T00:00:00.000 MSG */

		/* Header */
		me_string_append_format(
			&str,
			ME_TEXT("<%d> %s %2d %02d:%02d:%02d %s: %02d-%02d-%02dT%02d:%02d:%02d.%03d "),
			(me_uint16_t)fac * 8 + (me_uint16_t)sev,
			me_syslog_month_code[dt.month], dt.day, dt.hour, dt.min, dt.sec,
			IC_SPEC_OBJECT_NAME,
			dt.year, dt.month, dt.day, dt.hour, dt.min, dt.sec, dt.msec);

		/* Message */
		me_string_append_vformat(str, format, args);

#else
		/* RFC 5424 (https://tools.ietf.org/html/rfc5424) */
		/* <PRI>VERSION TIMESTAMP HOSTNAME APP-NAME - MSGID - MSG */
		/* <PRI>1 2016-01-23T01:23:45.678Z HOSTNAME APP-NAME - MSGID - BOMmessage */

		/* Header */
		me_string_append_format(
			&str,
			ME_TEXT("<%d>1 %04d-%02d-%02dT%02d:%02d:%02d.%03dZ %s %s - %s - "),
			(me_uint16_t)fac * 8 + (me_uint16_t)sev,
			dt->year, dt->month, dt->day, dt->hour, dt->min, dt->sec, dt->msec,
			ME_SYSLOG_HOST_NAME,
			ME_SYSLOG_APP_NAME,
			ME_SYSLOG_MSGID);

		/* BOM */
		me_string_append_text(&str, (me_char_t *)me_syslog_utf8_bom, ME_COUNTOF(me_syslog_utf8_bom));

		/* Message */
		me_string_append_vformat(&str, format, args);

#endif
		/* Line Feed */
		me_string_append_char(&str, ME_TEXT('\n'));

		/* マルチバイト型に変換 */
		str_a_len = me_strctoanlen(me_string_c_str(&str), ME_SYSLOG_RECORD_LENGTH_MAX + 1);
		str_a = me_malloc(sizeof(me_achar_t) * (str_a_len + 1));
		if (str_a != NULL) {
			me_strctoan(str_a, me_string_c_str(&str), ME_SYSLOG_RECORD_LENGTH_MAX + 1);
			str_a[str_a_len] = '\0';
			*build_data_size = str_a_len;
		}

		me_string_finalize(&str);
	}

	return (str_a);
}

static void me_syslog_record_delete(struct me_syslog_record *record)
{
	if (record != NULL) {
		me_free(record->output_data);
		me_free(record);
	}
}

static struct me_syslog_record *me_syslog_record_new(me_syslog_t *obj, enum me_syslog_facility fac, enum me_syslog_severity sev, const me_char_t *format, va_list args)
{
	struct me_syslog_record *record = NULL;
	me_bool_t success = ME_FALSE;

	record = (struct me_syslog_record *)me_calloc(sizeof(*record));
	if (record != NULL) {
		me_datetime_t dt_utc;

		if (me_datetime_now_utc(&dt_utc)) {
			record->output_data = me_syslog_build_data(&record->output_data_size, obj, &dt_utc, fac, sev, format, args);

			if (record->output_data != NULL) {
				success = ME_TRUE;
			}
		}
	}

	if (!success) {
		me_syslog_record_delete(record);
		record = NULL;
	}

	return (record);
}

static me_bool_t me_syslog_record_enqueue(me_syslog_t *obj, struct me_syslog_record *record)
{
	me_bool_t success = ME_FALSE;

	if (   (record != NULL)
		&& (obj->record_queue_count < ME_SYSLOG_OUTPUT_QUEUE_MAX)
	) {
		record->next = NULL;

		me_mutex_lock(&obj->record_queue_mtx);
		{
			if (obj->record_queue_count < ME_SYSLOG_OUTPUT_QUEUE_MAX) {
				if (obj->record_queue_first == NULL) {
					obj->record_queue_first = record;
					obj->record_queue_last = record;
				} else {
					obj->record_queue_last->next = record;
				}

				obj->record_queue_count++;
			}
		}
		me_mutex_unlock(&obj->record_queue_mtx);

		success = ME_TRUE;
	}

	return (success);
}

static struct me_syslog_record *me_syslog_record_dequeue(me_syslog_t *obj)
{
	struct me_syslog_record *record = NULL;

	if (obj->record_queue_count > 0) {
		me_mutex_lock(&obj->record_queue_mtx);
		{
			if (obj->record_queue_count > 0) {
				record = obj->record_queue_first;

				obj->record_queue_first = obj->record_queue_first->next;

				obj->record_queue_count--;
			}
		}
		me_mutex_unlock(&obj->record_queue_mtx);
	}

	return (record);
}

static me_bool_t me_syslog_file_output(me_syslog_t *obj, const me_uint8_t *data, me_uint16_t size)
{
	me_bool_t success = ME_FALSE;
	me_file_t file;

	if (me_file_open(&file, me_path_c_str(&obj->profile.file.output_path), ME_FILE_READWRITE_ADD)) {
		me_file_write(&file, data, size);
		me_file_close(&file);
		success = ME_TRUE;
	}

	return (success);
}

#if 0
static void me_syslog_tcp_client_output(me_syslog_t *obj, const me_uint8_t *data, me_uint16_t size)
{
	if (obj->tcp_client.obj == NULL) {
		IC_TRAP_PTR_ERROR(obj->tcp_client.obj = me_tcp_client_new(&obj->profile.tcp_client.remote));
	}

	if (obj->tcp_client.obj != NULL) {
		me_tcp_client_send(obj->tcp_client.obj, data, size);
		obj->tcp_client.last_send_time = me_clock_time_msec();
	}
}
#endif

#if 0
static void me_syslog_tcp_client_poll(me_syslog_t *obj)
{
	if (obj->tcp_client.obj != NULL) {
		if (   (!me_tcp_client_send_is_busy(obj->tcp_client.obj))
			&& (me_clock_elapsed_msec(obj->tcp_client.last_send_time) >= IC_SYSLOG_TCP_CLOSE_DELAY)
		) {
			/* 送信が完了していれば閉じる */
			me_tcp_client_delete(obj->tcp_client.obj);
			obj->tcp_client.obj = NULL;
		}
	}
}
#endif

static void me_syslog_output(me_syslog_t *obj, struct me_syslog_record *record)
{
	/* 標準出力 */
	if (((obj->profile.target_flags ^ obj->output_complete_flags) & MeSyslogTarget_Stdout) != 0) {
		me_stdout((const me_uint8_t *)record->output_data, record->output_data_size);
		obj->output_complete_flags |= MeSyslogTarget_Stdout;
	}

	/* 標準エラー出力 */
	if ((obj->profile.target_flags & MeSyslogTarget_Stderr) != 0) {
		me_stderr((const me_uint8_t *)record->output_data, record->output_data_size);
		obj->output_complete_flags |= MeSyslogTarget_Stderr;
	}

	/* ファイル出力 */
	if ((obj->profile.target_flags & MeSyslogTarget_File) != 0) {
		if (me_syslog_file_output(obj, (const me_uint8_t *)record->output_data, record->output_data_size)) {
			obj->output_complete_flags |= MeSyslogTarget_File;
		}
	}

#if 0
	/* UDP Client出力 */
	if ((obj->profile.target_flags & MeSyslogTarget_UdpClient) != 0) {
		/* 最後のNUL文字まで出力 */
		me_udp_client_send(obj->udp_client.obj, (me_uint8_t *)me_string_c_str(str), me_string_length(str) + 1, &obj->profile.udp_client.remote);
	}

	/* TCP Client出力 */
	if ((obj->profile.target_flags & MeSyslogTarget_TcpClient) != 0) {
		/* 最後のNUL文字まで出力 */
		me_syslog_tcp_client_output(obj, (me_uint8_t *)me_string_c_str(str), me_string_length(str) + 1);
	}
#endif
}

static void me_syslog_output_task(me_syslog_t *obj)
{
	/* 新しい出力レコードを取得 */
	if (obj->record_busy == NULL) {
		obj->record_busy = me_syslog_record_dequeue(obj);
		if (obj->record_busy != NULL) {
			obj->output_start_tick = me_system_tick_msec_get();
			obj->output_complete_flags = 0;
		}
	}

	/* レコード出力 */
	if (obj->record_busy != NULL) {
		if (me_system_tick_msec_elapsed(obj->output_start_tick) < ME_SYSLOG_OUTPUT_TIMEOUT) {
			me_syslog_output(obj, obj->record_busy);
		} else {
			/* タイムアウト */
			obj->output_complete_flags = obj->profile.target_flags;
		}

		/* 完了チェック */
		if ((obj->output_complete_flags & obj->profile.target_flags) == obj->profile.target_flags) {
			me_syslog_record_delete(obj->record_busy);
			obj->record_busy = NULL;
		}
	}
}

me_bool_t me_syslog_initialize(me_syslog_t *obj, const struct me_syslog_profile *profile)
{
	me_bool_t success = ME_FALSE;

	if ((obj != NULL) && (profile != NULL)) {
		obj->guard_code = obj;

		obj->profile = *profile;

		obj->record_queue_first = NULL;
		obj->record_queue_last = NULL;
		obj->record_queue_count = 0;

		obj->record_busy = NULL;

#if 0
		/* UDP Client Setup */
		if (me_has_flag(obj->profile.target, SyslogTargetFlag_UdpClient)) {
			IC_EVENT_OUT_MESSAGE("Syslog UDP Enable");
			IC_TRAP_PTR_ERROR_SET(obj->udp_client.obj = me_udp_client_new(IC_IPDOMAIN_TYPE_IPV4, NULL), error);
		}

		/* TCP Client Setup */
		if (me_has_flag(obj->profile.target, SyslogTargetFlag_TcpClient)) {
			IC_EVENT_OUT_MESSAGE("Syslog TCP Enable");
		}
#endif

		if (me_mutex_create(&obj->record_queue_mtx)) {
			success = ME_TRUE;
		}
	}

	/* === エラー処理 === */
	if (!success) {
		me_syslog_finalize(obj);
	}

	return (success);
}

void me_syslog_finalize(me_syslog_t *obj)
{
	if ((obj != NULL) && (obj->guard_code == obj)) {

#if 0
		me_udp_client_delete(obj->udp_client.obj);
		me_tcp_client_delete(obj->tcp_client.obj);
#endif

		obj->guard_code = NULL;
	}
}

void me_syslog_poll(me_syslog_t *obj)
{
	if ((obj != NULL) && (obj->guard_code == obj)) {
		me_syslog_output_task(obj);
	}
}

me_bool_t me_syslog_is_busy(me_syslog_t *obj)
{
	me_bool_t busy = ME_FALSE;

	if (obj != NULL) {
		if (obj->record_queue_first != NULL) {
			busy = ME_TRUE;
		}
	}

	return (busy);
}

void me_syslog_output_format(me_syslog_t *obj, enum me_syslog_facility fac, enum me_syslog_severity sev, const me_char_t *format, ... )
{
	if ((obj != NULL) && (obj->guard_code == obj)) {
		va_list args = {0};

		/* 可変引数初期化 */
		va_start(args, format);

		/* 処理開始 */
		me_syslog_output_vformat(obj, fac, sev, format, args);

		/* 可変引数終了 */
		va_end(args);
	}
}

void me_syslog_output_vformat(me_syslog_t *obj, enum me_syslog_facility fac, enum me_syslog_severity sev, const me_char_t *format, va_list args)
{
	if ((obj != NULL) && (obj->guard_code == obj)) {
		/* 指定優先度以上のログのみ出力する */
		if (sev <= obj->profile.enable_severity_level) {
			struct me_syslog_record *record;

			record = me_syslog_record_new(obj, fac, sev, format, args);
			if (record != NULL) {
				if (!me_syslog_record_enqueue(obj, record)) {
					me_syslog_record_delete(record);
				}
			}
		}
	}
}

/* ####### File End ###### */
/** @} */

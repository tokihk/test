/* ###################################################################### *//**
 *
 *	@addtogroup	Kernel
 *	@{
 *	@file		me_syslog.h
 *	@brief		Syslog Module
 *	@author		Copyright (C) 2019 Hitoshi Kouno
 *
*//* ####################################################################### */
#ifndef ME_SYSLOG_H_
#define ME_SYSLOG_H_

#include "kernel/me_kernel.h"

#include "kernel/base/me_thread.h"
#include "kernel/base/me_mutex.h"
#include "kernel/base/me_string.h"
#include "kernel/base/me_datetime.h"

#include "kernel/fs/me_path.h"
#include "kernel/fs/me_file.h"


#define ME_SYSLOG_RECORD_LENGTH_MAX			(ME_SYSLOG_MESSAGE_LENGTH_MAX + 150)


enum me_syslog_target
{
	MeSyslogTarget_Stdout			= 1 << 0,
	MeSyslogTarget_Stderr			= 1 << 1,
	MeSyslogTarget_File				= 1 << 2,
	MeSyslogTarget_UdpClient		= 1 << 3,
	MeSyslogTarget_TcpClient		= 1 << 4,
};


enum me_syslog_facility
{
	MeSyslogFacility_Kernel			= 0,
	MeSyslogFacility_User			= 1,
	MeSyslogFacility_Mail			= 2,
	MeSyslogFacility_Daemon			= 3,
	MeSyslogFacility_Auth0			= 4,
	MeSyslogFacility_Syslogd		= 5,
	MeSyslogFacility_LinePrinter	= 6,
	MeSyslogFacility_News			= 7,
	MeSyslogFacility_UUCP			= 8,
	MeSyslogFacility_ClockDaemon0	= 9,
	MeSyslogFacility_Auth1			= 10,
	MeSyslogFacility_FTP			= 11,
	MeSyslogFacility_NTP			= 12,
	MeSyslogFacility_LogAudit		= 13,
	MeSyslogFacility_LogAlert		= 14,
	MeSyslogFacility_ClockDaemon1	= 15,
	MeSyslogFacility_Local0			= 16,
	MeSyslogFacility_Local1			= 17,
	MeSyslogFacility_Local2			= 18,
	MeSyslogFacility_Local3			= 19,
	MeSyslogFacility_Local4			= 20,
	MeSyslogFacility_Local5			= 21,
	MeSyslogFacility_Local6			= 22,
	MeSyslogFacility_Local7			= 23,
};

enum me_syslog_severity
{
	MeSyslogSeverity_Emergency		= 0,
	MeSyslogSeverity_Alert			= 1,
	MeSyslogSeverity_Critical		= 2,
	MeSyslogSeverity_Error			= 3,
	MeSyslogSeverity_Warning		= 4,
	MeSyslogSeverity_Notice			= 5,
	MeSyslogSeverity_Information	= 6,
	MeSyslogSeverity_Debug			= 7,
};

struct me_syslog_record
{
	struct me_syslog_record *		prev;
	struct me_syslog_record *		next;

	me_datetime_t					dt_utc;
	enum me_syslog_facility			fac;
	enum me_syslog_severity			sev;
	me_string_t						msg;
};

struct me_syslog_profile_file
{
	me_path_t						output_path;
};

#if 0
struct me_syslog_profile_udp_client
{
	struct me_net_endpoint			remote_ep;
};

struct me_syslog_profile_tcp_client
{
	struct me_net_endpoint			server_ep;
};
#endif

struct me_syslog_profile
{
	enum me_syslog_target					target_flags;
	enum me_syslog_severity					enable_severity_level;

	struct me_syslog_profile_file			file;
//	struct me_syslog_profile_udp_client		udp_client;
//	struct me_syslog_profile_tcp_client		tcp_client;
};

typedef struct me_syslog {
	struct me_syslog_profile					profile;
	struct me_syslog_record						record_top;
	me_thread_t									output_thread;
	me_mutex_t									output_mutex;
	me_bool_t									exit_req;

	struct {
		me_file_t *							obj;
	} file;

#if 0
	struct {
		me_udp_client_t *					obj;
	} udp_client;

	struct {
		me_tcp_client_t *					obj;
		me_uint32_t							last_send_time;
	} tcp_client;
#endif

	void *									guard_code;
} me_syslog_t;


me_bool_t				me_syslog_initialize(me_syslog_t *obj, const struct me_syslog_profile *profile);
void					me_syslog_finalize(me_syslog_t *obj);
void					me_syslog_poll(me_syslog_t *obj);

void					me_syslog_output_format(me_syslog_t *obj, enum me_syslog_facility fac, enum me_syslog_severity sev, const me_char_t *format, ... );
void					me_syslog_output_vformat(me_syslog_t *obj, enum me_syslog_facility fac, enum me_syslog_severity sev, const me_char_t *format, va_list args);

#endif /* ME_SYSLOG_H_ */
/* ####### File End ###### */
/** @} */


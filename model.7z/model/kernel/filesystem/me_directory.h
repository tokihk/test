#ifndef ME_DIRECTORY_H_
#define ME_DIRECTORY_H_

#include "kernel/filesystem/me_directory_stddef.h"

#include "kernel/filesystem/me_path.h"


me_bool_t				me_chdir(const me_char_t *dir_path);
me_bool_t				me_getwd(struct me_path *dir_path);

me_bool_t				me_mkdir(const me_char_t *dir_path);
void					me_rmdir(const me_char_t *dir_path);

me_bool_t				me_is_dir(const me_char_t *dir_path);


#endif

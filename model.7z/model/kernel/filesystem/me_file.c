/* ###################################################################### *//**
 *
 *	@addtogroup	FileSystem
 *	@{
 *	@file		ic_file.c
 *	@brief
 *	@author		Copyright (C) 2019 Hitoshi Kouno
 *
*//* ####################################################################### */

#include "me_file.h"
#include "me_path.h"

#include "kernel/core/me_string.h"


me_bool_t me_current_dir_set(const me_char_t *dir_path)
{
	me_bool_t set_ok = ME_FALSE;

	if (dir_path != NULL) {
		me_current_dir_set_arch(dir_path);
	}

	return (set_ok);
}

me_bool_t me_current_dir_get(me_char_t *buffer, me_size_t buffer_size)
{
	me_bool_t get_ok = ME_FALSE;

	if ((buffer != NULL) && (buffer_size > 0)) {
		get_ok = me_current_dir_get_arch(buffer, buffer_size);
	}

	return (get_ok);
}

me_bool_t me_make_directory(const me_char_t *dir_path)
{
	me_bool_t make_ok = ME_FALSE;

	if (dir_path != NULL) {
		make_ok = me_make_directory_arch(dir_path);
	}

	return (make_ok);
}

void me_remove_directory(const me_char_t *dir_path)
{
	if (dir_path != NULL) {
		me_remove_directory_arch(dir_path);
	}
}

void me_remove_file(const me_char_t *file_path)
{
	if (file_path != NULL) {
		me_remove_file_arch(file_path);
	}
}

me_bool_t me_is_file_exist(const me_char_t *file_path)
{
	me_bool_t exist = ME_FALSE;

	if (file_path != NULL) {
		exist = me_is_file_exist_arch(file_path);
	}

	return (exist);
}

me_bool_t me_is_dir_exist(const me_char_t *dir_path)
{
	me_bool_t exist = ME_FALSE;

	if (dir_path != NULL) {
		exist = me_is_dir_exist_arch(dir_path);
	}

	return (exist);
}

me_bool_t me_file_open(me_file_t *obj, const me_char_t *file_path, enum me_file_mode mode)
{
	me_bool_t open_ok = ME_FALSE;

	if ((obj != NULL) && (file_path != NULL)) {
		if (   (mode == ME_FILE_READWRITE_NEW)
			|| (mode == ME_FILE_READWRITE_ADD)
		) {
			me_path_t path;

			me_path_parent_directory_get(&path, file_path);

			me_make_directory(me_path_c_str(&path));
		}

		open_ok = me_file_open_arch(&obj->base, file_path, mode);
	}

	return (open_ok);
}

void me_file_close(me_file_t *obj)
{
	if (obj != NULL) {
		me_file_close_arch(&obj->base);
	}
}

me_size_t me_file_read(me_file_t *obj, me_uint8_t *buffer, me_size_t buffer_size)
{
	me_size_t read_size = 0;

	if (obj != NULL) {
		read_size = me_file_read_arch(&obj->base, buffer, buffer_size);
	}

	return (read_size);
}

me_size_t me_file_write(me_file_t *obj, const me_uint8_t *data, me_uint16_t size)
{
	me_size_t write_size = 0;

	if (obj != NULL) {
		write_size = me_file_write_arch(&obj->base, data, size);
	}

	return (write_size);
}

me_size_t me_file_write_format(me_file_t *obj, const me_char_t *format, ... )
{
	me_size_t write_size = 0;

	if ((obj != NULL) && (format != NULL)) {
		va_list args = {0};

		/* 可変引数初期化 */
		va_start(args, format);

		/* 処理開始 */
		write_size = me_file_write_vformat(obj, format, args);

		/* 可変引数終了 */
		va_end(args);
	}

	return (write_size);
}

me_size_t me_file_write_vformat(me_file_t *obj, const me_char_t *format, va_list args)
{
	me_size_t write_size = 0;

	if ((obj != NULL) && (format != NULL)) {
		me_string_t str_temp;

		if (me_string_initialize_heap(&str_temp)) {
			if (me_string_append_vformat(&str_temp, format, args)) {
				write_size = me_file_write(obj, (const me_uint8_t *)me_string_c_str(&str_temp), me_string_length(&str_temp));
			}

			me_string_finalize(&str_temp);
		}
	}

	return (write_size);
}


/* ####### File End ###### */
/** @} */

#ifndef ME_FILE_H_
#define ME_FILE_H_

#include "kernel/me_kernel.h"

#include "kernel/filesystem/me_file_arch.h"

#include <stdarg.h>


void					me_unlink(const me_char_t *file_path);

me_bool_t				me_is_file(const me_char_t *file_path);

me_bool_t				me_file_open(me_file_t *obj, const me_char_t *file_path, enum me_file_mode mode);

void					me_file_close(me_file_t *obj);

me_size_t				me_file_read(me_file_t *obj, me_uint8_t *buffer, me_size_t buffer_size);

me_size_t				me_file_write(me_file_t *obj, const me_uint8_t *data, me_uint16_t size);

me_size_t				me_file_write_format(me_file_t *obj, const me_char_t *format, ... );
me_size_t				me_file_write_vformat(me_file_t *obj, const me_char_t *format, va_list args);


#endif

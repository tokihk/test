#include "me_filesystem.h"


me_bool_t me_fs_open(struct me_file *file, const me_char_t *path, me_uint8_t mode)
{
	me_bool_t open_ok = ME_FALSE;

	if (   (file != NULL)
		&& (path != NULL)
	) {
		open_ok = me_fs_open_arch(&file->base, path, mode);
	}

	return (open_ok);
}

me_bool_t me_fs_close(struct me_file *file)
{
	me_bool_t close_ok = ME_FALSE;

	if (file != NULL) {
		close_ok = me_fs_close_arch(&file->base);
	}

	return (close_ok);

}

me_bool_t me_fs_read(struct me_file *file, void *buff, me_size_t read_size, me_size_t *result)
{
	me_bool_t read_ok = ME_FALSE;

	if ((file != NULL) && (buff != NULL) && (read_size > 0) && (result != NULL)) {
		read_ok = me_fs_read_arch(&file->base, buff, read_size, result);
	}

	return (read_ok);
}

me_bool_t me_fs_write(struct me_file *file, const void *data, me_size_t write_size, me_size_t *result)
{
	me_bool_t write_ok = ME_FALSE;

	if ((file != NULL) && (data != NULL) && (write_size > 0) && (result != NULL)) {
		read_ok = me_fs_write_arch(&file->base, data, write_size, result);
	}

	return (write_ok);
}

me_size_t me_fs_write_format(struct me_file *file, const me_char_t *format, ... )
{
	me_size_t write_size = 0;

	if ((file != NULL) && (format != NULL)) {
		va_list args = {0};

		/* 可変引数初期化 */
		va_start(args, format);

		/* 処理開始 */
		write_size = me_fs_write_vformat(file, format, args);

		/* 可変引数終了 */
		va_end(args);
	}

	return (write_size);
}

me_size_t me_fs_write_vformat(struct me_file *file, const me_char_t *format, va_list args)
{
	me_size_t write_size = 0;

	if ((file != NULL) && (format != NULL)) {
		write_size = me_fs_write_vformat_arch(&file->base, format, args);
	}

	return (write_size);
}

me_bool_t me_fs_lseek(struct me_file *file, me_size_t ofs)
{
	me_bool_t seek_ok = ME_FALSE;

	if (file != NULL) {
		seek_ok = me_fs_lseek_arch(&file->base, ofs);
	}

	return (seek_ok);
}

me_bool_t me_fs_opendir(struct me_directory *dir, const me_char_t *path)
{
	me_bool_t open_ok = ME_FALSE;

	if ((dir != NULL) && (path != NULL)) {
		open_ok = me_fs_opendir_arch(&dir->base, path);
	}

	return (open_ok);
}

me_bool_t me_fs_closedir(struct me_directory *dir)
{
	me_bool_t close_ok = ME_FALSE;

	if (dir != NULL) {
		close_ok = me_fs_closedir_arch(&dir->base);
	}

	return (close_ok);
}

me_bool_t me_fs_readdir(struct me_directory *dir, struct me_file_info *info)
{
	me_bool_t read_ok = ME_FALSE;

	if ((dir != NULL) && (info != NULL)) {
		read_ok = me_fs_readdir_arch(&dir->base, info);
	}

	return (read_ok);
}

me_bool_t me_fs_mkdir(const me_char_t *path)
{
	me_bool_t make_ok = ME_FALSE;

	if (path != NULL) {
		make_ok = me_fs_mkdir_arch(path);
	}

	return (make_ok);
}

me_bool_t me_fs_unlink(const me_char_t *path)
{
	me_bool_t unlink_ok = ME_FALSE;

	if (path != NULL) {
		unlink_ok = me_fs_unlink_arch(path);
	}

	return (unlink_ok);
}

me_bool_t me_fs_rename(const me_char_t *path_old, const me_char_t *path_new)
{
	me_bool_t rename_ok = ME_FALSE;

	if ((path_old != NULL) && (path_new != NULL)) {
		rename_ok = me_fs_rename_arch(path_old, path_new);
	}

	return (rename_ok);
}

me_bool_t me_fs_stat(const me_char_t *path, struct me_file_info *info)
{
	me_bool_t get_ok = ME_FALSE;

	if ((path != NULL) && (info != NULL)) {
		get_ok = me_fs_stat_arch(path, info);
	}

	return (get_ok);
}

me_bool_t me_fs_chdir(const me_char_t *path)
{
	me_bool_t change_ok = ME_FALSE;

	if (path != NULL) {
		change_ok = me_fs_chdir_arch(path);
	}

	return (change_ok);
}

me_bool_t me_fs_getcwd(struct me_path *path)
{
	me_bool_t get_ok = ME_FALSE;

	if (path != NULL) {
		get_ok = me_fs_getcwd_arch(path);
	}

	return (get_ok);
}

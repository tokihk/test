#ifndef ME_FILESYSTEM_H_
#define ME_FILESYSTEM_H_

#include "kernel/filesystem/me_filesystem_stddef.h"

#include "kernel/filesystem/me_filesystem_arch.h"

#include "kernel/filesystem/me_path.h"

#include <stdarg.h>


struct me_file
{
	struct me_file_arch				base;
};

struct me_directory
{
	struct me_directory_arch		base;
};


me_bool_t				me_fs_open(struct me_file *file, const me_char_t *path, me_uint8_t mode);
me_bool_t				me_fs_close(struct me_file *file);
me_bool_t				me_fs_read(struct me_file *file, void *buff, me_size_t read_size, me_size_t *result);
me_bool_t				me_fs_write(struct me_file *file, const void *data, me_size_t write_size, me_size_t *result);
me_size_t				me_fs_write_format(struct me_file *file, const me_char_t *format, ... );
me_size_t				me_fs_write_vformat(struct me_file *file, const me_char_t *format, va_list args);

me_bool_t				me_fs_lseek(struct me_file *file, me_size_t ofs);

me_bool_t				me_fs_opendir(struct me_directory *dir, const me_char_t *path);
me_bool_t				me_fs_closedir(struct me_directory *dir);
me_bool_t				me_fs_readdir(struct me_directory *dir, struct me_file_info *info);

me_bool_t				me_fs_mkdir(const me_char_t *path);
me_bool_t				me_fs_unlink(const me_char_t *path);
me_bool_t				me_fs_rename(const me_char_t *path_old, const me_char_t *path_new);
me_bool_t				me_fs_stat(const me_char_t *path, struct me_file_info *info);
me_bool_t				me_fs_chdir(const me_char_t *path);
me_bool_t				me_fs_getcwd(struct me_path *path);


#endif

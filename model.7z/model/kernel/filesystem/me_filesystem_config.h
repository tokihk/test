#ifndef ME_FILESYSTEM_CONFIG_H_
#define ME_FILESYSTEM_CONFIG_H_

#include "kernel/filesystem/me_filesystem_config_board.h"


#ifndef ME_PATH_LENGTH_MAX
#define ME_PATH_LENGTH_MAX						(250)
#endif

#endif

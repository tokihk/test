#ifndef ME_FILESYSTEM_STDDEF_H_
#define ME_FILESYSTEM_STDDEF_H_

#include "kernel/core/me_stddef.h"


#define	ME_FILEMODE_READ				(0x01)
#define	ME_FILEMODE_WRITE				(0x02)
#define	ME_FILEMODE_OPEN_EXISTING		(0x00)
#define	ME_FILEMODE_CREATE_NEW			(0x04)
#define	ME_FILEMODE_CREATE_ALWAYS		(0x08)
#define	ME_FILEMODE_OPEN_ALWAYS			(0x10)
#define	ME_FILEMODE_OPEN_APPEND			(0x30)


#define ME_FILEATTR_READONLY			(0x01)
#define ME_FILEATTR_HIDDEN				(0x02)
#define ME_FILEATTR_DIRECTORY			(0x10)


struct me_file_info
{
	me_size_t		file_size;
	me_uint8_t		attr;
};


#endif

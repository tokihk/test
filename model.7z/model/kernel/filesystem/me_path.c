#include "me_path.h"

#include "kernel/core/me_string.h"


void me_path_assign(struct me_path *obj, const me_char_t *path)
{
	if (obj != NULL) {
		if (path != NULL) {
			me_strcncpy(obj->path_full, path, ME_COUNTOF(obj->path_full));
		}
		obj->path_full[ME_COUNTOF(obj->path_full) - 1] = ME_TEXT('\0');
	}
}

void me_path_dirname(const struct me_path *base, struct me_path *path)
{
	if ((base != NULL) && (path != NULL)) {
		me_char_t *path_cur;
		me_char_t *path_end;

		*path = *base;

		path_cur = &path->path_full[0];
		path_end = path_cur;

		while (*path_cur != ME_TEXT('\0')) {
			if (*path_cur == ME_PATH_SEPARATOR) {
				path_end = path_cur;
			}
			path_cur++;
		}

		*path_end = ME_TEXT('\0');
	}
}

void me_path_basename(const struct me_path *base, struct me_path *path)
{
	if ((base != NULL) && (path != NULL)) {
		me_char_t *path_cur;
		me_char_t *path_end;

		path_cur = &base->path_full[0];
		path_end = path_cur;

		/* 最後のセパレータの場所を検索 */
		while (*path_cur != ME_TEXT('\0')) {
			if (*path_cur == ME_PATH_SEPARATOR) {
				path_end = path_cur;
			}
			path_cur++;
		}

		if (*path_end == ME_PATH_SEPARATOR) {
			path_end++;
		}

		/* セパレータより後ろをコピー */
		path_cur = &path->path_full[0];
		while (*path_end != ME_TEXT('\0')) {
			*path_cur = *path_end;
			path_cur++;
			path_end++;
		}

		*path_cur = ME_TEXT('\0');
	}
}

#ifndef ME_PATH_H_
#define ME_PATH_H_

#include "kernel/filesystem/me_path_stddef.h"


struct me_path
{
	me_char_t			path_full[ME_PATH_LENGTH_MAX + 1];
};


#define me_path_c_str(obj)			(&((obj)->path_full[0]))


void					me_path_assign(struct me_path *obj, const me_char_t *path);

void					me_path_dirname(const struct me_path *base, struct me_path *path);
void					me_path_basename(const struct me_path *base, struct me_path *path);


#endif

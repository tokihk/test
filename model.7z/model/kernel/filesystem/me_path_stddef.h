#ifndef ME_PATH_STDDEF_H_
#define ME_PATH_STDDEF_H_

#include "kernel/core/me_stddef.h"


#define ME_PATH_SEPARATOR			ME_TEXT('/')


#endif

/* ###################################################################### *//**
 *
 *	@addtogroup	FileSystem
 *	@{
 *	@file		ic_file.c
 *	@brief
 *	@author		Copyright (C) 2015 Icom.Inc
 *
*//* ####################################################################### */

#include "ic_file.h"
#include "arch/ic_file_arch.h"

#include "kernel/fs/ic_directory.h"

#include <string.h>


struct st_ic_file {
	ic_file_arch_t *		base;
};


static void ic_file_directory_make(const ic_char_t *filename)
{
	ic_string_t *str;

	str = ic_string_new(NULL);
	if (str != NULL) {
		if (ic_directory_name_get(filename, str)) {
			ic_directory_make(ic_string_c_str(str));
		}
		ic_string_delete(str);
	}
}

ic_file_t *ic_file_open(const ic_char_t *filename, enum en_ic_file_mode mode)
{
	ic_file_t *obj = NULL;
	ic_bool_t error = IC_FALSE;

	if (filename != NULL) {
		IC_TRAP_PTR_ERROR_SET(obj = ic_malloc_base(sizeof(*obj)), error);
		if (obj != NULL) {
			/* 書き込み可能モードのときはディレクトリも生成 */
			if (mode != IC_FILE_READONLY) {
				ic_file_directory_make(filename);
			}

			IC_TRAP_PTR_ERROR_SET(obj->base = ic_file_new_arch(filename, mode), error);
		}
	}

	/* === エラー処理 === */
	if (error) {
		ic_file_close(obj);
		obj = NULL;
	}

	return (obj);
}

void ic_file_close(ic_file_t *obj)
{
	if (obj != NULL) {
		ic_file_delete_arch(obj->base);
		ic_free_base(obj);
	}
}

ic_uint16_t ic_file_read(ic_file_t *obj, ic_uint8_t *buffer, ic_uint16_t size)
{
	ic_uint16_t read_size = 0;

	if (   (obj != NULL)
		&& (buffer != NULL)
		&& (size > 0)
	) {
		read_size = ic_file_read_arch(obj->base, buffer, size);
	}

	return (read_size);
}

ic_bool_t ic_file_readline(ic_file_t *obj, ic_string_t *str)
{
	ic_bool_t read_ok = IC_FALSE;

	if (   (obj != NULL)
		&& (str != NULL)
	) {
		ic_uint8_t buffer;

		/* 可変長文字列をクリア */
		ic_string_clear(str);

		/* 1バイトずつ読み込む */
		while (ic_file_read_arch(obj->base, &buffer, 1)) {
			/* 1バイトでも読み込めたら成功 */
			read_ok = IC_TRUE;

			/* 改行コードの場合は終了 */
			if (buffer == (ic_uint8_t)'\n')break;

			ic_string_append_char(str, (ic_char_t)buffer);
		}
	}

	return (read_ok);
}

ic_uint16_t ic_file_write(ic_file_t *obj, const ic_uint8_t *data, ic_uint16_t size)
{
	ic_uint16_t write_size = 0;

	if (   (obj != NULL)
		&& (data != NULL)
		&& (size > 0)
	) {
		write_size = ic_file_write_arch(obj->base, data, size);
	}

	return (write_size);
}

ic_uint16_t ic_file_write_format(ic_file_t *obj, const ic_char_t *format, ... )
{
	ic_uint16_t write_size = 0;
	va_list args = {0};

    /* --- 可変引数初期化 --- */
    va_start(args, format);

    /* --- 処理開始 --- */
    write_size = ic_file_write_vformat_arch(obj->base, format, args);

    /* --- 可変引数終了 --- */
    va_end(args);

    return (write_size);
}

ic_bool_t ic_file_is_exist(const ic_char_t *filename)
{
	ic_bool_t is_exist = IC_FALSE;

	if (filename != NULL) {
		is_exist = ic_file_is_exist_arch(filename);
	}

	return (is_exist);
}

ic_bool_t ic_file_remove(const ic_char_t *filename)
{
	ic_bool_t rem_ok = IC_FALSE;

	if (filename != NULL) {
		rem_ok = ic_file_remove_arch(filename);
	}

	return (rem_ok);
}

ic_bool_t ic_file_make_empty(const ic_char_t *filename)
{
	ic_bool_t make_ok = IC_FALSE;
	ic_file_t *obj;

	obj = ic_file_open(filename, IC_FILE_READWRITE_NEW);
	if (obj != NULL) {
		ic_file_close(obj);
	}

	return (make_ok);
}


/* ####### File End ###### */
/** @} */

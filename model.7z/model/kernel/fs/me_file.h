#ifndef ME_FILE_H_
#define ME_FILE_H_

#include "kernel/me_kernel.h"

#include "kernel/fs/me_file_arch.h"


typedef struct me_file
{
	me_file_arch_t			arch_param;
} me_file_t;


typedef struct st_ic_file	ic_file_t;


enum me_file_mode {
	ME_FILE_READONLY,
	ME_FILE_READWRITE_NEW,
	ME_FILE_READWRITE_ADD,
};


me_bool_t				me_file_open(me_file_t *obj, const me_char_t *filename, enum me_file_mode mode);
void					me_file_close(me_file_t *obj);

me_size_t				me_file_read(me_file_t *obj, me_uint8_t *buffer, me_size_t buffer_size);
me_bool_t				me_file_readline(me_file_t *obj, me_string_t *str);

me_size_t				me_file_write(me_file_t *obj, const me_uint8_t *data, me_uint16_t size);

me_size_t				me_file_write_format(me_file_t *obj, const me_char_t *format, ... );

me_bool_t				me_file_is_exist(const me_char_t *filename);

me_bool_t				me_file_remove(const me_char_t *filename);

me_bool_t				me_file_make_empty(const me_char_t *filename);



#endif

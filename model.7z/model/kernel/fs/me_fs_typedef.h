#ifndef ME_FS_TYPEDEF_H_
#define ME_FS_TYPEDEF_H_

#include "kernel/me_kernel.h"

#include "kernel/fs/me_fs_typedef_arch.h"


typedef struct me_file
{
	me_file_arch_t		base;
} me_file_t;


#endif

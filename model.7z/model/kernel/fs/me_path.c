#include "me_path.h"

#include "kernel/base/me_string_utility.h"


void me_path_initialize(me_path_t *obj, const me_char_t *init_path)
{
	if (obj != NULL) {
		obj->path_full[0] = ME_TEXT('\0');

		me_path_assign(obj, init_path);
	}
}

void me_path_assign(me_path_t *obj, const me_char_t *path)
{
	if ((obj != NULL) && (path != NULL)) {
		me_strcncpy(obj->path_full, path, ME_COUNTOF(obj->path_full));
		obj->path_full[ME_COUNTOF(obj->path_full) - 1] = ME_TEXT('\0');
	}
}

void me_path_block_begin(me_path_block_t *obj, const me_path_t *path)
{
	if ((obj != NULL) && (path != NULL)) {
		obj->path_base = *path;
		obj->block_next_top = &obj->path_base.path_full[0];
		obj->block_curr = obj->block_next_top;
		obj->end = ME_FALSE;

		me_path_block_shift(obj);
	}
}

me_bool_t me_path_block_end(const me_path_block_t *obj)
{
	me_bool_t end = ME_TRUE;

	if (obj != NULL) {
		end = obj->end;
	}

	return (end);
}

void me_path_block_shift(me_path_block_t *obj)
{
	if (obj != NULL) {
		if (!obj->end) {
			obj->block_curr = obj->block_next_top;

			/* セパレータもしくは終端を検索 */
			while (   (*(obj->block_next_top) != ME_PATH_SEPARATOR)
				   && (*(obj->block_next_top) != ME_TEXT('\0'))
			) {
				obj->block_next_top++;
			}

			if (*(obj->block_next_top) == ME_TEXT('\0')) {
				/* --- 終端の場合 --- */
				obj->end = ME_TRUE;
			} else {
				/* --- セパレータの場合 --- */
				*(obj->block_next_top) = ME_TEXT('\0');
				obj->block_next_top++;
			}
		}
	}
}


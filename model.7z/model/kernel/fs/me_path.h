/* ###################################################################### *//**
 *
 *	@addtogroup	Kernel
 *	@{
 *	@file		me_path.h
 *	@brief		Path Module
 *	@author		Copyright (C) 2019 Hitoshi Kouno
 *
*//* ####################################################################### */
#ifndef ME_PATH_H_
#define ME_PATH_H_

#include "kernel/me_kernel.h"


#define ME_PATH_SEPARATOR			'/'


typedef struct me_path
{
	me_char_t			path_full[ME_PATH_LENGTH_MAX + 1];
} me_path_t;

typedef struct me_path_block
{
	me_path_t			path_base;
	me_char_t *			block_curr;
	me_char_t *			block_next_top;
	me_bool_t			end;
} me_path_block_t;


void					me_path_initialize(me_path_t *obj, const me_char_t *init_path);

#define me_path_c_str(obj)			(&((obj)->path_full[0]))

void					me_path_assign(me_path_t *obj, const me_char_t *path);

void					me_path_block_begin(me_path_block_t *obj, const me_path_t *path);
me_bool_t				me_path_block_end(const me_path_block_t *obj);
void					me_path_block_shift(me_path_block_t *obj);

#define me_path_block_c_str(obj)	((obj)->path_block)


#endif /* ME_PATH_H_ */
/* ####### File End ###### */
/** @} */

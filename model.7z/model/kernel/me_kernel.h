#ifndef ME_KERNEL_H_
#define ME_KERNEL_H_

#include "kernel/core/me_core_config.h"
#include "kernel/peripherals/me_peripheral_config.h"
#include "kernel/protocols/me_protocol_config.h"
#include "kernel/functions/me_function_config.h"

#include "kernel/core/me_stddef.h"

#endif




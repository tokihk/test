#include "me_net.h"


me_bool_t me_net_initialize(void)
{
	return (me_net_initialize_board());
}

void me_net_finalize(void)
{
	me_net_finalize_board();
}

me_bool_t me_net_endpoint_get(me_net_endpoint_t *ep, enum me_net_domain_type dtype, const me_achar_t *hostname)
{
	me_bool_t success = ME_FALSE;

	if ((ep != NULL) && (hostname != NULL)) {
		success = me_net_endpoint_get_board(&ep->base, dtype, hostname);
	}

	return (success);
}

me_bool_t me_net_endpoint_to_text(const me_net_endpoint_t *ep, enum me_net_domain_type dtype, me_achar_t *ep_text, me_size_t ep_text_size)
{
	me_bool_t success = ME_FALSE;

	if ((ep != NULL) && (ep_text != NULL) && (ep_text_size > 0)) {
		success = me_net_endpoint_to_text_board(&ep->base, dtype, ep_text, ep_text_size);
	}

	return (success);
}


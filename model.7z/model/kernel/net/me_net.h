#ifndef ME_NET_H_
#define ME_NET_H_

#include "kernel/me_kernel.h"

#include "kernel/net/me_net_typedef.h"

#include "kernel/net/me_net_board.h"


me_bool_t			me_net_initialize(void);
void				me_net_finalize(void);

me_bool_t			me_net_endpoint_get(me_net_endpoint_t *ep, enum me_net_domain_type dtype, const me_achar_t *hostname);

me_bool_t			me_net_endpoint_to_text(const me_net_endpoint_t *ep, enum me_net_domain_type dtype, me_achar_t *ep_text, me_size_t ep_text_size);


#endif

#ifndef ME_NET_H_
#define ME_NET_H_

#include "kernel/me_kernel.h"

#define IC_INET_ADDRESS_MAXLEN			(255)


	enum me_ipdomain_type {
		IC_IPDOMAIN_TYPE_UNKNOWN,
		IC_IPDOMAIN_TYPE_IPV4,
		IC_IPDOMAIN_TYPE_IPV6,
	};

	enum me_netsocket_type {
		IC_NETSOCKET_TYPE_TCP,
		IC_NETSOCKET_TYPE_UDP,
	};

	struct me_ipaddress_v4 {
		me_uint8_t					data[4];
		me_uint8_t					mask[4];
	};

	struct me_ipaddress_v6 {
		me_uint16_t					data[8];
	};

	struct me_ipaddress {
		enum me_ipdomain_type		type;

		union {
			struct me_ipaddress_v4	ipv4;
			struct me_ipaddress_v6	ipv6;
		} value;
	};

	struct me_ipendpoint {
		me_uint16_t					port_no;
		struct me_ipaddress			address;
	};


	ic_bool_t				ic_inet_network_address_get(const ic_ipaddress_t *addr, ic_ipaddress_t *value);
	ic_bool_t				ic_inet_host_address_get(const ic_ipaddress_t *addr, ic_ipaddress_t *value);

	ic_bool_t				ic_inet_equal_endpoint(const ic_ipendpoint_t *ep1, const ic_ipendpoint_t *ep2);
	ic_bool_t				ic_inet_equal_network_address(const ic_ipaddress_t *addr1, const ic_ipaddress_t *addr2);

	ic_bool_t				ic_inet_text_to_endpoint(const ic_char_t *text, ic_ipendpoint_t *ep);
	ic_bool_t				ic_inet_text_to_ipaddress(const ic_char_t *text, ic_ipaddress_t *addr);
	ic_bool_t				ic_inet_text_to_subnetmask(const ic_char_t *text, ic_ipaddress_t *addr);

#endif

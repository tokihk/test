#ifndef ME_NET_TYPEDEF_H_
#define ME_NET_TYPEDEF_H_

#include "kernel/me_kernel.h"

#include "kernel/net/me_net_typedef_board.h"


enum me_net_domain_type
{
	ME_NET_DOMAIN_TYPE_IPV4,
	ME_NET_DOMAIN_TYPE_IPV6,
};

enum me_net_socket_type
{
	ME_NET_SOCKET_TYPE_TCP,
	ME_NET_SOCKET_TYPE_UDP,
};

typedef struct me_net_endpoint
{
	me_net_endpoint_board_t		base;
} me_net_endpoint_t;

typedef struct me_net_tcp_server
{
	me_net_tcp_server_board_t	base;
} me_net_tcp_server_t;

typedef struct me_net_tcp_client
{
	me_net_tcp_client_board_t	base;
} me_net_tcp_client_t;

typedef struct me_net_udp_client
{
	me_net_udp_client_board_t	base;
} me_net_udp_client_t;


#endif

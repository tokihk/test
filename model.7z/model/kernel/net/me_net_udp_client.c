#include "kernel/net/me_net_udp_client.h"


me_bool_t me_net_udp_client_create(me_net_udp_client_t *obj, me_uint16_t local_port_no)
{
	me_bool_t success = ME_FALSE;

	if ((obj != NULL) && (local_port_no > 0)) {
		success = me_net_udp_client_create_board(&obj->base, local_port_no);
	}

	return (success);
}

void me_net_udp_client_destroy(me_net_udp_client_t *obj)
{
	if (obj != NULL) {
		me_net_udp_client_destroy_board(&obj->base);
	}
}

me_size_t me_net_udp_client_sendto(me_net_udp_client_t *obj, const me_uint8_t *data, me_size_t size, const me_net_endpoint_t *remote_ep)
{
	me_size_t send_size = 0;

	if ((obj != NULL) && (data != NULL) && (size > 0) && (remote_ep != NULL)) {
		send_size = me_net_udp_client_sendto_board(&obj->base, data, size, &remote_ep->base);
	}

	return (send_size);
}

me_size_t me_net_udp_client_recvfrom(me_net_udp_client_t *obj, me_uint8_t *buffer, me_size_t size, me_net_endpoint_t *remote_ep, me_uint32_t timeout_msec)
{
	me_size_t recv_size = 0;

	if ((obj != NULL) && (buffer != NULL) && (size > 0) && (remote_ep != NULL)) {
		recv_size = me_net_udp_client_recvfrom_board(&obj->base, buffer, size, &remote_ep->base, timeout_msec);
	}

	return (recv_size);
}


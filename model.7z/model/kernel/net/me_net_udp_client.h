#ifndef ME_NET_UDP_CLIENT_H_
#define ME_NET_UDP_CLIENT_H_

#include "kernel/me_kernel.h"

#include "kernel/net/me_net_udp_client_board.h"


me_bool_t					me_net_udp_client_create(me_net_udp_client_t *obj, me_uint16_t local_port_no);
void						me_net_udp_client_destroy(me_net_udp_client_t *obj);

me_size_t					me_net_udp_client_sendto(me_net_udp_client_t *obj, const me_uint8_t *data, me_size_t size, const me_net_endpoint_t *remote_ep);

me_size_t					me_net_udp_client_recvfrom(me_net_udp_client_t *obj, me_uint8_t *buffer, me_size_t size, me_net_endpoint_t *remote_ep, me_uint32_t timeout_msec);


#endif

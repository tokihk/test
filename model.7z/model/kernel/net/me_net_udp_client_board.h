#ifndef ME_NET_UDP_CLIENT_BOARD_H_
#define ME_NET_UDP_CLIENT_BOARD_H_

#include "kernel/me_kernel.h"

#include "kernel/net/me_net_udp_client_arch.h"


me_bool_t			me_net_udp_client_create_board(me_net_udp_client_board_t *obj, me_uint16_t local_port_no);
void				me_net_udp_client_destroy_board(me_net_udp_client_board_t *obj);

me_size_t			me_net_udp_client_sendto_board(me_net_udp_client_board_t *obj, const me_uint8_t *data, me_size_t size, const me_net_endpoint_board_t *remote_ep);

me_size_t			me_net_udp_client_recvfrom_board(me_net_udp_client_board_t *obj, me_uint8_t *buffer, me_size_t size, me_net_endpoint_board_t *remote_ep, me_uint32_t timeout_msec);


#endif

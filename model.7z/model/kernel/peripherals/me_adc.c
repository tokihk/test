#include "me_adc.h"

#include "kernel/peripherals/me_adc_board.h"


me_bool_t me_adc_initialize(void)
{
	return (me_adc_initialize_board());
}

void me_adc_finalize(void)
{
	me_adc_finalize_board();
}

me_bool_t me_adc_value_get(me_uint16_t adc_id)
{
	return (me_adc_value_get_board(adc_id));
}

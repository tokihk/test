#ifndef ME_ADC_H_
#define ME_ADC_H_

#include "kernel/peripherals/me_adc_stddef.h"


me_bool_t					me_adc_initialize(void);
void						me_adc_finalize(void);

me_bool_t					me_adc_value_get(me_uint16_t adc_id);


#endif

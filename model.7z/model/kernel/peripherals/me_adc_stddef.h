#ifndef ME_ADC_STDDEF_H_
#define ME_ADC_STDDEF_H_

#include "kernel/me_kernel.h"

#endif

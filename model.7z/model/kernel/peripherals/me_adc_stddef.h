#ifndef ME_ADC_STDDEF_H_
#define ME_ADC_STDDEF_H_

#include "kernel/core/me_stddef.h"

#endif

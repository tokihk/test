#include "me_gpio.h"


me_bool_t me_gpio_initialize(void)
{
	return (me_gpio_initialize_board());
}

void me_gpio_finalize(void)
{
	me_gpio_finalize_board();
}

me_bool_t me_gpio_direction_get(me_uint16_t pin)
{
	return (me_gpio_direction_get_board(pin));
}

void me_gpio_direction_set(me_uint16_t pin, me_bool_t dir)
{
	me_gpio_direction_set_arch(pin, dir);
}

me_bool_t me_gpio_value_get(me_uint16_t pin)
{
	return (me_gpio_value_get_arch(pin));
}

void me_gpio_value_set(me_uint16_t pin, me_bool_t value)
{
	me_gpio_value_set_arch(pin, value);
}

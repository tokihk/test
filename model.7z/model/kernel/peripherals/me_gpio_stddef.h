#ifndef ME_GPIO_STDDEF_H_
#define ME_GPIO_STDDEF_H_

#include "kernel/core/me_stddef.h"


#define ME_GPIO_ID_COMMON_TOP			(0xF000u)

#define ME_GPIO_ID_DEBUG_00				(ME_GPIO_ID_COMMON_TOP + 0u)
#define ME_GPIO_ID_DEBUG_01				(ME_GPIO_ID_COMMON_TOP + 1u)


#endif

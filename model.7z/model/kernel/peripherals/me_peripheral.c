#include "me_peripheral.h"


me_bool_t me_peripheral_initialize(void)
{
	return (me_peripheral_initialize_board());
}

void me_peripheral_finalize(void)
{
	me_peripheral_finalize_board();
}


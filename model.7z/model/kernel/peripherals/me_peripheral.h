#ifndef ME_PERIPHERAL_H_
#define ME_PERIPHERAL_H_

#include "kernel/peripherals/me_peripheral_stddef.h"

#include "kernel/peripherals/me_peripheral_board.h"


me_bool_t			me_peripheral_initialize(void);
void				me_peripheral_finalize(void);


#endif

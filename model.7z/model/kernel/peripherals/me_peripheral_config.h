#ifndef ME_PERIPHERAL_CONFIG_H_
#define ME_PERIPHERAL_CONFIG_H_

#include "kernel/peripherals/me_peripheral_config_board.h"


#ifndef ME_DEVICE_CONFIG_TIMER_NUMBER
#define ME_DEVICE_CONFIG_TIMER_NUMBER			(1)
#endif

#endif

#ifndef ME_PERIPHERAL_STDDEF_H_
#define ME_PERIPHERAL_STDDEF_H_

#include "kernel/me_kernel.h"


#endif

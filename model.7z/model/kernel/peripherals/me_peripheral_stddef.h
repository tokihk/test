#ifndef ME_PERIPHERAL_STDDEF_H_
#define ME_PERIPHERAL_STDDEF_H_

#include "kernel/core/me_stddef.h"


#endif

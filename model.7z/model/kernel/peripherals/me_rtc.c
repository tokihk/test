#include "me_rtc.h"

#include "kernel/peripherals/me_rtc_board.h"


me_bool_t me_rtc_initialize(void)
{
	return (me_rtc_initialize_board());
}

void me_rtc_finalize(void)
{
	me_rtc_finalize();
}

me_bool_t me_rtc_datetime_get(struct me_datetime *dt)
{
	me_bool_t get_ok = ME_FALSE;

	if (dt != NULL) {
		get_ok = me_rtc_datetime_get_board(dt);
	}

	return (get_ok);
}

me_bool_t me_rtc_datetime_set(const struct me_datetime *dt)
{
	me_bool_t set_ok = ME_FALSE;

	if (dt != NULL) {
		set_ok = me_rtc_datetime_set_board(dt);
	}

	return (set_ok);
}

#ifndef ME_RTC_H_
#define ME_RTC_H_

#include "kernel/core/me_stddef.h"

#include "kernel/core/me_datetime.h"


me_bool_t					me_rtc_initialize(void);
void						me_rtc_finalize(void);

me_bool_t					me_rtc_datetime_get(struct me_datetime *dt);

me_bool_t					me_rtc_datetime_set(const struct me_datetime *dt);


#endif

#include "me_spi.h"


me_bool_t me_spi_initialize(void)
{
	return (me_spi_initialize_board());
}

void me_spi_finalize(void)
{
	me_spi_finalize_board();
}

me_bool_t me_spi_setup(me_uint16_t spi_id, enum me_spi_mode mode, me_uint32_t clock_hz)
{
	return (me_spi_setup_board(spi_id, mode, clock_hz));
}

me_size_t me_spi_send(me_uint16_t spi_id, const me_uint8_t *data, me_size_t size)
{
	me_size_t send_size = 0;

	if ((data != NULL) && (size > 0)) {
		send_size = me_spi_send_board(spi_id, data, size);
	}

	return (send_size);
}

me_bool_t me_spi_send_async(me_uint16_t spi_id, const me_uint8_t *data, me_size_t size)
{
	me_bool_t success = ME_FALSE;

	if ((data != NULL) && (size > 0)) {
		success = me_spi_send_async_board(spi_id, data, size);
	}

	return (success);
}

me_bool_t me_spi_send_async_is_busy(me_uint16_t spi_id)
{
	return (me_spi_send_async_is_busy_board(spi_id));
}

me_size_t me_spi_recv(me_uint16_t spi_id, me_uint8_t *buffer, me_size_t buffer_size)
{
	me_size_t recv_size = 0;

	if ((buffer != NULL) && (buffer_size > 0)) {
		recv_size = me_spi_recv_board(spi_id, buffer, buffer_size);
	}

	return (recv_size);
}

me_bool_t me_spi_recv_async(me_uint16_t spi_id, me_uint8_t *buffer, me_size_t buffer_size)
{
	me_bool_t success = ME_FALSE;

	if ((buffer != NULL) && (buffer_size > 0)) {
		success = me_spi_recv_async_board(spi_id, buffer, buffer_size);
	}

	return (success);
}

me_bool_t me_spi_recv_async_is_busy(me_uint16_t spi_id)
{
	return (me_spi_recv_async_is_busy_board(spi_id));
}


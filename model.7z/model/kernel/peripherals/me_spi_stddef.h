#ifndef ME_SPI_STDDEF_H_
#define ME_SPI_STDDEF_H_

#include "kernel/core/me_stddef.h"


enum me_spi_mode
{
	ME_DEV_SPI_MODE_MASTER,
	ME_DEV_SPI_MODE_SLAVE,
};


#endif

#include "me_timer.h"


me_bool_t me_timer_initialize(void)
{
	return (me_timer_initialize_board());
}

void me_timer_finalize(void)
{
	me_timer_finalize_board();
}

me_bool_t me_timer_create(me_uint16_t tmr_id, me_uint32_t ival_10nsec, me_timer_callback_t callback)
{
	me_bool_t success = ME_FALSE;

	if (ival_10nsec > 0) {
		success = me_timer_create_board(tmr_id, ival_10nsec, callback);
	}

	return (success);
}

void me_timer_destroy(me_uint16_t tmr_id)
{
	me_timer_destroy_board(tmr_id);
}


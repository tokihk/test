#ifndef ME_TIMER_H_
#define ME_TIMER_H_

#include "kernel/peripherals/me_timer_stddef.h"

#include "kernel/peripherals/me_timer_board.h"


me_bool_t				me_timer_initialize(void);
void					me_timer_finalize(void);

me_bool_t				me_timer_create(me_uint16_t tmr_id, me_uint32_t ival_10nsec, void (* callback)(me_uint16_t tmr_id));
void					me_timer_destroy(me_uint16_t tmr_id);


#endif



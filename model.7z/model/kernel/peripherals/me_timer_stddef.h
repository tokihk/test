#ifndef ME_TIMER_STDDEF_H_
#define ME_TIMER_STDDEF_H_

#include "kernel/me_kernel.h"

#endif

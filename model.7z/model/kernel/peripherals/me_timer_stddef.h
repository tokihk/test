#ifndef ME_TIMER_STDDEF_H_
#define ME_TIMER_STDDEF_H_

#include "kernel/core/me_stddef.h"


typedef void (* me_timer_callback_t)(me_uint16_t tmr_id);


#define ME_TIMER_FUNC_TOP				(0xF000u)
#define ME_TIMER_FUNC_GENERAL_0			(ME_DEV_TIMER_FUNC_TOP + 0u)
#define ME_TIMER_FUNC_GENERAL_1			(ME_DEV_TIMER_FUNC_TOP + 1u)
#define ME_TIMER_FUNC_GENERAL_2			(ME_DEV_TIMER_FUNC_TOP + 2u)
#define ME_TIMER_FUNC_GENERAL_3			(ME_DEV_TIMER_FUNC_TOP + 3u)



#endif

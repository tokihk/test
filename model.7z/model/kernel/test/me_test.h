/* ###################################################################### *//**
 *
 *	@addtogroup	Kernel
 *	@{
 *	@file		me_test.h
 *	@brief		Unit Test Module
 *	@author		Copyright (C) 2019 Hitoshi Kouno
 *
*//* ####################################################################### */
#ifndef ME_TEST_H_
#define ME_TEST_H_

#include "kernel/me_kernel.h"



#define ME_TEST_TASK_START(obj,task)			me_test_task_start(obj, )


struct me_test_suite_result
{
	const me_char_t *		suite_name;

	me_uint32_t				task_count;
	me_uint32_t				success_count;

	me_uint32_t				process_time;
};

struct me_test_task_result
{
	const me_char_t *		test_name;

	const me_char_t *		source_file_name;
	me_uint32_t				source_line_no;

	me_uint32_t				process_time;

	me_bool_t				success;				/* ME_TRUE: Success, ME_FALSE: Error */
};

typedef struct me_test
{
	me_uint32_t		count_total;
	me_uint32_t		count_error;

	me_uint32_t		count_suite_total;
	me_uint32_t		count_suite_error;

	void *			user_param;

	void			(*callback_test_start)(struct me_test_manager *mgr);
	void			(*callback_test_end)(struct me_test_manager *mgr);

	void			(*callback_test_suite_start)(struct me_test_manager *mgr, const me_char_t *suite_name);
	void			(*callback_test_suite_end)(struct me_test_manager *mgr);

	void			(*callback_test_task_start)(struct me_test_manager *mgr, const struct me_test_task_result *result);
	void			(*callback_test_task_end)(struct me_test_manager *mgr, const struct me_test_task_result *result);
} me_test_t;


void							me_test_initialize(me_test_t *obj);
void							me_test_finalize(me_test_t *obj);

void							me_test_start(me_test_t *obj);
void							me_test_end(me_test_t *obj);

void							me_test_suite_start(me_test_t *obj, const me_char_t *suite_name);
void							me_test_suite_end(me_test_t *obj);

void							me_test_task_start(me_test_t *obj, const me_char_t *test_name);
void							me_test_task_run(me_test_t *obj, me_bool_t result);
void							me_test_task_end(me_test_t *obj);


#endif /* ME_TEST_H_ */
/* ####### File End ###### */
/** @} */

#ifndef ME_CONFIG_H_
#define ME_CONFIG_H_

#include "kernel/base/me_config_arch.h"

#endif

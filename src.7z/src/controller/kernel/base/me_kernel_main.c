#include "kernel/base/me_kernel_main.h"
#include "kernel/base/me_main.h"


me_int8_t me_kernel_main(me_int32_t argc, const me_achar_t *argv[])
{
	me_int8_t	exit_code = 0;

	exit_code = me_main(argc, argv);

	return (exit_code);
}

#ifndef ME_MACRO_H_
#define ME_MACRO_H_

	#define UNREFERENCED_PARAMETER(var)		(void)var

#endif

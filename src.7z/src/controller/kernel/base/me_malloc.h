/* ###################################################################### *//**
 *
 *	@addtogroup	Kernel
 *	@{
 *	@file		me_malloc.h
 *	@brief		Heap Memory Module
 *	@author		Copyright (C) 2019 Hitoshi Kouno
 *
*//* ####################################################################### */
#ifndef ME_MALLOC_H_
#define ME_MALLOC_H_

#include "kernel/me_kernel.h"


	void					me_malloc_initialize(void);
	void					me_malloc_finalize(void);

	void *					me_malloc(me_size_t size);
	void *					me_calloc(me_size_t size);

	void					me_free(void *ptr);


#endif /* ME_THREAD_H_ */
/* ####### File End ###### */
/** @} */

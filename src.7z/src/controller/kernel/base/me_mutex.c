/* ###################################################################### *//**
 *
 *	@addtogroup	Kernel
 *	@{
 *	@file		me_mutex.c
 *	@brief		Mutex Module
 *	@author		Copyright (C) 2019 Hitoshi Kouno
 *
*//* ####################################################################### */

#include "me_mutex.h"

#include "kernel/base/me_malloc.h"


me_bool_t me_mutex_initialize(me_mutex_t *obj)
{
	me_bool_t error = ME_FALSE;

	if (obj != NULL) {
		obj->guard_code = obj;

		if (!me_mutex_initialize_arch(obj)) {
			error = ME_TRUE;
		}
	}

	if (error) {
		me_mutex_finalize(obj);
	}

	return (ME_TOBOOL(!error));
}

void me_mutex_finalize(me_mutex_t *obj)
{

}

me_mutex_t *me_mutex_new(void)
{
	me_mutex_t *obj = NULL;
	me_bool_t error = ME_FALSE;

	obj = me_malloc(sizeof(*obj));
	if (obj != NULL) {
		obj->arch_param = me_mutex_new_arch();
		if (obj->arch == NULL) {
			error = IC_TRUE;
		}
	}

	/* === エラー処理 === */
	if (error) {
		me_mutex_delete(obj);
		obj = NULL;
	}

	return (obj);
}

void me_mutex_delete(me_mutex_t *obj)
{
	if (obj != NULL) {
		me_mutex_delete_arch(obj->arch);
		me_free_base(obj);
	}
}

void me_mutex_lock(me_mutex_t *obj)
{
	if (obj != NULL) {
		me_mutex_lock_arch(obj->arch);
	}
}

me_bool_t me_mutex_trylock(me_mutex_t *obj)
{
	me_bool_t lock = IC_FALSE;

	if (obj != NULL) {
		lock = me_mutex_trylock_arch(obj->arch);
	}

	return (lock);
}

void me_mutex_unlock(me_mutex_t *obj)
{
	if (obj != NULL) {
		me_mutex_unlock_arch(obj->arch);
	}
}


/* ####### File End ###### */
/** @} */

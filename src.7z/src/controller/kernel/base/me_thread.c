/* ###################################################################### *//**
 *
 *	@addtogroup	Module
 *	@{
 *	@file		ic_thread.c
 *	@brief		エントリポイント
 *	@author		Copyright (C) 2015 Icom.Inc
 *
*//* ####################################################################### */

#include "ic_thread.h"

#include "arch/ic_thread_arch.h"

#include "kernel/system/ic_clock.h"

#include <string.h>


struct st_ic_thread
{
	ic_thread_arch_t *			arch;

	void *						param;

	IC_CALLBACK_THREAD			callback;
};


static void ic_thread_main(ic_thread_arch_t *obj_arch, void *param)
{
	ic_thread_t *obj = (ic_thread_t *)param;

	UNREFERENCED_PARAMETER(obj_arch);

	/* --- コールバック関数呼び出し --- */
	if (obj->callback != NULL) {
		(obj->callback)(obj, obj->param);
	}
}


ic_thread_t *ic_thread_new(IC_CALLBACK_THREAD callback, void *param)
{
	ic_thread_t *obj = NULL;
	ic_bool_t error = IC_FALSE;

	obj = ic_malloc_base(sizeof(*obj));
	if (obj != NULL) {
		obj->callback = callback;
		obj->param = param;

		/* --- スレッド開始 --- */
		obj->arch = ic_thread_new_arch(ic_thread_main, obj);
		IC_TRAP_ERROR_SET(obj->arch != NULL, error);
	}

	/* === エラー処理 === */
	if (error) {
		ic_thread_delete(obj);
		obj = NULL;
	}

	return (obj);
}

void ic_thread_delete(ic_thread_t *obj)
{
	if (obj != NULL) {
		ic_thread_delete_arch(obj->arch);
		ic_free_base(obj);
	}
}

ic_bool_t ic_thread_is_active(ic_thread_t *obj)
{
	ic_bool_t is_active = IC_FALSE;

	if (obj != NULL) {
		is_active = ic_thread_is_active_arch(obj->arch);
	}

	return (is_active);
}

ic_bool_t ic_thread_join(ic_thread_t *obj, ic_uint32_t wait_ms)
{
	ic_bool_t error = IC_FALSE;
	ic_uint32_t time_s;

	time_s = ic_clock_time_msec();
	while (ic_thread_is_active(obj)) {
		/* --- タイムアウト --- */
		if (   (wait_ms != ~(ic_uint32_t)0)
			&& (ic_clock_elapsed_msec(time_s) >= wait_ms)
		) {
			break;
		}

		ic_thread_sleep_ms(1);
	}

	return (error);
}

/* -------------------------------------------------- *//**
 *	@brief		指定した時間[秒]だけスリープします。
 *	@param		time_s		スリープ時間[s]。
 *//* -------------------------------------------------- */
void ic_thread_sleep(ic_uint32_t time_s)
{
	ic_thread_sleep_arch(time_s);
}

/* -------------------------------------------------- *//**
 *	@brief		指定した時間[ミリ秒]だけスリープします。
 *	@param		time_ms		スリープ時間[ms]。
 *//* -------------------------------------------------- */
void ic_thread_sleep_ms(ic_uint32_t time_ms)
{
	ic_thread_sleep_ms_arch(time_ms);
}

/* ####### File End ###### */
/** @} */

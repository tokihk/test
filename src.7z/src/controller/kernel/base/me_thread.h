/* ###################################################################### *//**
 *
 *	@addtogroup	Kernel
 *	@{
 *	@file		me_thread.h
 *	@brief		Thread Module
 *	@author		Copyright (C) 2019 Hitoshi Kouno
 *
*//* ####################################################################### */
#ifndef ME_THREAD_H_
#define ME_THREAD_H_

#include "kernel/me_kernel.h"


typedef struct me_thread
{
	struct me_thread_arch			arch_param;
} me_thread_t;


#define ME_THREAD_OBJECT_SIZE()		sizeof(me_thread_t);


typedef void (* ME_THREAD_CALLBACK)(me_thread_t *obj, void *param);


me_thread_t *			me_thread_new(ME_THREAD_CALLBACK callback, void *param);
me_thread_t *			me_thread_new_placement(void *ram, me_size_t ram_size, ME_THREAD_CALLBACK callback, void *param);

void					me_thread_delete(me_thread_t *obj);

me_bool_t				me_thread_is_active(me_thread_t *obj);

me_bool_t				me_thread_join(me_thread_t *obj, me_uint32_t wait_ms);

void					me_thread_sleep(me_uint32_t time_s);
void					me_thread_sleep_ms(me_uint32_t time_ms);


#endif /* ME_THREAD_H_ */
/* ####### File End ###### */
/** @} */

#ifndef ME_TYPEDEF_H_
#define ME_TYPEDEF_H_

	#include "kernel/base/me_typedef_arch.h"

	typedef int							me_int_t;

	typedef char						me_achar_t;
	typedef wchar_t						me_wchar_t;

	#if ARCH_OPTION_CHAR_IS_WCHAR
		typedef me_wchar_t				me_char_t;
		#define ME_TEXT(text)			L ## text
	#else
		typedef me_achar_t				me_char_t;
		#define ME_TEXT(text)			text
	#endif



#endif

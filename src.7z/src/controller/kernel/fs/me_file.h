#ifndef ME_FILE_BASE_H_
#define ME_FILE_BASE_H_


	typedef struct me_file
	{
		void *				sub_param;

	} me_file_t;



	typedef struct st_ic_file	ic_file_t;


	enum en_ic_file_mode {
		IC_FILE_READONLY,
		IC_FILE_READWRITE_NEW,
		IC_FILE_READWRITE_ADD,
	};


	ic_file_t *				ic_file_open(const ic_char_t *filename, enum en_ic_file_mode mode);
	void					ic_file_close(ic_file_t *obj);

	ic_uint16_t				ic_file_read(ic_file_t *obj, ic_uint8_t *buffer, ic_uint16_t size);
	ic_bool_t				ic_file_readline(ic_file_t *obj, ic_string_t *str);

	ic_uint16_t				ic_file_write(ic_file_t *obj, const ic_uint8_t *data, ic_uint16_t size);
	ic_uint16_t				ic_file_write_format(ic_file_t *obj, const ic_char_t *format, ... );

	ic_bool_t				ic_file_is_exist(const ic_char_t *filename);

	ic_bool_t				ic_file_remove(const ic_char_t *filename);

	ic_bool_t				ic_file_make_empty(const ic_char_t *filename);



#endif

#!/usr/bin/python3
# -*- coding: utf-8 -*-

DIR_LOGIN_USER_ROOT = "/tmp/web/login-user"


#!/usr/bin/python3
# -*- coding: utf-8 -*-

import os

class FirmwareManager:
	@staticmethod
	def get_firmware_path(uobj):
		return uobj.get_work_file_path('firmware-tmp')

	@staticmethod
	def update_ready(uobj, file):
		save_path = FirmwareManager.get_firmware_path(uobj)

		file.save(save_path)

		return FirmwareInfo()

	@staticmethod
	def update_run(uobj):
		path = get_firmware_path(uobj)

		if os.path.isfile(path) is False:
			return False
		
		return True

class FirmwareInfo:
	def __init__(self):
		self.revision = '1.0.0.0'

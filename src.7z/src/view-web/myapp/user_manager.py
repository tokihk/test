#!/usr/bin/python3
# -*- coding: utf-8 -*-

import os, shutil
from datetime import datetime

from myapp import config
from utility import textutil

def create_access_key():
	return textutil.random_text(24)

class UserManager:
	@staticmethod
	def login(username, access_key, password=None, override=False):
		if username is None or access_key is None or len(username) == 0 or len(access_key) == 0:
			return UserLoginResult(None, 'Illegal user name.')

		# ログイン情報を取得
		user_data = UserManager.load_user_data(username)

		# 同じ名前の他のユーザーがログイン中かどうかを調べる
		if user_data and user_data.username == username and user_data.access_key != access_key:
			if override is False:
				# 上書きログインが許可されていない場合は失敗
				return UserLoginResult(None, 'A user with the same name is logged in.')

			# ログイン情報を削除
			logout(username)
			user_data = None

		# ログイン中でなければログイン処理
		if user_data is None:
			account_info = AccountManager.load_account_info(username)

			# アカウントが存在しない、もしくはパスワードが一致しなければ失敗
			if account_info is None or account_info.password != password:
				return UserLoginResult(None, 'User name or password do not match.')

			user_data = UserDataObject(username)
			user_data.access_key = access_key

		# 新しい情報で上書き
		user_data.last_access_time = datetime.now()
		user_data.save()

		return UserLoginResult(user_data, "Success")

	@staticmethod
	def logout(username, access_key):
		if is_login(username, access_key):
			try:
				shutil.rmtree(os.path.join(config.DIR_LOGIN_USER_ROOT, username))
			except:
				return

	@staticmethod
	def is_login(username, access_key):
		if username is None or access_key is None or len(username) == 0 or len(access_key) == 0:
			return False

		# ログイン情報を取得
		user_data = UserManager.load_user_data(username)

		# 自身がログイン中かどうかを調べる
		return (user_data and user_data.username == username and user_data.access_key == access_key)

	@staticmethod
	def load_user_data(username):
		path_root = os.path.join(config.DIR_LOGIN_USER_ROOT, username)

		try:
			# ディレクトリが存在しなければ失敗
			if os.path.isdir(path_root) is False:
				return None

			# アクセスキー情報がなければ失敗
			if os.path.isfile(os.path.join(path_root, 'access-key')) is False:
				return None

			return UserDataObject(username)

		except:
			return None

class UserDataObject:
	def __init__(self, username):
		self.username = username

		if self.load() is False:
			self.access_key = create_access_key()
			self.last_access_time = datetime.now()

	def load(self):
		try:
			path_base = os.path.join(config.DIR_LOGIN_USER_ROOT, self.username)
			self.access_key = textutil.text_read(os.path.join(path_base, 'access-key'))
			self.last_access_time = textutil.datetime_text_read(os.path.join(path_base, 'last-access-time'))
			return True

		except:
			return False

	def save(self):
		path_base = os.path.join(config.DIR_LOGIN_USER_ROOT, self.username)
		textutil.text_write(os.path.join(path_base, 'access-key'), self.access_key)
		textutil.datetime_text_write(os.path.join(path_base, 'last-access-time'), self.last_access_time)

	def get_work_file_path(self, filename):
		path = os.path.join(config.DIR_LOGIN_USER_ROOT, self.username, 'work', filename)
		path_root = os.path.dirname(path)

		if os.path.isdir(path_root) is False:
			os.makedirs(path_root)

		return path

class UserLoginResult:
	def __init__(self, obj, msg):
		self.object = obj
		self.message = msg

class AccountManager:
	@staticmethod
	def load_account_info(username):
		if username == 'admin':
			return AccountInfo('admin')
		elif username == 'developper':
			return AccountInfo('developper')
		elif username == 'guest':
			return AccountInfo('guest')
		else:
			return None

class AccountInfo:
	def __init__(self, password):
		self.password = password

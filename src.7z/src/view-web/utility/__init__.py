#!/usr/bin/python3
# -*- coding: utf-8 -*-

from . import textutil

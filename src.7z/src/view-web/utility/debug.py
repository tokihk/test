#!/usr/bin/python3
# -*- coding: utf-8 -*-



class DebugManager:
	@staticmethod
	def WriteLine(obj):


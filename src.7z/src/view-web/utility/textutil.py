#!/usr/bin/python3
# -*- coding: utf-8 -*-

import os, datetime, random, string

def text_write(filepath, text):
	try:
		os.makedirs(os.path.dirname(filepath))
		with open(filepath, mode='w') as f:
			f.write(text)
	except:
		return

def text_read(filepath, default=None):
	try:
		with open(filepath) as f:
			return f.read()
	except:
		return default

def datetime_text_write(filepath, dt):
	text_write(filepath, dt.strftime('%Y-%m-%d %H:%M:%S'))

def datetime_text_read(filepath, default=datetime.datetime.now()):
	try:
		return datetime.strptime(textutil.text_read(filepath), '%Y-%m-%d %H:%M:%S')
	except:
		return default.strftime('%Y-%m-%d %H:%M:%S')

def random_text(len):
	return ''.join(random.choices(string.ascii_letters + string.digits, k = len))

#!/bin/sh
cd_old=`pwd`
cd "`dirname $0`"

start() {
    if [ -f /tmp/view-web-uwsgi.pid ]; then
        echo "Web view has already been launched."
    else
        echo "Launch web view."
        nohup uwsgi --ini view-web-uwsgi.ini &
        sleep 2s
    fi
}

stop() {
    echo "Stop the web view."
    if [ -f /tmp/view-web-uwsgi.pid ]; then
        uwsgi --stop /tmp/view-web-uwsgi.pid
        sleep 2s
    fi
}

restart() {
    stop
    start
}

case "$1" in
	start)
		start
		;;
	stop)
		stop
		;;
	restart)
		restart
		;;
	*)
		echo "Usage: $0 {start|stop|restart}"
		exit 1
esac

cd "${cd_old}"
exit $?

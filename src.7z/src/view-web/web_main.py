#!/usr/bin/python3
# -*- coding: utf-8 -*-

import os, sys, shutil, binascii, datetime, base64

from myapp import user_manager, system_manager

from flask import Flask, jsonify, request, session, g, redirect, url_for, abort, render_template, flash, send_from_directory, send_file
from werkzeug import secure_filename

# --- Flask初期化 ---
app = Flask(__name__)

# --- 設定ファイル読み込み ---
app.config.from_pyfile('web_main.cfg')

def render_page(url, **params):
	# ユーザー名を追加
	# params['username'] = "Guest"

	# 認証情報を追加
	# params['authority'] = icom.login.authority_get()

	# タイトルを付加
	# params['web_title'] = icom.setting.web_title_get()

	# バージョン情報を付加
	# params['system_info'] = icom.machine.system_info_get()

	# モード情報を付加
	# params['mode_info'] = icom.machine.mode_info_get()
	# params['debug_mode'] = icom.machine.debug_mode_check()

	return render_template(url, **params)

def render_member_page(url, **params):
	return (render_page(url, params))

def get_login_user_data():
	if 'username' not in session or 'access-key' not in session:
		return None

	user_data = user_manager.UserManager.login(session['username'], session['access-key'])
	if user_data is None:
		return None
	
	return user_data.object

@app.before_request
def on_webopen_before_request():
	# アクセスキーを作成
	if 'access-key' not in session:
		session['access-key'] = user_manager.create_access_key()

	# ログイン状態でなければログインページに移動
	if request.path != '/login':
		if 'username' not in session:
			return redirect('/login')

		if 'username' not in session or \
		   user_manager.UserManager.is_login(session['username'], session['access-key']) is False:
			return redirect('/login')

	app.logger.debug(request.path)

@app.route('/')
def on_webopen_root():
	return render_page('frame.html')

@app.route('/login', methods=['POST', 'GET'])
def on_webopen_login():
	if request.method == 'POST':
		return on_webopen_login_post()
	else:
		return render_page('login.html')

def on_webopen_login_post():
	username = request.form['username']
	password = request.form['password']

	# ログイン実行
	login_state = user_manager.UserManager.login(username, session['access-key'], password)

	# エラー処理
	if login_state.object is None:
		return render_page('login.html', msg_error=login_state.message)

	# ログイン情報を記憶
	session['username'] = username

	return redirect('/')

@app.route('/logout')
def on_webopen_logout():
	# ログイン中であればログアウトする
	if 'username' in session:
		user_manager.UserManager.logout(session['username'], session['access-key'])
		del session['username']

	return redirect('/')

@app.route('/home')
def on_webopen_home():
	return render_page('page-home.html')

@app.route('/terminal-console')
def on_webopen_terminal_console():
	return render_page('page-terminal-console.html')

@app.route('/file-explorer')
def on_webopen_file_explorer():
	return render_page('page-file-explorer.html')

@app.route('/firmware-update', methods=['POST', 'GET'])
def on_webopen_firmware_update():
	uobj = get_login_user_data()

	if request.method == 'POST':
		return on_webopen_firmware_update_post(uobj)

	else:
		return render_page('page-firmware-update.html')

def on_webopen_firmware_update_post(uobj):
	# ファームウェアパッケージの読み込み
	if request.form.get('upload-request') is not None:
		app.logger.debug('test')
		file = request.files['upload-file']
		if file:
			system_manager.FirmwareManager.update_ready(uobj, file)

	# 読み込んだファームウェアパッケージでアップグレードを実行
	if request.form.get('update-run') is not None:
		system_manager.FirmwareManager.update_run(uobj)

	return render_page('page-firmware-update.html')

if __name__ == "__main__":
	# デバッグモード判定
	if os.environ.get("MODE") == "debug":
		app.debug = True

	# サーバー起動
	app.run()

#	実機でデバッグさせる用
#	app.debug = True
#	app.run(host='0.0.0.0')

